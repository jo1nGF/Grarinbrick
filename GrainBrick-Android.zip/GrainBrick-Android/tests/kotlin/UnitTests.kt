// Plain-JVM tests for the Android-independent Kotlin code (JSON, WAV, demo sample, projects).
//
//   kotlinc app/src/main/java/com/grainbrick/android/SampleBuffer.kt \
//           app/src/main/java/com/grainbrick/android/Params.kt \
//           app/src/main/java/com/grainbrick/android/audio/*.kt tests/kotlin/UnitTests.kt -d /tmp/ut
//   java -cp /tmp/ut:<kotlin-stdlib.jar> UnitTestsKt [original AMBIENT.json | -] [params.tsv] [presets dir]
//   (params.tsv = output of tests/host/dump_params.cpp; the last two arguments enable the registry tests)
import com.grainbrick.android.ParamDef
import com.grainbrick.android.Params
import com.grainbrick.android.SampleBuffer
import com.grainbrick.android.audio.DemoSample
import com.grainbrick.android.audio.MiniJson
import com.grainbrick.android.audio.ProjectCodec
import com.grainbrick.android.audio.ProjectData
import com.grainbrick.android.audio.ProjectStore
import com.grainbrick.android.audio.RecordingCleanup
import com.grainbrick.android.audio.WavIO
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.system.exitProcess

private var checks = 0
private var failed = 0

private fun check(cond: Boolean, msg: () -> String) {
    checks++
    if (!cond) {
        failed++
        println("  FAIL: ${msg()}")
    }
}

private inline fun expectThrows(what: String, block: () -> Unit) {
    checks++
    try {
        block()
        failed++
        println("  FAIL: expected an exception: $what")
    } catch (e: Exception) {
        // expected
    }
}

private fun maxDiff(a: FloatArray, b: FloatArray): Float {
    if (a.size != b.size) return Float.MAX_VALUE
    var m = 0f
    for (i in a.indices) m = maxOf(m, abs(a[i] - b[i]))
    return m
}

private fun le16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())
private fun le32(v: Long) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())

/** Hand-assembled WAV for formats our own writer never produces. */
private fun rawWav(
    tag: Int, channels: Int, rate: Int, bits: Int, data: ByteArray, extensible: Boolean = false,
    dataSizeField: Long = data.size.toLong(), extraChunk: Boolean = false,
): ByteArray {
    val o = ByteArrayOutputStream()
    val fmt = ByteArrayOutputStream()
    fmt.write(le16(if (extensible) 0xFFFE else tag)); fmt.write(le16(channels)); fmt.write(le32(rate.toLong()))
    fmt.write(le32(rate.toLong() * channels * bits / 8)); fmt.write(le16(channels * bits / 8)); fmt.write(le16(bits))
    if (extensible) {
        fmt.write(le16(22)); fmt.write(le16(bits)); fmt.write(le32(3)); fmt.write(le16(tag))
        fmt.write(ByteArray(14))
    }
    o.write("RIFF".toByteArray()); o.write(le32(0)); o.write("WAVE".toByteArray())
    if (extraChunk) { o.write("LIST".toByteArray()); o.write(le32(3)); o.write(byteArrayOf(1, 2, 3, 0)) } // odd size + pad
    o.write("fmt ".toByteArray()); o.write(le32(fmt.size().toLong())); o.write(fmt.toByteArray())
    o.write("data".toByteArray()); o.write(le32(dataSizeField)); o.write(data)
    return o.toByteArray()
}

// ---------------------------------------------------------------------------------------------
private fun testJson() {
    println("json")
    val text = """ { "a": 1, "b": [1, 2.5, -3e2, true, false, null, "x\n\"y\" \u00e9 \\"], "c": {"d": {}}, "e": [] } """
    val v = MiniJson.parse(text) as Map<*, *>
    check(v["a"] == 1.0, { "a" })
    val b = v["b"] as List<*>
    check(b[2] == -300.0 && b[3] == true && b[4] == false && b[5] == null, { "array values $b" })
    check(b[6] == "x\n\"y\" \u00e9 \\", { "string escapes: ${b[6]}" })
    check((v["c"] as Map<*, *>)["d"] is Map<*, *> && (v["e"] as List<*>).isEmpty(), { "nested" })

    val round = MiniJson.parse(MiniJson.stringify(v)) as Map<*, *>
    check(round == v, { "stringify/parse round trip" })
    check(MiniJson.stringify(mapOf("f" to 0.55f), false) == "{\"f\":0.55}", { "float printed shortest: ${MiniJson.stringify(mapOf("f" to 0.55f), false)}" })
    check(MiniJson.stringify(mapOf("n" to Float.NaN), false) == "{\"n\":0}", { "NaN must not leak into JSON" })
    check(MiniJson.parse(MiniJson.stringify("tab\there \u0001")) == "tab\there \u0001", { "control chars" })

    for (bad in listOf("", "{", "[1,]", "{\"a\":}", "{a:1}", "[1 2]", "nul", "\"abc", "{\"a\":1} x", "1e999", "[\"\\q\"]", "\"\\u12\"")) {
        expectThrows("bad json <$bad>") { MiniJson.parse(bad) }
    }
    expectThrows("deep nesting") { MiniJson.parse("[".repeat(500) + "]".repeat(500)) }
    check(MiniJson.parse("\uFEFF{\"k\": 1}") is Map<*, *>, { "BOM tolerated" })
}

private fun testWav() {
    println("wav")
    val n = 5000
    val l = FloatArray(n) { 0.8f * sin(2 * PI * 440 * it / 44100).toFloat() }
    val r = FloatArray(n) { 0.5f * sin(2 * PI * 660 * it / 44100).toFloat() }

    var d = WavIO.read(WavIO.encode(l, r, 44100, mono = false))
    check(d.sampleRate == 44100 && !d.mono && d.left.size == n, { "stereo16 header" })
    check(maxDiff(l, d.left) < 1f / 16000 && maxDiff(r, d.right) < 1f / 16000, { "stereo16 data ${maxDiff(l, d.left)}" })

    d = WavIO.read(WavIO.encode(l, l, 22050, mono = true))
    check(d.mono && d.sampleRate == 22050 && d.left === d.right && maxDiff(l, d.left) < 1f / 16000, { "mono16" })

    d = WavIO.read(WavIO.encode(l, r, 48000, mono = false, float32 = true))
    check(maxDiff(l, d.left) == 0f && maxDiff(r, d.right) == 0f, { "float32 must be lossless" })

    // 24-bit PCM, extensible header, extra odd chunk before fmt
    val b24 = ByteArrayOutputStream()
    val vals = intArrayOf(0, 4194304, -4194304, 8388607, -8388608)
    for (v in vals) { b24.write(v and 0xFF); b24.write((v shr 8) and 0xFF); b24.write((v shr 16) and 0xFF) }
    d = WavIO.read(rawWav(1, 1, 48000, 24, b24.toByteArray(), extensible = true, extraChunk = true))
    check(abs(d.left[1] - 0.5f) < 1e-6 && abs(d.left[2] + 0.5f) < 1e-6 && abs(d.left[4] + 1f) < 1e-6, { "24 bit values ${d.left.toList()}" })

    // 8-bit unsigned
    d = WavIO.read(rawWav(1, 1, 8000, 8, byteArrayOf(0, 128.toByte(), 255.toByte())))
    check(d.left[0] == -1f && d.left[1] == 0f && d.left[2] > 0.99f, { "8 bit" })

    // 32-bit int
    d = WavIO.read(rawWav(1, 1, 8000, 32, le32(0x40000000L) + le32(0x80000000L)))
    check(abs(d.left[0] - 0.5f) < 1e-6 && d.left[1] == -1f, { "32 bit int" })

    // 6 channel file: first two channels used
    val six = ByteArrayOutputStream()
    for (f in 0 until 10) for (c in 0 until 6) six.write(le16((c + 1) * 1000))
    d = WavIO.read(rawWav(1, 6, 48000, 16, six.toByteArray()))
    check(!d.mono && d.left.size == 10 && abs(d.left[0] - 1000f / 32768f) < 1e-6 && abs(d.right[0] - 2000f / 32768f) < 1e-6, { "multichannel" })

    // streamed header (data size 0 / 0xFFFFFFFF) reads to EOF
    val pcm = ByteArray(2 * 300) { (it * 7).toByte() }
    for (field in longArrayOf(0L, 0xFFFFFFFFL)) {
        d = WavIO.read(rawWav(1, 1, 48000, 16, pcm, dataSizeField = field))
        check(d.left.size == 300, { "unknown data size $field -> ${d.left.size}" })
    }
    // data chunk claims more than exists: use what is there
    d = WavIO.read(rawWav(1, 1, 48000, 16, pcm, dataSizeField = 100000))
    check(d.left.size == 300, { "oversized data chunk" })

    // truncation flag
    d = WavIO.read(WavIO.encode(l, r, 44100, mono = false), maxFrames = 1000)
    check(d.left.size == 1000 && d.truncated, { "maxFrames truncation" })
    d = WavIO.read(WavIO.encode(l, r, 44100, mono = false), maxFrames = n)
    check(d.left.size == n && !d.truncated, { "exact fit is not truncated" })

    // duration limit uses the file's own sample rate
    val long96 = WavIO.encode(FloatArray(96000 * 3), FloatArray(96000 * 3), 96000, mono = false)
    d = WavIO.read(long96, maxSeconds = 2)
    check(d.left.size == 192000 && d.truncated, { "maxSeconds at 96 kHz -> ${d.left.size}" })
    d = WavIO.read(long96, maxSeconds = 3)
    check(d.left.size == 288000 && !d.truncated, { "maxSeconds exact fit -> ${d.left.size} ${d.truncated}" })

    // hostile / broken input
    val good = WavIO.encode(l, r, 44100, mono = false)
    expectThrows("empty") { WavIO.read(ByteArray(0)) }
    expectThrows("not wav") { WavIO.read(ByteArray(100) { 7 }) }
    expectThrows("header only") { WavIO.read(good.copyOf(44)) }
    expectThrows("compressed (ADPCM tag 2)") { WavIO.read(rawWav(2, 1, 8000, 4, pcm)) }
    expectThrows("0 channels") { WavIO.read(rawWav(1, 0, 8000, 16, pcm)) }
    expectThrows("bad rate") { WavIO.read(rawWav(1, 1, 5, 16, pcm)) }
    expectThrows("bad bits") { WavIO.read(rawWav(1, 1, 8000, 12, pcm)) }
    expectThrows("data before fmt") {
        val o = ByteArrayOutputStream()
        o.write("RIFF".toByteArray()); o.write(le32(100)); o.write("WAVE".toByteArray())
        o.write("data".toByteArray()); o.write(le32(4)); o.write(ByteArray(4))
        WavIO.read(o.toByteArray())
    }
    // truncated in the middle of the data: keeps the complete frames
    d = WavIO.read(good.copyOf(44 + 4 * 100 + 3))
    check(d.left.size == 100, { "mid-frame cut -> ${d.left.size}" })
    // NaN / Inf floats become silence
    val nan = ByteArrayOutputStream()
    nan.write(le32(0x7FC00000L)); nan.write(le32(0x7F800000L)); nan.write(le32(0x3F000000L))
    d = WavIO.read(rawWav(3, 1, 48000, 32, nan.toByteArray()))
    check(d.left[0] == 0f && d.left[1] == 0f && d.left[2] == 0.5f, { "non-finite floats ${d.left.toList()}" })
    // clipping on write
    val clip = WavIO.read(WavIO.encode(floatArrayOf(2f, -2f), floatArrayOf(2f, -2f), 44100, mono = false))
    check(clip.left[0] > 0.999f && clip.left[1] < -0.999f, { "clip on write" })
}

private fun testDemo() {
    println("demo sample")
    val t0 = System.nanoTime()
    val s = DemoSample.generate()
    val ms = (System.nanoTime() - t0) / 1e6
    println("  generated ${s.seconds}s in ${"%.0f".format(ms)} ms")
    check(s.frames == DemoSample.RATE * 14 && s.sampleRate == DemoSample.RATE, { "length ${s.frames}" })
    var finite = true
    var sumSq = 0.0
    var diff = 0.0
    for (i in 0 until s.frames) {
        if (!s.left[i].isFinite() || !s.right[i].isFinite()) finite = false
        sumSq += s.left[i].toDouble() * s.left[i]
        diff += abs(s.left[i] - s.right[i])
    }
    check(finite, { "finite" })
    val peak = s.peakLevel()
    check(peak in 0.79f..0.81f, { "normalised peak $peak" })
    val rms = Math.sqrt(sumSq / s.frames)
    check(rms > 0.05, { "audible rms $rms" })
    check(diff / s.frames > 0.005, { "stereo image (mean |L-R| = ${diff / s.frames})" })
    check(abs(s.left[0]) < 1e-4f && abs(s.left[s.frames - 1]) < 1e-4f, { "silent edges" })
    check(s.peaks(100).size == 200, { "peaks size" })
    val c = s.crop(0.25f, 0.5f, "crop")
    check(abs(c.frames - s.frames / 4) <= 2 && abs(c.left[0]) < 1e-6f, { "crop ${c.frames}" })
    val again = DemoSample.generate()
    check(maxDiff(s.left, again.left) == 0f, { "deterministic" })
}

private val ORIGINAL_STYLE = """
{
  "format": 1,
  "name": "AMBIENT",
  "parameters": { "comp.attack": 10.0, "comp.enabled": 1.0, "grain.spray": 0.9999999999999999,
                  "tape.crinkle": 2.7755575615628914e-17, "reverb.decay": 10.0, "weird": true, "skipme": "text" },
  "sample": { "path": "samples/sample grainbrick 1.wav", "type": "relative" }
}"""

private fun testProjects(originalPath: String?) {
    println("projects")
    val p = ProjectCodec.decode(ORIGINAL_STYLE, "fallback")
    check(p.name == "AMBIENT" && p.params.size == 6, { "original-style decode: ${p.name} ${p.params.size}" })
    check(p.params["tape.crinkle"]!! < 1e-12f && p.params["weird"] == 1f && "skipme" !in p.params, { "values" })
    check(p.sampleFileName() == "sample grainbrick 1.wav" && p.sampleType == "relative", { "sample ref" })
    check(ProjectData("x", samplePath = "C:\\music\\a b.wav").sampleFileName() == "a b.wav", { "windows path" })

    val text = ProjectCodec.encode(p)
    val q = ProjectCodec.decode(text, "z")
    check(q.params == p.params && q.name == p.name && q.samplePath == p.samplePath, { "encode/decode round trip" })
    check(text.contains("\"format\": 1"), { "format key" })

    check(ProjectCodec.sanitizeName("../../etc/passwd") == "etcpasswd", { "path traversal: ${ProjectCodec.sanitizeName("../../etc/passwd")}" })
    check(ProjectCodec.sanitizeName("  ") == "PROJECT" && ProjectCodec.sanitizeName("???") == "PROJECT", { "empty name" })
    check(ProjectCodec.sanitizeName(".hidden") == "hidden", { "leading dot" })
    check(ProjectCodec.sanitizeName("a".repeat(100)).length == 40, { "length cap" })
    check(ProjectCodec.decode("{\"parameters\":{}}", "My Song").name == "My Song", { "fallback name" })
    expectThrows("not an object") { ProjectCodec.decode("[1,2]", "x") }
    expectThrows("no parameters") { ProjectCodec.decode("{\"name\":\"a\"}", "x") }

    val dir = File.createTempFile("gbproj", "").let { it.delete(); it.mkdirs(); it }
    try {
        val st = ProjectStore(dir)
        check(st.list().isEmpty(), { "empty store" })
        st.save(ProjectData("Zeta", linkedMapOf("grain.size" to 0.25f)))
        st.save(ProjectData("alpha one", linkedMapOf("grain.size" to 1.5f), "samples/a.wav", "relative"))
        check(st.list() == listOf("alpha one", "Zeta"), { "sorted list ${st.list()}" })
        val back = st.load("alpha one")
        check(back.params["grain.size"] == 1.5f && back.samplePath == "samples/a.wav", { "load" })
        check(st.uniqueName("Zeta") == "Zeta 2" && st.uniqueName("fresh") == "fresh", { "unique names" })
        st.save(ProjectData("Zeta", linkedMapOf("grain.size" to 0.5f)))
        check(st.load("Zeta").params["grain.size"] == 0.5f && st.list().size == 2, { "overwrite" })
        check(dir.listFiles()!!.none { it.name.endsWith(".tmp") }, { "no temp files left" })
        check(st.delete("Zeta") && !st.exists("Zeta") && !st.delete("Zeta"), { "delete" })
        File(dir, "broken.json").writeText("{ nope")
        expectThrows("broken file") { st.load("broken") }
    } finally {
        dir.deleteRecursively()
    }

    if (originalPath != null && File(originalPath).isFile) {
        val o = ProjectCodec.decode(File(originalPath).readText(), "x")
        check(o.name == "AMBIENT" && o.params.size > 80, { "real original project: ${o.params.size} params" })
        check(o.params["shimmer.shift"] == 19f && o.params["orbix.balls"] == 6f, { "real original values" })
        println("  (original AMBIENT.json imported: ${o.params.size} parameters)")
    }
}

private fun testParams(tsvPath: String, presetsDir: String?, originalPath: String?) {
    println("parameter registry (${File(tsvPath).name})")
    val defs = ArrayList<ParamDef>()
    File(tsvPath).readLines().filter { it.isNotBlank() }.forEachIndexed { i, line ->
        val d = Params.parse(i, line)
        check(d != null, { "line $i did not parse: $line" })
        if (d != null) defs.add(d)
    }
    Params.install(defs)
    check(defs.size > 60, { "registry size ${defs.size}" })
    check(Params.byId("transport.playing") != null && Params.byId("grain.position") != null, { "lookup" })
    check(Params.inGroup("MIX").none { it.id == "transport.playing" }, { "transport must not appear in panels" })
    check(Params.groupOrder.all { g -> defs.any { it.group == g } }, { "every listed group has parameters" })
    // every group needs a home in the UI: GrainPage, FxPage, TapePage, OrbixPage, SettingsPage
    val shown = setOf("GRAIN", "ROAM", "MOTION", "EQ", "COMP", "DELAY", "REVERB", "SHIMMER", "TAPE", "ORBIX", "MIX", "SMOOTH")
    val unlisted = defs.map { it.group }.toSet() - shown
    check(unlisted.isEmpty(), { "parameter groups without a page: $unlisted" })

    for (d in defs) {
        check(d.def in d.min..d.max, { "${d.id} default outside range" })
        // normalised mapping must round-trip for knobs and stay inside 0..1
        for (t in listOf(0f, 0.25f, 0.5f, 0.9f, 1f)) {
            val v = d.fromNorm(t)
            check(v in d.min - 1e-4f..d.max + 1e-4f, { "${d.id} fromNorm($t)=$v" })
            check(abs(d.toNorm(v) - t) < 1e-3f, { "${d.id} norm round trip $t -> ${d.toNorm(v)}" })
        }
        check(d.toNorm(d.def) in 0f..1f, { "${d.id} default norm" })
        check(d.format(d.def).isNotBlank() && d.format(d.min).isNotBlank() && d.format(d.max).isNotBlank(), { "${d.id} format" })
        if (d.isChoice) {
            check(d.choices.size == (d.max - d.min).toInt() + 1, { "${d.id}: ${d.choices.size} labels for ${d.min}..${d.max}" })
            for (i in d.choices.indices) check(d.format(d.min + i) == d.choices[i], { "${d.id} label $i" })
        }
        check(d.help.length > 10, { "${d.id} help" })
    }
    check(Params.byId("delay.time")!!.format(1200f) == "1.20 s" && Params.byId("delay.time")!!.format(850f) == "850 ms", { "ms formatting" })
    check(Params.byId("reverb.damp")!!.format(12000f) == "12.0 kHz", { "Hz formatting" })
    check(Params.byId("level.master_db")!!.format(3f) == "+3.0 dB", { "dB formatting" })
    check(Params.byId("grain.pitch")!!.format(-12f) == "-12.0 st", { "semitone formatting" })
    check(Params.byId("orbix.root")!!.format(4f) == "E" && Params.byId("orbix.octave")!!.format(-1f) == "-1", { "choice formatting" })

    if (presetsDir != null) {
        val files = File(presetsDir).listFiles { f -> f.name.endsWith(".json") }!!.sortedBy { it.name }
        check(files.size >= 5, { "bundled presets: ${files.size}" })
        for (f in files) {
            val p = ProjectCodec.decode(f.readText(), f.nameWithoutExtension)
            check(p.sampleType == "builtin" && p.sampleFileName() == DemoSample.FILE, { "${f.name} sample reference" })
            for ((k, v) in p.params) {
                val d = Params.byId(k)
                check(d != null, { "${f.name}: unknown parameter $k" })
                if (d != null) check(v >= d.min - 1e-6f && v <= d.max + 1e-6f, { "${f.name}: $k=$v outside ${d.min}..${d.max}" })
            }
            // a preset that survives encode/decode unchanged is what "Save" will write
            val again = ProjectCodec.decode(ProjectCodec.encode(p), "x")
            check(again.params == p.params, { "${f.name} round trip" })
        }
        println("  ${files.size} bundled presets decoded and range-checked")
    }
    if (originalPath != null && File(originalPath).isFile) {
        val o = ProjectCodec.decode(File(originalPath).readText(), "x")
        val unknown = o.params.keys.filter { Params.byId(it) == null }
        val outside = o.params.filter { (k, v) -> Params.byId(k)?.let { v < it.min - 1e-4f || v > it.max + 1e-4f } == true }
        println("  original AMBIENT.json: ${o.params.size} keys, unknown here: $unknown, outside our ranges: $outside")
        check(unknown.isEmpty(), { "original keys unknown to the registry: $unknown" })
    }
}

private fun testRecordingCleanup() {
    println("recording cleanup")
    val rate = 48000
    val n = rate
    fun tone(amp: Float, dc: Float) = FloatArray(n) { amp * Math.sin(2.0 * Math.PI * 440.0 * it / rate).toFloat() + dc }

    // quiet, offset take: DC removed, brought up to about -1 dBFS, edges faded
    val a = tone(0.08f, 0.05f)
    val ra = RecordingCleanup.process(a, a, rate)
    check(!ra.silent, { "a quiet tone is not silence" })
    var mean = 0.0
    for (v in a) mean += v
    check(Math.abs(mean / n) < 1e-4, { "DC offset left: ${mean / n}" })
    val peakA = a.maxOf { Math.abs(it) }
    check(Math.abs(peakA - RecordingCleanup.TARGET_PEAK) < 0.02f, { "quiet take should reach -1 dBFS, got $peakA" })
    check(Math.abs(a[0]) < 1e-6f && Math.abs(a[n - 1]) < 1e-6f, { "edges must be faded" })
    check(ra.gain > 10f && ra.gain <= RecordingCleanup.MAX_GAIN + 1e-3f, { "gain ${ra.gain}" })

    // a loud take keeps its level
    val b = tone(0.8f, 0f)
    val rb = RecordingCleanup.process(b, b, rate)
    check(rb.gain == 1f, { "loud take must not be changed in level" })
    check(Math.abs(b.maxOf { Math.abs(it) } - 0.8f) < 0.01f, { "loud peak" })

    // digital silence / near silence is refused
    val z = FloatArray(n)
    check(RecordingCleanup.process(z, z, rate).silent, { "zeros are silence" })
    val noise = FloatArray(n) { 0.0002f * (if (it % 2 == 0) 1f else -1f) }
    check(RecordingCleanup.process(noise, noise, rate).silent, { "-74 dB noise counts as silence" })

    // very quiet but real signal: gain is capped
    val c = tone(0.003f, 0f)
    val rc = RecordingCleanup.process(c, c, rate)
    check(!rc.silent && Math.abs(rc.gain - RecordingCleanup.MAX_GAIN) < 1e-3f, { "gain cap, got ${rc.gain}" })

    // stereo: both channels get the same gain, mono arrays are not processed twice
    val l = tone(0.1f, 0.02f)
    val r = tone(0.05f, -0.02f)
    val ratio0 = 0.5f // 0.05 / 0.1 once the offsets (+0.02 / -0.02) are gone
    RecordingCleanup.process(l, r, rate)
    val ratio1 = r.maxOf { Math.abs(it) } / l.maxOf { Math.abs(it) }
    check(Math.abs(ratio0 - ratio1) < 0.01f, { "stereo balance changed: $ratio0 -> $ratio1" })
    val m = tone(0.1f, 0f)
    RecordingCleanup.process(m, m, rate)
    check(Math.abs(m.maxOf { Math.abs(it) } - RecordingCleanup.TARGET_PEAK) < 0.02f, { "mono processed twice? peak ${m.maxOf { Math.abs(it) }}" })

    // tiny takes do not crash
    val t = FloatArray(3) { 0.3f }
    RecordingCleanup.process(t, t, rate)
    check(RecordingCleanup.process(FloatArray(0), FloatArray(0), rate).silent, { "empty take" })
}

fun main(args: Array<String>) {
    testJson()
    testWav()
    testDemo()
    testRecordingCleanup()
    testProjects(args.getOrNull(0)?.takeIf { it != "-" })
    if (args.size >= 2) testParams(args[1], args.getOrNull(2), args.getOrNull(0)?.takeIf { it != "-" })
    println("\n$checks checks, $failed failed")
    if (failed != 0) exitProcess(1)
}
