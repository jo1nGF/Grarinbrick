// Writes the procedurally generated demo pad to a WAV file (used by the host preset audio check).
//   kotlinc SampleBuffer.kt audio/DemoSample.kt audio/WavIO.kt tests/kotlin/DumpDemo.kt -d out && java -cp out:kotlin-stdlib.jar DumpDemoKt demo.wav
import com.grainbrick.android.audio.DemoSample
import com.grainbrick.android.audio.WavIO
import java.io.File

fun main(args: Array<String>) {
    val s = DemoSample.generate()
    File(args.firstOrNull() ?: "demo-pad.wav").writeBytes(WavIO.encode(s.left, s.right, s.sampleRate, s.mono))
}
