// Offline renderer: renders the engine to a WAV file. Handy for previewing presets without a phone.
//   render in.wav out.wav seconds [key=value ...] [project.json]
// A GrainBrick project JSON (flat "key": number pairs inside "parameters") may be given as an
// argument that ends in .json.
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <regex>
#include <sstream>

#include "../../app/src/main/cpp/engine/engine.h"
#include "wav.h"

static void loadProject(gb::Engine& e, const std::string& path) {
  std::ifstream in(path);
  std::stringstream ss;
  ss << in.rdbuf();
  std::string s = ss.str();
  std::regex kv("\"([a-z0-9_.]+)\"\\s*:\\s*(-?[0-9.eE+-]+)");
  for (std::sregex_iterator it(s.begin(), s.end(), kv), end; it != end; ++it) {
    int idx = gb::paramIndex((*it)[1].str().c_str());
    if (idx >= 0) e.setParam(idx, std::strtof((*it)[2].str().c_str(), nullptr));
  }
}

int main(int argc, char** argv) {
  if (argc < 4) { std::fprintf(stderr, "usage: render in.wav out.wav seconds [key=value|project.json ...]\n"); return 2; }
  WavData w;
  if (std::string(argv[1]) != "-" && !readWav(argv[1], w)) { std::fprintf(stderr, "cannot read %s\n", argv[1]); return 1; }
  const int sr = 48000;
  const float secs = std::strtof(argv[3], nullptr);
  gb::Engine e;
  e.prepare(sr);
  if (!w.l.empty()) e.publishSample(w.l.data(), w.r.data(), static_cast<int>(w.l.size()), w.sampleRate);
  e.setParam(gb::P_TRANSPORT_PLAYING, 1.f);
  for (int i = 4; i < argc; ++i) {
    std::string a = argv[i];
    if (a.size() > 5 && a.substr(a.size() - 5) == ".json") { loadProject(e, a); continue; }
    auto eq = a.find('=');
    if (eq == std::string::npos) continue;
    int idx = gb::paramIndex(a.substr(0, eq).c_str());
    if (idx < 0) { std::fprintf(stderr, "unknown param %s\n", a.c_str()); return 1; }
    e.setParam(idx, std::strtof(a.c_str() + eq + 1, nullptr));
  }
  e.snapParams();
  const int total = static_cast<int>(secs * sr);
  std::vector<float> out(static_cast<size_t>(total) * 2);
  const int chunk = 480;
  for (int pos = 0; pos < total; pos += chunk) e.render(out.data() + 2 * pos, std::min(chunk, total - pos), nullptr);
  writeWav16(argv[2], out, sr);
  return 0;
}
