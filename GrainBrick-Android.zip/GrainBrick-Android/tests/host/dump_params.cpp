// Prints the parameter registry exactly like jni_bridge.cpp's nParamInfo (one tab-separated line
// per parameter). Used by tools/validate_presets.py and the Kotlin unit tests.
//   g++ -std=c++17 tests/host/dump_params.cpp app/src/main/cpp/engine/params.cpp -o dump_params
#include <cstdio>
#include <string>

#include "../../app/src/main/cpp/engine/params.h"

int main() {
  for (int i = 0; i < gb::paramCount(); ++i) {
    const gb::ParamInfo& p = gb::paramInfo(i);
    char nums[160];
    std::snprintf(nums, sizeof(nums), "%.6g\t%.6g\t%.6g\t%d\t%d", static_cast<double>(p.min),
                  static_cast<double>(p.max), static_cast<double>(p.def), static_cast<int>(p.kind),
                  static_cast<int>(p.curve));
    std::string s = std::string(p.id) + "\t" + p.group + "\t" + p.label + "\t" + p.unit + "\t" + nums + "\t" +
                    (p.choices ? p.choices : "") + "\t" + p.help;
    std::puts(s.c_str());
  }
  return 0;
}
