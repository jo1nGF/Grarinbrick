#!/usr/bin/env bash
# Builds the host-side tools into $1 (default: ./build). Needs only g++ and the sources in this repo.
#   tests/host/build.sh [outdir] [tool ...]      tools: engine_test render dump_params shimmer_eval shimmer_tail
set -euo pipefail
cd "$(dirname "$0")/../.."
OUT="${1:-build}"; shift || true
TOOLS=("$@"); [ ${#TOOLS[@]} -eq 0 ] && TOOLS=(engine_test render dump_params)
mkdir -p "$OUT"

ENGINE=(app/src/main/cpp/engine/engine.cpp app/src/main/cpp/engine/params.cpp)
ST=(app/src/main/cpp/soundtouch/st_bridge.cpp)
for f in AAFilter FIFOSampleBuffer FIRFilter InterpolateCubic InterpolateLinear InterpolateShannon \
         RateTransposer SoundTouch TDStretch cpu_detect_x86 mmx_optimized sse_optimized PeakFinder; do
  ST+=("third_party/soundtouch/source/$f.cpp")
done
INC=(-Iapp/src/main/cpp -Ithird_party/soundtouch/include -Ithird_party/soundtouch/source -Itests/host)
CXX="${CXX:-g++}"
FLAGS=(-std=c++17 -O2 -Wall -Wextra -Wno-mismatched-new-delete "${INC[@]}" -DSOUNDTOUCH_FLOAT_SAMPLES -fexceptions)

# SoundTouch itself is third-party code: compile it once without our warning flags.
ST_OBJ="$OUT/soundtouch.o.a"
if [ ! -f "$ST_OBJ" ] || [ -n "$(find third_party/soundtouch app/src/main/cpp/soundtouch -newer "$ST_OBJ" -type f 2>/dev/null | head -1)" ]; then
  rm -rf "$OUT/st_objs"; mkdir -p "$OUT/st_objs"
  for f in "${ST[@]}"; do
    "$CXX" -std=c++17 -O2 -fexceptions -DSOUNDTOUCH_FLOAT_SAMPLES "${INC[@]}" -c "$f" -o "$OUT/st_objs/$(basename "$f").o"
  done
  rm -f "$ST_OBJ"; ar rcs "$ST_OBJ" "$OUT"/st_objs/*.o
fi

for t in "${TOOLS[@]}"; do
  case "$t" in
    engine_test)   "$CXX" "${FLAGS[@]}" tests/host/engine_test.cpp "${ENGINE[@]}" "$ST_OBJ" -o "$OUT/engine_test" -pthread ;;
    render)        "$CXX" "${FLAGS[@]}" tests/host/render.cpp "${ENGINE[@]}" "$ST_OBJ" -o "$OUT/render" -pthread ;;
    dump_params)   "$CXX" "${FLAGS[@]}" tests/host/dump_params.cpp app/src/main/cpp/engine/params.cpp -o "$OUT/dump_params" ;;
    shimmer_eval)  "$CXX" "${FLAGS[@]}" tests/host/shimmer_eval.cpp "${ENGINE[@]}" "$ST_OBJ" -o "$OUT/shimmer_eval" -pthread ;;
    shimmer_tail)  "$CXX" "${FLAGS[@]}" tests/host/shimmer_tail.cpp "${ENGINE[@]}" "$ST_OBJ" -o "$OUT/shimmer_tail" -pthread ;;
    *) echo "unknown tool $t" >&2; exit 2 ;;
  esac
  echo "built $OUT/$t"
done
