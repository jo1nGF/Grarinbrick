#!/usr/bin/env bash
# Builds the host-side tools into $1 (default: ./build). Needs only g++ and the sources in this repo.
#   tests/host/build.sh [outdir] [tool ...]      tools: engine_test render dump_params shimmer_eval shimmer_tail shifter_eval voice_eval
set -euo pipefail
cd "$(dirname "$0")/../.."
OUT="${1:-build}"; shift || true
TOOLS=("$@"); [ ${#TOOLS[@]} -eq 0 ] && TOOLS=(engine_test render dump_params)
mkdir -p "$OUT"

ENGINE=(app/src/main/cpp/engine/engine.cpp app/src/main/cpp/engine/params.cpp)
ST=(app/src/main/cpp/soundtouch/st_bridge.cpp)
for f in AAFilter FIFOSampleBuffer FIRFilter InterpolateCubic InterpolateLinear InterpolateShannon \
         RateTransposer SoundTouch TDStretch cpu_detect_x86 mmx_optimized sse_optimized PeakFinder; do
  ST+=("third_party/soundtouch/source/$f.cpp")
done
INC=(-Iapp/src/main/cpp -Ithird_party/soundtouch/include -Ithird_party/soundtouch/source -Itests/host)
CXX="${CXX:-g++}"
FLAGS=(-std=c++17 -O2 -Wall -Wextra -Wno-mismatched-new-delete "${INC[@]}" -DSOUNDTOUCH_FLOAT_SAMPLES -fexceptions)

# SoundTouch itself is third-party code: compile it once without our warning flags.
ST_OBJ="$OUT/soundtouch.o.a"
if [ ! -f "$ST_OBJ" ] || [ -n "$(find third_party/soundtouch app/src/main/cpp/soundtouch -newer "$ST_OBJ" -type f 2>/dev/null | head -1)" ]; then
  rm -rf "$OUT/st_objs"; mkdir -p "$OUT/st_objs"
  for f in "${ST[@]}"; do
    "$CXX" -std=c++17 -O2 -fexceptions -DSOUNDTOUCH_FLOAT_SAMPLES "${INC[@]}" -c "$f" -o "$OUT/st_objs/$(basename "$f").o"
  done
  rm -f "$ST_OBJ"; ar rcs "$ST_OBJ" "$OUT"/st_objs/*.o
fi

# The Mutable Instruments firmware code (MIT, third_party/mutable) and its wrappers: compiled once, quietly.
MUT_OBJ="$OUT/mutable.o.a"
MUT=(app/src/main/cpp/engine/mutable_rings.cpp app/src/main/cpp/engine/mutable_elements.cpp
     third_party/mutable/stmlib/dsp/atan.cc third_party/mutable/stmlib/dsp/units.cc third_party/mutable/stmlib/utils/random.cc)
for f in third_party/mutable/rings/dsp/*.cc third_party/mutable/rings/resources.cc \
         third_party/mutable/elements/dsp/*.cc third_party/mutable/elements/resources.cc; do MUT+=("$f"); done
if [ ! -f "$MUT_OBJ" ] || [ -n "$(find third_party/mutable app/src/main/cpp/engine -newer "$MUT_OBJ" -type f \( -name '*.cc' -o -name '*.h' -o -name 'mutable_*.cpp' \) 2>/dev/null | head -1)" ]; then
  rm -rf "$OUT/mut_objs"; mkdir -p "$OUT/mut_objs"
  i=0
  for f in "${MUT[@]}"; do
    i=$((i+1))
    "$CXX" -std=c++17 -O2 -w -DTEST -Ithird_party/mutable -Iapp/src/main/cpp/engine -c "$f" -o "$OUT/mut_objs/$i-$(basename "$f").o" &
    [ $((i % 6)) -eq 0 ] && wait
  done
  wait
  rm -f "$MUT_OBJ"; ar rcs "$MUT_OBJ" "$OUT"/mut_objs/*.o
fi

for t in "${TOOLS[@]}"; do
  case "$t" in
    engine_test)   "$CXX" "${FLAGS[@]}" tests/host/engine_test.cpp "${ENGINE[@]}" "$ST_OBJ" "$MUT_OBJ" -o "$OUT/engine_test" -pthread ;;
    render)        "$CXX" "${FLAGS[@]}" tests/host/render.cpp "${ENGINE[@]}" "$ST_OBJ" "$MUT_OBJ" -o "$OUT/render" -pthread ;;
    dump_params)   "$CXX" "${FLAGS[@]}" tests/host/dump_params.cpp app/src/main/cpp/engine/params.cpp -o "$OUT/dump_params" ;;
    shimmer_eval)  "$CXX" "${FLAGS[@]}" tests/host/shimmer_eval.cpp "${ENGINE[@]}" "$ST_OBJ" "$MUT_OBJ" -o "$OUT/shimmer_eval" -pthread ;;
    shimmer_tail)  "$CXX" "${FLAGS[@]}" tests/host/shimmer_tail.cpp "${ENGINE[@]}" "$ST_OBJ" "$MUT_OBJ" -o "$OUT/shimmer_tail" -pthread ;;
    shifter_eval)  "$CXX" "${FLAGS[@]}" tests/host/shifter_eval.cpp "${ENGINE[@]}" "$ST_OBJ" "$MUT_OBJ" -o "$OUT/shifter_eval" -pthread ;;
    voice_eval)    "$CXX" "${FLAGS[@]}" tests/host/voice_eval.cpp app/src/main/cpp/engine/params.cpp "$MUT_OBJ" -o "$OUT/voice_eval" ;;
    *) echo "unknown tool $t" >&2; exit 2 ;;
  esac
  echo "built $OUT/$t"
done
