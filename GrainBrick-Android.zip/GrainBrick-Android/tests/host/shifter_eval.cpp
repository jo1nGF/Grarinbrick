// Compares the two pitch-shift engines of the shimmer on their own:
//   purity  : a 440 Hz sine shifted +12 st must show up at 880 Hz; how much of the output energy is
//             within +-2 % of it (the rest is sidebands / noise from the splicing)
//   ripple  : steady noise through the shifter; the standard deviation of the 10 ms RMS in dB
//             (a periodic splice or crossfade shows up as flutter / tremolo)
//   latency : delay of an impulse, in ms
#include <cmath>
#include <cstdio>
#include <vector>

#include "fft.h"
#include "../../app/src/main/cpp/engine/reverb.h"

using namespace gb;
constexpr int kSr = 48000;

template <class S>
static std::vector<float> run(S& s, const std::vector<float>& in) {
  std::vector<float> out(in.size());
  std::vector<float> a(64), b(64);
  for (size_t i = 0; i + 64 <= in.size(); i += 64) {
    std::vector<float> l(in.begin() + static_cast<long>(i), in.begin() + static_cast<long>(i) + 64);
    s.process(l.data(), l.data(), out.data() + i, b.data(), 64);
  }
  return out;
}

template <class S>
static void eval(const char* name, S& s, float st) {
  s.setPitch(st);
  s.setSmooth(0.5f);
  const double ratio = std::pow(2.0, st / 12.0);
  // purity
  std::vector<float> sine(static_cast<size_t>(kSr) * 3);
  for (size_t i = 0; i < sine.size(); ++i) sine[i] = 0.5f * std::sin(6.2831853f * 440.f * static_cast<float>(i) / kSr);
  auto y = run(s, sine);
  const size_t N = 32768, from = static_cast<size_t>(kSr) * 2;
  auto p = ana::power(y, from, N);
  const double bin = static_cast<double>(kSr) / static_cast<double>(N), target = 440.0 * ratio;
  double tot = 0, near = 0;
  for (size_t i = 2; i < p.size(); ++i) {
    const double f = static_cast<double>(i) * bin;
    tot += p[i];
    if (std::fabs(f - target) < 0.02 * target) near += p[i];
  }
  // ripple
  Rng r(7);
  std::vector<float> noise(static_cast<size_t>(kSr) * 4);
  for (auto& v : noise) v = 0.2f * r.bi();
  s.reset();
  s.setPitch(st);
  auto n = run(s, noise);
  std::vector<double> db;
  const size_t w = kSr / 100;
  for (size_t i = static_cast<size_t>(kSr); i + w < n.size(); i += w) {
    double e = 0;
    for (size_t k = 0; k < w; ++k) e += static_cast<double>(n[i + k]) * n[i + k];
    db.push_back(10 * std::log10(e / static_cast<double>(w) + 1e-12));
  }
  double m = 0, v = 0;
  for (double d : db) m += d;
  m /= static_cast<double>(db.size());
  for (double d : db) v += (d - m) * (d - m);
  v = std::sqrt(v / static_cast<double>(db.size()));
  // latency
  s.reset();
  s.setPitch(0.f);
  std::vector<float> imp(static_cast<size_t>(kSr) / 2, 0.f);
  imp[2000] = 1.f;
  auto io = run(s, imp);
  size_t at = 0;
  float best = 0;
  for (size_t i = 0; i < io.size(); ++i) if (std::fabs(io[i]) > best) { best = std::fabs(io[i]); at = i; }
  std::printf("%-14s %+5.0f st  purity %5.1f dB (energy within 2%% of target vs rest)   noise ripple %.2f dB   latency(0st) %.0f ms\n", name, st,
              10 * std::log10(near / (tot - near + 1e-20)), v, (static_cast<double>(at) - 2000.0) * 1000.0 / kSr);
  s.reset();
}

int main() {
  GrainShifter cloud;
  cloud.prepare(kSr);
  cloud.setTexture(0.5f);
  StShifter clean;
  clean.prepare(kSr);
  for (float st : {12.f, 7.f, -12.f}) {
    cloud.setTexture(0.0f);
    eval("cloud tex 0", cloud, st);
    cloud.setTexture(0.5f);
    eval("cloud tex .5", cloud, st);
    cloud.setTexture(1.0f);
    eval("cloud tex 1", cloud, st);
    eval("clean", clean, st);
  }
  return 0;
}
