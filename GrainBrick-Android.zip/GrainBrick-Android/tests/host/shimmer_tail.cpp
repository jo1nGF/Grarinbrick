// Does the shimmer actually shimmer? Feeds a short two-note chord (220 + 330 Hz), then silence, and
// prints how the energy of the tail is spread over octaves above the notes, second by second.
// In a true shimmer the weight moves up: first the notes, then +1 octave, then +2, ...
// A plain reverb keeps all its tail on the original notes.
//
//   shimmer_tail [key=value ...]       keys are parameter ids, e.g. shimmer.feedback=0.7
//   (the shimmer is run on its own, input level = shimmer.mix * 1.5, like the engine's send)
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "fft.h"
#include "../../app/src/main/cpp/engine/reverb.h"

using namespace gb;

int main(int argc, char** argv) {
  constexpr int kSr = 48000;
  float P[P_COUNT];
  for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
  bool sustain = false;  // sustain=1: the chord never stops (a pad); prints level over time instead
  for (int a = 1; a < argc; ++a) {
    const char* eq = std::strchr(argv[a], '=');
    if (!eq) continue;
    const std::string key(argv[a], static_cast<size_t>(eq - argv[a]));
    if (key == "sustain") { sustain = std::atoi(eq + 1) != 0; continue; }
    bool found = false;
    for (int i = 0; i < P_COUNT; ++i)
      if (key == paramInfo(i).id) { P[i] = static_cast<float>(std::atof(eq + 1)); found = true; }
    if (!found) { std::fprintf(stderr, "unknown parameter %s\n", key.c_str()); return 2; }
  }
  const double secs = 14.0;
  const size_t total = static_cast<size_t>(secs * kSr);
  const size_t noteLen = sustain ? total : kSr / 2;
  std::vector<float> in(total, 0.f), outL(total, 0.f), outR(total, 0.f);
  const float sendGain = P[P_SHIMMER_MIX] * 1.5f;
  for (size_t i = 0; i < noteLen; ++i) {
    const float t = static_cast<float>(i) / kSr;
    const float env = std::min(1.f, t / 0.02f) * std::min(1.f, static_cast<float>(noteLen - i) / (0.05f * kSr));
    in[i] = 0.35f * env * (std::sin(2.f * static_cast<float>(M_PI) * 220.f * t) + std::sin(2.f * static_cast<float>(M_PI) * 330.f * t));
  }
  Shimmer sh;
  sh.prepare(kSr);
  sh.setParams(P);
  std::vector<float> a(64), b(64);
  float peak = 0.f;
  for (size_t i = 0; i + 64 <= total; i += 64) {
    for (size_t k = 0; k < 64; ++k) a[k] = b[k] = in[i + k] * sendGain;
    sh.processBlock(a.data(), b.data(), outL.data() + i, outR.data() + i, 64);
    for (size_t k = 0; k < 64; ++k) peak = std::max(peak, std::max(std::fabs(outL[i + k]), std::fabs(outR[i + k])));
  }
  if (sustain) {
    std::printf("sustained chord, feedback %.2f: wet level per 2 s (dB re full scale) and peak\n", P[P_SHIMMER_FEEDBACK]);
    for (size_t from = 0; from + 2 * kSr <= total; from += 2 * kSr) {
      double s2 = 0, pk = 0;
      for (size_t i = from; i < from + 2 * kSr; ++i) { s2 += static_cast<double>(outL[i]) * outL[i]; pk = std::max(pk, static_cast<double>(std::fabs(outL[i]))); }
      std::printf("  %4.0f-%4.0f s  rms %6.1f dB   peak %6.1f dB\n", static_cast<double>(from) / kSr, static_cast<double>(from) / kSr + 2,
                  10 * std::log10(s2 / (2.0 * kSr) + 1e-20), 20 * std::log10(pk + 1e-12));
    }
    const size_t N2 = 32768, from2 = total - N2 - 1;
    auto p2 = ana::power(outL, from2, N2);
    const double bin2 = static_cast<double>(kSr) / static_cast<double>(N2);
    double tot2 = 0;
    std::printf("  steady-state spectrum, dB re total, per octave band:");
    const double e2[] = {100, 180, 400, 800, 1600, 3200, 6400, 12800};
    std::vector<double> b2(7, 0.0);
    for (size_t i = 1; i < p2.size(); ++i) { const double f = static_cast<double>(i) * bin2; tot2 += p2[i]; for (int k = 0; k < 7; ++k) if (f >= e2[k] && f < e2[k + 1]) b2[static_cast<size_t>(k)] += p2[i]; }
    for (int k = 0; k < 7; ++k) std::printf(" %.0f:%.1f", e2[k], 10 * std::log10(b2[static_cast<size_t>(k)] / tot2 + 1e-12));
    std::printf("\n");
    return 0;
  }
  // octave bands above the notes: [180,400) notes, then x2 each
  const double edges[] = {180, 400, 800, 1600, 3200, 6400, 12800};
  const int nb = 6;
  std::printf("feedback %.2f shift %.0f dual %.0f mix %.2f | peak %.1f dB\n", P[P_SHIMMER_FEEDBACK], P[P_SHIMMER_SHIFT], P[P_SHIMMER_DUAL],
              P[P_SHIMMER_MIX], 20 * std::log10(peak + 1e-12));
  std::printf("%-9s %7s |", "window", "level");
  for (int k = 0; k < nb; ++k) std::printf(" %4.0f-%-5.0f", edges[k], edges[k + 1]);
  std::printf("   (band level in dB relative to the loudest band of the whole tail)\n");
  const size_t N = 16384;
  const double bin = static_cast<double>(kSr) / static_cast<double>(N);
  std::vector<std::vector<double>> rows;
  std::vector<double> levels;
  double maxBand = 1e-30;
  for (int w = 0; w < 13; ++w) {
    const size_t from = noteLen + static_cast<size_t>(w) * kSr;
    if (from + N > total) break;
    auto p = ana::power(outL, from, N);
    std::vector<double> band(nb, 0.0);
    double tot = 0;
    for (size_t i = 1; i < p.size(); ++i) {
      const double f = static_cast<double>(i) * bin;
      tot += p[i];
      for (int k = 0; k < nb; ++k) if (f >= edges[k] && f < edges[k + 1]) band[static_cast<size_t>(k)] += p[i];
    }
    for (double v : band) maxBand = std::max(maxBand, v);
    rows.push_back(band);
    levels.push_back(tot);
  }
  for (size_t w = 0; w < rows.size(); ++w) {
    std::printf("%2zu-%2zu s  %6.1f |", w, w + 1, 10 * std::log10(levels[w] / maxBand + 1e-12));
    for (int k = 0; k < nb; ++k) std::printf(" %10.1f", 10 * std::log10(rows[w][static_cast<size_t>(k)] / maxBand + 1e-12));
    std::printf("\n");
  }
  return 0;
}
