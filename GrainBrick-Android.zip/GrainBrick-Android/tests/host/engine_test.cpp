// Host-side tests for the GrainBrick DSP engine. Uses only synthetic signals.
//   g++ -std=c++17 -O2 engine_test.cpp ../../app/src/main/cpp/engine/{engine,params}.cpp -pthread
#include <atomic>
#include <new>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>
#include <thread>

#include "fft.h"
#include "../../app/src/main/cpp/engine/engine.h"
#include "../../app/src/main/cpp/engine/reverb.h"

using namespace gb;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond, ...)                                              \
  do {                                                                \
    ++g_checks;                                                       \
    if (!(cond)) {                                                    \
      ++g_fail;                                                       \
      std::printf("  FAIL %s:%d  %s  -- ", __FILE__, __LINE__, #cond); \
      std::printf(__VA_ARGS__);                                       \
      std::printf("\n");                                              \
    }                                                                 \
  } while (0)

static constexpr int kSr = 48000;

// ---- allocation counter: the audio path must not allocate once prepared --------------------------
static std::atomic<long> g_allocs{0};
static std::atomic<bool> g_countAllocs{false};
void* operator new(std::size_t n) {
  if (g_countAllocs.load(std::memory_order_relaxed)) g_allocs.fetch_add(1, std::memory_order_relaxed);
  void* p = std::malloc(n ? n : 1);
  if (!p) throw std::bad_alloc();
  return p;
}
void* operator new[](std::size_t n) { return operator new(n); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }

// ---- helpers --------------------------------------------------------------------------------
static std::vector<float> sine(float hz, float secs, float amp = 0.5f, int sr = kSr) {
  std::vector<float> v(static_cast<size_t>(secs * static_cast<float>(sr)));
  for (size_t i = 0; i < v.size(); ++i)
    v[i] = amp * std::sin(kTwoPi * hz * static_cast<float>(i) / static_cast<float>(sr));
  return v;
}

static double goertzel(const float* x, int n, double hz, double sr) {
  const double w = 2.0 * M_PI * hz / sr, c = 2.0 * std::cos(w);
  double s1 = 0, s2 = 0;
  for (int i = 0; i < n; ++i) {
    double win = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / (n - 1));  // Hann
    double s = x[i] * win + c * s1 - s2;
    s2 = s1;
    s1 = s;
  }
  double re = s1 - s2 * std::cos(w), im = s2 * std::sin(w);
  return std::sqrt(re * re + im * im) / n;
}

static double dominantHz(const float* x, int n, double lo, double hi, double sr = kSr) {
  double best = lo, bm = -1;
  for (double f = lo; f <= hi; f += 1.0) {
    double m = goertzel(x, n, f, sr);
    if (m > bm) { bm = m; best = f; }
  }
  return best;
}

// Energy (sum of squared Goertzel magnitudes) in a frequency band; robust against the +-30 Hz
// sidebands that the two-tap pitch shifter produces.
static double bandEnergy(const float* x, int n, double lo, double hi, double sr = kSr) {
  double e = 0;
  for (double f = lo; f <= hi; f += 3.0) {
    double m = goertzel(x, n, f, sr);
    e += m * m;
  }
  return e;
}

static double rmsOf(const float* x, int n) {
  double s = 0;
  for (int i = 0; i < n; ++i) s += static_cast<double>(x[i]) * x[i];
  return std::sqrt(s / std::max(1, n));
}

static void setNeutral(Engine& e) {
  // Everything that colours the sound off, so a test sees the module under test only.
  e.setParam(P_TAPE_ENABLED, 0);
  e.setParam(P_COMP_ENABLED, 0);
  e.setParam(P_REVERB_MIX, 0);
  e.setParam(P_SHIMMER_MIX, 0);
  e.setParam(P_DELAY_MIX, 0);
  e.setParam(P_ORBIX_ENABLED, 0);
  e.setParam(P_ORBIX_REVERB, 0);
  e.setParam(P_LEVEL_MASTER_DB, 0);
  e.setParam(P_LEVEL_INPUT_DB, 0);
  e.setParam(P_SMOOTH_PARAM_MS, 1);
}

// Renders `secs` of stereo audio; `in` (interleaved stereo, may be null) is fed frame-synchronously.
static std::vector<float> render(Engine& e, float secs, const std::vector<float>* inMono = nullptr,
                                 int chunk = 480) {
  const int total = static_cast<int>(secs * static_cast<float>(e.sampleRate()));
  std::vector<float> out(static_cast<size_t>(total) * 2);
  std::vector<float> in;
  for (int pos = 0; pos < total; pos += chunk) {
    const int n = std::min(chunk, total - pos);
    const float* inp = nullptr;
    if (inMono) {
      in.assign(static_cast<size_t>(n) * 2, 0.f);
      for (int k = 0; k < n; ++k) {
        size_t idx = static_cast<size_t>(pos + k);
        float s = idx < inMono->size() ? (*inMono)[idx] : 0.f;
        in[2 * static_cast<size_t>(k)] = in[2 * static_cast<size_t>(k) + 1] = s;
      }
      inp = in.data();
    }
    e.render(out.data() + 2 * static_cast<size_t>(pos), n, inp);
  }
  return out;
}
static std::vector<float> chan(const std::vector<float>& st, int c) {
  std::vector<float> m(st.size() / 2);
  for (size_t i = 0; i < m.size(); ++i) m[i] = st[2 * i + static_cast<size_t>(c)];
  return m;
}
static bool allFinite(const std::vector<float>& v, float lim = 1.0001f) {
  for (float x : v)
    if (!std::isfinite(x) || std::fabs(x) > lim) return false;
  return true;
}

// ---- tests ----------------------------------------------------------------------------------
static void testRegistry() {
  std::printf("registry\n");
  std::set<std::string> ids;
  for (int i = 0; i < paramCount(); ++i) {
    const ParamInfo& p = paramInfo(i);
    CHECK(ids.insert(p.id).second, "duplicate id %s", p.id);
    CHECK(p.def >= p.min && p.def <= p.max, "%s default %g outside [%g,%g]", p.id, p.def, p.min, p.max);
    CHECK(p.min < p.max, "%s range", p.id);
    CHECK(paramIndex(p.id) == i, "%s lookup", p.id);
    if (p.curve == Curve::Log) CHECK(p.min > 0, "%s log range needs min>0", p.id);
    if (p.kind == Kind::Choice) {
      CHECK(p.choices != nullptr, "%s needs choices", p.id);
      int count = 1;
      for (const char* c = p.choices ? p.choices : ""; *c; ++c) count += (*c == '|');
      CHECK(count == static_cast<int>(p.max - p.min) + 1, "%s has %d labels for range %g..%g", p.id, count,
            p.min, p.max);
    }
    CHECK(p.help && std::strlen(p.help) > 10, "%s help", p.id);
    for (const char* c = p.help; c && *c; ++c) CHECK(static_cast<unsigned char>(*c) < 128, "%s non-ascii help", p.id);
  }
  CHECK(paramIndex("nope") == -1, "unknown id");
  // Every key of the original AMBIENT.json project must exist.
  const char* orig[] = {"comp.attack", "comp.enabled", "comp.gain", "comp.mix", "comp.reduction", "comp.release",
    "delay.feedback", "delay.lowpass", "delay.mix", "delay.pingpong", "delay.spread", "delay.time", "eq.air",
    "eq.high", "eq.hmid", "eq.lmid", "eq.low", "eq.mid", "grain.density", "grain.enabled", "grain.pitch",
    "grain.position", "grain.size", "grain.spray", "level.input_db", "level.master_db", "motion.chaos",
    "motion.elastic", "motion.enabled", "motion.hold", "motion.jump", "motion.reverse", "orbix.attack",
    "orbix.balls", "orbix.bounce", "orbix.enabled", "orbix.gravity", "orbix.instrument", "orbix.octave",
    "orbix.release", "orbix.reverb", "orbix.root", "orbix.rotation", "orbix.scale", "orbix.shape",
    "orbix.volume", "reverb.damp", "reverb.decay", "reverb.diffuse", "reverb.mix", "reverb.mod",
    "reverb.motion", "reverb.predelay", "reverb.size", "reverb.width", "roam.enabled", "roam.mode",
    "roam.range", "roam.smooth", "roam.speed", "roam.wander", "shimmer.dual", "shimmer.feedback",
    "shimmer.mix", "shimmer.shift", "shimmer.smooth", "shimmer.spread", "shimmer.tone",
    "shimmer.voice2_level", "smooth.delay_ms", "smooth.overlap", "smooth.param_ms", "smooth.tail_ms",
    "smooth.xfade_ms", "tape.bit8", "tape.crinkle", "tape.dropout", "tape.enabled", "tape.flutter",
    "tape.hiss", "tape.saturation", "tape.wow", "transport.playing"};
  for (const char* k : orig) CHECK(paramIndex(k) >= 0, "original key missing: %s", k);
}

static void testGranularPitch() {
  std::printf("granular pitch\n");
  auto src = sine(220.f, 4.f, 0.5f);
  for (float semis : {0.f, 12.f, -12.f, 7.f}) {
    Engine e;
    e.prepare(kSr);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
    setNeutral(e);
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_GRAIN_DENSITY, 80);
    e.setParam(P_GRAIN_SIZE, 0.25f);
    e.setParam(P_GRAIN_SPRAY, 0.f);
    e.setParam(P_GRAIN_WIDTH, 0.f);
    e.setParam(P_GRAIN_PITCH, semis);
    e.setParam(P_GRAIN_POSITION, 0.3f);
    e.setParam(P_SMOOTH_OVERLAP, 1.f);
    e.setParam(P_MOTION_ENABLED, 0);
    e.snapParams();
    auto out = chan(render(e, 3.f), 0);
    const double expect = 220.0 * std::pow(2.0, semis / 12.0);
    const double got = dominantHz(out.data() + kSr, kSr, expect * 0.7, expect * 1.4);
    CHECK(std::fabs(got - expect) / expect < 0.04, "pitch %+g: expected %.1f Hz got %.1f Hz", semis, expect, got);
    CHECK(rmsOf(out.data() + kSr, kSr) > 0.02, "pitch %+g: output too quiet", semis);
    CHECK(allFinite(out), "pitch %+g: not finite", semis);
  }
}

static void testStopAndTail() {
  std::printf("transport stop\n");
  auto src = sine(330.f, 4.f, 0.5f);
  Engine e;
  e.prepare(kSr);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_GRAIN_SIZE, 0.2f);
  e.setParam(P_GRAIN_DENSITY, 80);
  e.setParam(P_SMOOTH_TAIL_MS, 100);
  e.snapParams();
  auto a = chan(render(e, 1.5f), 0);
  CHECK(rmsOf(a.data() + kSr, kSr / 2) > 0.02, "should be audible while playing");
  e.setParam(P_TRANSPORT_PLAYING, 0);
  auto b = chan(render(e, 1.5f), 0);
  CHECK(rmsOf(b.data() + kSr, kSr / 2) < 1e-4, "should be silent after stop, got %g", rmsOf(b.data() + kSr, kSr / 2));
  // stopped + tape hiss must stay silent too
  e.setParam(P_TAPE_ENABLED, 1);
  e.setParam(P_TAPE_HISS, 1.f);
  auto c = chan(render(e, 1.0f), 0);
  CHECK(rmsOf(c.data() + kSr / 2, kSr / 2) < 1e-4, "hiss must be gated when stopped, got %g",
        rmsOf(c.data() + kSr / 2, kSr / 2));
}

static void testEq() {
  std::printf("eq\n");
  auto gainDb = [](const char* band, float f, float db) {
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    for (int i : {P_EQ_LOW, P_EQ_LMID, P_EQ_MID, P_EQ_HMID, P_EQ_HIGH, P_EQ_AIR}) P[i] = 0;
    P[paramIndex(band)] = db;
    Eq6 eq;
    eq.prepare(kSr);
    auto x = sine(f, 1.0f, 0.1f);
    std::vector<float> l = x, r = x;
    eq.process(P, l.data(), r.data(), static_cast<int>(l.size()));
    double a = rmsOf(l.data() + kSr / 2, kSr / 2), b = rmsOf(x.data() + kSr / 2, kSr / 2);
    return 20.0 * std::log10(a / b);
  };
  double g;
  g = gainDb("eq.low", 40.f, 12.f);   CHECK(std::fabs(g - 12) < 1.5, "low shelf @40Hz = %.2f dB", g);
  g = gainDb("eq.low", 4000.f, 12.f); CHECK(std::fabs(g) < 0.5, "low shelf leaks @4k = %.2f dB", g);
  g = gainDb("eq.mid", 1000.f, -10.f); CHECK(std::fabs(g + 10) < 0.5, "mid @1k = %.2f dB", g);
  g = gainDb("eq.mid", 100.f, -10.f);  CHECK(std::fabs(g) < 1.5, "mid leaks @100 = %.2f dB", g);
  g = gainDb("eq.high", 16000.f, 9.f); CHECK(std::fabs(g - 9) < 1.5, "high shelf @16k = %.2f dB", g);
  g = gainDb("eq.air", 18000.f, 9.f);  CHECK(g > 6.5, "air @18k = %.2f dB", g);
  g = gainDb("eq.lmid", 250.f, 6.f);   CHECK(std::fabs(g - 6) < 0.5, "lmid @250 = %.2f dB", g);
  g = gainDb("eq.hmid", 3500.f, 6.f);  CHECK(std::fabs(g - 6) < 0.5, "hmid @3.5k = %.2f dB", g);
}

static void testCompressor() {
  std::printf("compressor\n");
  float P[P_COUNT];
  for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
  P[P_COMP_ENABLED] = 1; P[P_COMP_REDUCTION] = 80; P[P_COMP_GAIN] = 0; P[P_COMP_MIX] = 1;
  P[P_COMP_ATTACK] = 1; P[P_COMP_RELEASE] = 100;
  auto run = [&](float amp) {
    Compressor c;
    c.prepare(kSr);
    auto x = sine(440.f, 1.5f, amp);
    std::vector<float> l = x, r = x;
    for (size_t i = 0; i < l.size(); i += 64) c.process(P, l.data() + i, r.data() + i, static_cast<int>(std::min<size_t>(64, l.size() - i)));
    return 20.0 * std::log10(rmsOf(l.data() + kSr, kSr / 4) / rmsOf(x.data() + kSr, kSr / 4));
  };
  double loud = run(0.9f), quiet = run(0.002f);
  CHECK(loud < -6.0, "loud signal should be reduced, got %.2f dB", loud);
  CHECK(std::fabs(quiet) < 0.8, "very quiet signal should pass untouched, got %.2f dB", quiet);
  P[P_COMP_MIX] = 0;
  CHECK(std::fabs(run(0.9f)) < 0.1, "mix 0 = bypass");
}

static void testDelay() {
  std::printf("delay\n");
  float P[P_COUNT];
  for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
  P[P_DELAY_TIME] = 250; P[P_DELAY_FEEDBACK] = 0.5f; P[P_DELAY_MIX] = 1; P[P_DELAY_PINGPONG] = 0;
  P[P_DELAY_SPREAD] = 0; P[P_DELAY_LOWPASS] = 20000;
  StereoDelay d;
  d.prepare(kSr);
  std::vector<float> l(kSr, 0.f), r(kSr, 0.f);
  l[0] = r[0] = 1.f;
  for (size_t i = 0; i < l.size(); i += 64) d.process(P, l.data() + i, r.data() + i, 64);
  const int echo = kSr / 4;
  float peak1 = 0; int at1 = 0;
  for (int i = 100; i < echo * 3 / 2; ++i) if (std::fabs(l[static_cast<size_t>(i)]) > peak1) { peak1 = std::fabs(l[static_cast<size_t>(i)]); at1 = i; }
  CHECK(std::abs(at1 - echo) <= 2, "first echo at %d, expected %d", at1, echo);
  CHECK(peak1 > 0.3f && peak1 < 1.0f, "first echo level %g", peak1);
  float second = 0;
  for (int i = 2 * echo - 3; i <= 2 * echo + 3; ++i) second = std::max(second, std::fabs(l[static_cast<size_t>(i)]));
  CHECK(second > 0.1f && second < peak1, "second echo %g vs first %g", second, peak1);

  // ping-pong: first echo only on the left, second on the right (input centre -> mono mid)
  P[P_DELAY_PINGPONG] = 1;
  StereoDelay d2;
  d2.prepare(kSr);
  std::vector<float> l2(kSr, 0.f), r2(kSr, 0.f);
  l2[0] = 1.f; r2[0] = 0.f;
  for (size_t i = 0; i < l2.size(); i += 64) d2.process(P, l2.data() + i, r2.data() + i, 64);
  float pl = 0, pr2 = 0, pr1 = 0;
  for (int i = echo - 3; i <= echo + 3; ++i) { pl = std::max(pl, std::fabs(l2[static_cast<size_t>(i)])); pr1 = std::max(pr1, std::fabs(r2[static_cast<size_t>(i)])); }
  for (int i = 2 * echo - 3; i <= 2 * echo + 3; ++i) pr2 = std::max(pr2, std::fabs(r2[static_cast<size_t>(i)]));
  CHECK(pl > 0.2f && pr1 < 0.01f, "pingpong: first echo left only (L %.3f R %.3f)", pl, pr1);
  CHECK(pr2 > 0.05f, "pingpong: second echo on the right (%.3f)", pr2);
}

static void testReverbDecay() {
  std::printf("reverb decay\n");
  for (float rt : {1.0f, 3.0f}) {
    Reverb r;
    r.prepare(kSr, 0.1f);
    r.setParams(0.6f, rt, 20000.f, 0.5f, 0.f, 0.f, 0.f, 1.f);
    const int N = static_cast<int>(8 * kSr);
    std::vector<double> e2(static_cast<size_t>(N));
    for (int i = 0; i < N; ++i) {
      float l, rr;
      r.process(i == 0 ? 1.f : 0.f, i == 0 ? 1.f : 0.f, l, rr);
      e2[static_cast<size_t>(i)] = static_cast<double>(l) * l + static_cast<double>(rr) * rr;
    }
    // Schroeder backward integration
    std::vector<double> edc(static_cast<size_t>(N));
    double acc = 0;
    for (int i = N - 1; i >= 0; --i) { acc += e2[static_cast<size_t>(i)]; edc[static_cast<size_t>(i)] = acc; }
    auto at = [&](double db) {
      for (int i = 0; i < N; ++i) if (10.0 * std::log10(edc[static_cast<size_t>(i)] / edc[0]) < db) return static_cast<double>(i) / kSr;
      return 99.0;
    };
    double t5 = at(-5), t35 = at(-35);
    double rt60 = (t35 - t5) * 2.0;
    CHECK(rt60 > rt * 0.6 && rt60 < rt * 1.5, "RT60 target %.1fs measured %.2fs", rt, rt60);
  }
}

// A shimmer has to climb in octaves, not just be a reverb: after a two-note chord the tail must carry
// strong energy one octave above the notes, with feedback up and not with feedback at zero. It must also
// stay bounded on a sustained chord at maximum feedback, and its weight must move upwards with feedback.
static void testShimmerLadder() {
  std::printf("shimmer octave ladder\n");
  auto run = [&](float feedback, bool sustain, int dual, std::vector<float>& out) {
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    P[P_SHIMMER_FEEDBACK] = feedback;
    P[P_SHIMMER_DUAL] = static_cast<float>(dual);
    const size_t total = static_cast<size_t>(kSr) * (sustain ? 12 : 4);
    const size_t noteLen = sustain ? total : static_cast<size_t>(kSr) / 2;
    gb::Shimmer sh;
    sh.prepare(kSr);
    sh.setParams(P);
    out.assign(total, 0.f);
    std::vector<float> a(64), b(64), r(64);
    for (size_t i = 0; i + 64 <= total; i += 64) {
      for (size_t k = 0; k < 64; ++k) {
        const size_t j = i + k;
        const float t = static_cast<float>(j) / kSr;
        const float env = j < noteLen ? std::min(1.f, t / 0.02f) * std::min(1.f, static_cast<float>(noteLen - j) / (0.05f * kSr)) : 0.f;
        a[k] = b[k] = 0.375f * 0.35f * env * (std::sin(6.2831853f * 220.f * t) + std::sin(6.2831853f * 330.f * t));
      }
      sh.processBlock(a.data(), b.data(), out.data() + i, r.data(), 64);
    }
  };
  auto band = [&](const std::vector<float>& x, size_t from, double lo, double hi) {
    const size_t N = 16384;
    auto p = ana::power(x, from, N);
    double e = 0;
    for (size_t i = 1; i < p.size(); ++i) {
      const double f = static_cast<double>(i) * kSr / N;
      if (f >= lo && f < hi) e += p[i];
    }
    return e;
  };
  std::vector<float> y;
  run(0.5f, false, 0, y);
  const size_t at = static_cast<size_t>(kSr) / 2 + kSr / 2;  // 0.5 s after the chord ended
  const double notes = band(y, at, 180, 400), oct1 = band(y, at, 400, 800);
  CHECK(10 * std::log10(oct1 / notes) > -9.0, "feedback 0.5: octave above is only %.1f dB under the notes", 10 * std::log10(oct1 / notes));
  run(0.0f, false, 0, y);
  const double n0 = band(y, at, 180, 400), o0 = band(y, at, 400, 800);
  CHECK(10 * std::log10(o0 / n0) < -30.0, "feedback 0: octave above leaks (%.1f dB)", 10 * std::log10(o0 / n0));
  // and it climbs further: two octaves up must show up too
  run(0.7f, false, 0, y);
  const double oct2 = band(y, at + kSr, 800, 1600), noteLate = band(y, at + kSr, 180, 400);
  CHECK(oct2 > noteLate, "feedback 0.7: after 1.5 s the 2nd octave should outweigh the notes");
  // dual: a voice goes down as well, so energy appears below the notes
  run(0.7f, false, 1, y);
  const double below = band(y, at + kSr / 2, 90, 180);
  CHECK(below > 0.0, "dual produces an octave below");
  // bounded at the maximum feedback with a never-ending chord
  run(0.95f, true, 1, y);
  float pk = 0;
  for (float v : y) { CHECK(std::isfinite(v), "NaN in the shimmer loop"); pk = std::max(pk, std::fabs(v)); }
  CHECK(pk < 1.5f, "shimmer loop must stay bounded, peak %.2f", pk);
}

static void testShimmer() {
  std::printf("shimmer\n");

  // --- one pitch-shift voice -------------------------------------------------------------------
  {
    StShifter v;
    CHECK(v.prepare(kSr) && v.ok(), "SoundTouch voice must be created");
    v.setPitch(7.f);
    const double target = 440.0 * std::pow(2.0, 7.0 / 12.0);
    auto x = sine(440.f, 5.f, 0.3f);
    std::vector<float> y(x.size());
    std::vector<float> yr(x.size());
    for (size_t i = 0; i + 64 <= x.size(); i += 64) v.process(x.data() + i, x.data() + i, y.data() + i, yr.data() + i, 64);
    size_t first = 0;
    while (first < y.size() && y[first] == 0.f) ++first;
    CHECK(first > 0 && first < static_cast<size_t>(0.4 * kSr), "voice latency %.0f ms", 1000.0 * static_cast<double>(first) / kSr);
    const float* tail = y.data() + 3 * kSr;
    double hz = dominantHz(tail, kSr, 600, 720);
    CHECK(std::fabs(hz - target) < 2.0, "shifted pitch %.1f Hz, wanted %.1f", hz, target);
    double eTarget = bandEnergy(tail, kSr, target - 25, target + 25);
    double eAll = bandEnergy(tail, kSr, 100, 4000);
    CHECK(eTarget > 0.97 * eAll, "only %.1f%% of the energy sits at the target pitch", 100 * eTarget / eAll);
    double eSrc = bandEnergy(tail, kSr, 400, 480);
    CHECK(eSrc < 0.002 * eTarget, "voice leaks the source pitch");
    int run = 0, longest = 0;  // after it started, the stream must never run dry
    for (size_t i = first + kSr; i < y.size(); ++i) { run = (y[i] == 0.f) ? run + 1 : 0; longest = std::max(longest, run); }
    CHECK(longest < 8, "voice output ran dry for %d samples", longest);
  }

  // --- the loop at its most extreme must stay bounded and finite -------------------------------------
  {
    Engine e;
    e.prepare(kSr);
    setNeutral(e);
    e.setParam(P_SHIMMER_MIX, 1.f);
    e.setParam(P_SHIMMER_FEEDBACK, 0.95f);
    e.setParam(P_SHIMMER_SHIFT, 24.f);
    e.setParam(P_SHIMMER_DUAL, 1);
    e.setParam(P_SHIMMER_VOICE2, 1.f);
    e.setParam(P_SHIMMER_TONE, 20000.f);
    e.setParam(P_SHIMMER_SMOOTH, 1.f);
    e.setParam(P_LIVE_LEVEL, 1.f);
    e.snapParams();
    Rng rng(7);
    std::vector<float> noise(static_cast<size_t>(4 * kSr));
    for (auto& n : noise) n = rng.bi() * 0.5f;
    auto out = render(e, 14.f, &noise);
    CHECK(allFinite(out), "extreme shimmer must stay finite and below full scale");
    CHECK(rmsOf(out.data() + 13 * 2 * kSr, kSr) < 0.7, "extreme shimmer tail level %.3f", rmsOf(out.data() + 13 * 2 * kSr, kSr));
  }

  // --- a NaN inside the loop must not poison it forever ------------------------------------------------
  {
    Shimmer sh;
    sh.prepare(kSr);
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    P[P_SHIMMER_DUAL] = 1;
    sh.setParams(P);
    std::vector<float> inL(64, 0.1f), inR(64, 0.1f), oL(64), oR(64);
    for (int b = 0; b < 200; ++b) sh.processBlock(inL.data(), inR.data(), oL.data(), oR.data(), 64);
    inL[10] = std::nanf("");
    sh.processBlock(inL.data(), inR.data(), oL.data(), oR.data(), 64);
    inL[10] = 0.1f;
    bool finite = true;
    for (int b = 0; b < 400; ++b) {
      sh.processBlock(inL.data(), inR.data(), oL.data(), oR.data(), 64);
      for (int i = 0; i < 64; ++i) finite = finite && std::isfinite(oL[static_cast<size_t>(i)]) && std::isfinite(oR[static_cast<size_t>(i)]);
    }
    CHECK(finite, "shimmer did not recover from NaN input");
  }

  // --- real-time safety: no allocation while parameters sweep ---------------------------------------
  {
    Engine e;
    e.prepare(kSr);
    setNeutral(e);
    e.setParam(P_SHIMMER_MIX, 0.8f);
    e.setParam(P_SHIMMER_DUAL, 1);
    e.setParam(P_LIVE_LEVEL, 1.f);
    e.snapParams();
    std::vector<float> in(480 * 2, 0.2f), out(480 * 2);
    for (int i = 0; i < 480; ++i) in[static_cast<size_t>(2 * i)] = in[static_cast<size_t>(2 * i + 1)] = 0.3f * std::sin(0.05f * static_cast<float>(i));
    // settle first (lazy first-use work, if any, must not count)
    for (int c = 0; c < 20; ++c) e.render(out.data(), 480, in.data());
    g_allocs = 0;
    g_countAllocs = true;
    for (int c = 0; c < 1000; ++c) {  // 10 s
      const float ph = static_cast<float>(c) / 1000.f;
      e.setParam(P_SHIMMER_SHIFT, -12.f + 36.f * ph);
      e.setParam(P_SHIMMER_SMOOTH, 0.5f + 0.5f * std::sin(ph * 40.f));
      e.setParam(P_SHIMMER_DUAL, (c / 200) % 2);
      e.setParam(P_SHIMMER_TONE, 500.f + 19000.f * ph);
      e.setParam(P_SHIMMER_FEEDBACK, 0.3f + 0.65f * ph);
      e.render(out.data(), 480, in.data());
    }
    g_countAllocs = false;
    CHECK(g_allocs.load() == 0, "%ld heap allocations on the audio thread during a shimmer sweep", g_allocs.load());
  }

  // --- full engine: the shifted octave must show up in the tail (A/B against feedback = 0) -----------------
  // Band-limited noise, not a sine: with a 6 s reverb tail a lone sine mostly falls between the
  // (very narrow) modes of the reverb and says little about the loop.
  {
    Rng rng(99);
    std::vector<float> low(static_cast<size_t>(3 * kSr));
    float a = 0, b = 0, c = 0, d = 0;
    const float k = 1.f - std::exp(-kTwoPi * 180.f / static_cast<float>(kSr));
    for (auto& x : low) { a += k * (rng.bi() - a); b += k * (a - b); c += k * (b - c); d += k * (c - d); x = d; }
    float pk = 0;
    for (float x : low) pk = std::max(pk, std::fabs(x));
    for (auto& x : low) x *= 0.5f / pk;
    auto run = [&](float feedback) {
      Engine e;
      e.prepare(kSr);
      setNeutral(e);
      e.setParam(P_SHIMMER_MIX, 1.f);
      e.setParam(P_SHIMMER_FEEDBACK, feedback);
      e.setParam(P_SHIMMER_SHIFT, 12.f);
      e.setParam(P_SHIMMER_DUAL, 0);
      e.setParam(P_LIVE_LEVEL, 1.f);
      e.snapParams();
      auto out = chan(render(e, 6.f, &low), 0);
      const float* tail = out.data() + static_cast<size_t>(3.4 * kSr);
      struct R { double src, oct, rms; } r{bandEnergy(tail, 2 * kSr, 100, 300), bandEnergy(tail, 2 * kSr, 450, 900), rmsOf(tail, kSr)};
      return std::make_pair(r, allFinite(out));
    };
    auto fb = run(0.7f), nofb = run(0.f);
    CHECK(fb.second && nofb.second, "shimmer finite");
    CHECK(nofb.first.src > 1e-9, "shimmer wet path carries the source");
    CHECK(fb.first.oct > 8.0 * nofb.first.oct, "octave band with feedback %.3g vs without %.3g: no shifted energy", fb.first.oct, nofb.first.oct);
    CHECK(fb.first.rms > 1e-4, "shimmer tail should still ring");
  }
}

static void testTape() {
  std::printf("tape\n");
  auto run = [](float wow, float flutter) {
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    P[P_TAPE_ENABLED] = 1; P[P_TAPE_WOW] = wow; P[P_TAPE_FLUTTER] = flutter; P[P_TAPE_HISS] = 0;
    P[P_TAPE_SATURATION] = 0; P[P_TAPE_CRINKLE] = 0; P[P_TAPE_DROPOUT] = 0; P[P_TAPE_BIT8] = 0;
    Tape t;
    t.prepare(kSr);
    auto x = sine(1000.f, 4.f, 0.3f);
    std::vector<float> l = x, r = x;
    for (size_t i = 0; i < l.size(); i += 64) t.process(P, l.data() + i, r.data() + i, 64);
    // Estimate instantaneous frequency via zero crossings in 50 ms windows after settling.
    double lo = 1e9, hi = -1e9;
    const int win = kSr / 20;
    for (int s = kSr; s + win < static_cast<int>(l.size()); s += win / 2) {
      int z = 0;
      for (int i = s + 1; i < s + win; ++i) if ((l[static_cast<size_t>(i - 1)] < 0) != (l[static_cast<size_t>(i)] < 0)) ++z;
      double hz = z * 0.5 / (static_cast<double>(win) / kSr);
      lo = std::min(lo, hz); hi = std::max(hi, hz);
    }
    return hi - lo;
  };
  double none = run(0, 0), wow = run(1.f, 0.f), flut = run(0.f, 1.f);
  CHECK(none < 25.0, "no modulation should be steady, spread %.1f Hz", none);
  CHECK(wow > none + 10.0, "wow should wobble pitch: %.1f vs %.1f Hz", wow, none);
  CHECK(flut > none + 3.0, "flutter should wobble pitch: %.1f vs %.1f Hz", flut, none);
}

static void testOrbix() {
  std::printf("orbix\n");
  auto src = sine(261.6f, 2.f, 0.4f);
  for (int inst = 0; inst < 4; ++inst) {
    Engine e;
    e.prepare(kSr);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
    setNeutral(e);
    e.setParam(P_GRAIN_ENABLED, 0);
    e.setParam(P_ORBIX_ENABLED, 1);
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_ORBIX_INSTRUMENT, static_cast<float>(inst));
    e.setParam(P_ORBIX_BALLS, 6);
    e.setParam(P_ORBIX_VOLUME, 80);
    e.setParam(P_ORBIX_ROTATION, 50);
    e.setParam(P_ORBIX_RELEASE, 300);
    e.snapParams();
    int maxVoices = 0;
    double rms = 0; int cnt = 0;
    float st[Engine::kStateSize];
    bool inside = true;
    for (int s = 0; s < 20; ++s) {
      auto o = chan(render(e, 0.5f), 0);
      rms += rmsOf(o.data(), static_cast<int>(o.size())); ++cnt;
      e.getState(st, Engine::kStateSize);
      maxVoices = std::max(maxVoices, static_cast<int>(st[6]));
      const float* ob = st + Engine::kStateHeader + Granular::kMaxGrains;
      int nb = static_cast<int>(ob[2]);
      for (int b = 0; b < nb; ++b) {
        float x = ob[3 + 3 * b], y = ob[4 + 3 * b];
        if (!std::isfinite(x) || !std::isfinite(y) || x * x + y * y > 1.2f) inside = false;
      }
      CHECK(nb == 6, "ball count %d", nb);
    }
    CHECK(maxVoices > 0, "instrument %d: no notes played", inst);
    CHECK(rms / cnt > 0.003, "instrument %d: too quiet (%.5f)", inst, rms / cnt);
    CHECK(inside, "instrument %d: a ball left the arena", inst);
  }
  // Stopping the transport must stop new notes, ringing voices must end.
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  e.setParam(P_GRAIN_ENABLED, 0);
  e.setParam(P_ORBIX_ENABLED, 1);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_ORBIX_INSTRUMENT, 0);
  e.setParam(P_ORBIX_RELEASE, 100);
  e.snapParams();
  render(e, 3.f);
  e.setParam(P_TRANSPORT_PLAYING, 0);
  render(e, 3.f);
  auto o = chan(render(e, 1.f), 0);
  CHECK(rmsOf(o.data(), static_cast<int>(o.size())) < 1e-4, "orbix silent after stop");
}

static void testLimiterAndFinite() {
  std::printf("limiter / loud input\n");
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  e.setParam(P_LIVE_LEVEL, 1.f);
  e.setParam(P_LEVEL_INPUT_DB, 24.f);
  e.setParam(P_LEVEL_MASTER_DB, 12.f);
  e.snapParams();
  auto in = sine(100.f, 2.f, 1.0f);
  auto out = render(e, 2.f, &in);
  CHECK(allFinite(out, 1.0f), "output must never exceed full scale");
  CHECK(rmsOf(out.data(), static_cast<int>(out.size())) > 0.3, "loud output expected");
}

static void testRecording() {
  std::printf("recording\n");
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  CHECK(e.startRecording(), "start");
  CHECK(!e.startRecording(), "double start rejected");
  auto in = sine(500.f, 1.0f, 0.4f);
  // The input thread delivers odd-sized blocks, the output callback runs at its own cadence (and
  // may even see no input at all): the recording must still be complete and bit-exact.
  {
    std::vector<float> inter(in.size() * 2);
    for (size_t i = 0; i < in.size(); ++i) inter[2 * i] = inter[2 * i + 1] = in[i];
    size_t pos = 0;
    int chunk = 97;
    while (pos < in.size()) {
      const size_t n = std::min<size_t>(static_cast<size_t>(chunk), in.size() - pos);
      e.recordInput(inter.data() + 2 * pos, static_cast<int>(n));
      pos += n;
      chunk = chunk == 97 ? 480 : (chunk == 480 ? 33 : 97);
      std::vector<float> o(2 * 128);
      e.render(o.data(), 128, nullptr);  // output side is independent of what the input thread did
    }
  }
  e.stopRecording();
  {
    std::vector<float> junk(2 * 256, 0.9f);
    e.recordInput(junk.data(), 256);  // after stop: ignored
  }
  const int fr = e.recordedFrames();
  CHECK(fr == kSr, "recorded %d frames, expected %d", fr, kSr);
  std::vector<float> got(static_cast<size_t>(fr) * 2);
  CHECK(e.copyRecording(got.data(), fr) == fr, "copy");
  double err = 0;
  for (int i = 0; i < fr; ++i) {
    err = std::max(err, static_cast<double>(std::fabs(got[2 * static_cast<size_t>(i)] - in[static_cast<size_t>(i)])));
    err = std::max(err, static_cast<double>(std::fabs(got[2 * static_cast<size_t>(i) + 1] - in[static_cast<size_t>(i)])));
  }
  CHECK(err < 1e-6, "recording must be bit-exact, err %g", err);
  CHECK(std::fabs(e.recordingSampleRate() - kSr) < 0.5, "rate defaults to the output rate");

  // render() must not record on its own any more (that path used to lose audio)
  CHECK(e.startRecording(), "restart");
  CHECK(e.recordedFrames() == 0, "a new take starts empty");
  render(e, 0.5f, &in);
  CHECK(e.recordedFrames() == 0, "the output callback does not feed the recording");

  // the input stream's real rate is what the recording is saved at
  e.stopRecording();
  e.setInputSampleRate(44100);
  CHECK(e.startRecording(), "start at 44.1k");
  CHECK(std::fabs(e.recordingSampleRate() - 44100.0) < 0.5, "recording rate follows the input stream");
  std::vector<float> nan(2 * 64, 0.25f);
  nan[10] = std::nanf("");
  nan[11] = INFINITY;
  e.recordInput(nan.data(), 64);
  std::vector<float> back(2 * 64);
  CHECK(e.copyRecording(back.data(), 64) == 64, "copy 64");
  CHECK(back[10] == 0.f && back[11] == 0.f && back[12] == 0.25f, "non-finite samples are replaced by silence");

  // the buffer fills up: recording stops by itself at the limit and nothing is written past it
  e.stopRecording();
  e.setInputSampleRate(0);
  CHECK(e.startRecording(), "start for the limit");
  std::vector<float> blk(2 * 4800, 0.1f);
  const int limit = kSr * Engine::kMaxRecSeconds;
  for (int i = 0; i < limit / 4800 + 3; ++i) e.recordInput(blk.data(), 4800);
  CHECK(!e.isRecording(), "recording ends when the buffer is full");
  CHECK(e.recordedFrames() == limit, "limit %d, recorded %d", limit, e.recordedFrames());
}

static void testSampleRates() {
  std::printf("sample rates\n");
  auto src = sine(200.f, 3.f, 0.5f, 44100);
  for (int sr : {22050, 44100, 48000, 96000}) {
    Engine e;
    e.prepare(sr);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), 44100);
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_ORBIX_ENABLED, 1);
    e.setParam(P_SHIMMER_MIX, 0.5f);
    e.setParam(P_REVERB_MIX, 0.5f);
    e.snapParams();
    auto out = render(e, 3.f);
    CHECK(allFinite(out), "sr %d finite", sr);
    CHECK(rmsOf(out.data(), static_cast<int>(out.size())) > 0.005, "sr %d audible", sr);
  }
  // sample rate conversion of grains: a 44.1k sample played at 48k keeps its pitch
  Engine e;
  e.prepare(48000);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), 44100);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_GRAIN_SIZE, 0.25f);
  e.setParam(P_GRAIN_DENSITY, 80);
  e.setParam(P_GRAIN_SPRAY, 0.f);
  e.setParam(P_SMOOTH_OVERLAP, 1.f);
  e.snapParams();
  auto o = chan(render(e, 3.f), 0);
  double f = dominantHz(o.data() + kSr, kSr, 150, 260);
  CHECK(std::fabs(f - 200.0) < 4.0, "44.1k->48k pitch kept: %.1f Hz", f);
}

static void testRoamAndMotion() {
  std::printf("roam / motion\n");
  auto src = sine(220.f, 4.f, 0.5f);
  Engine e;
  e.prepare(kSr);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_ROAM_ENABLED, 1);
  e.setParam(P_ROAM_MODE, 0);
  e.setParam(P_ROAM_RANGE, 1.f);
  e.setParam(P_ROAM_SPEED, 0.5f);
  e.setParam(P_ROAM_SMOOTH, 0.f);
  e.snapParams();
  float lo = 2, hi = -1, st[Engine::kStateSize];
  for (int i = 0; i < 40; ++i) {
    render(e, 0.1f);
    e.getState(st, Engine::kStateSize);
    lo = std::min(lo, st[0]); hi = std::max(hi, st[0]);
  }
  CHECK(hi - lo > 0.4f, "roam should move the playhead: %.2f..%.2f", lo, hi);
  e.setParam(P_MOTION_HOLD, 1.f);
  render(e, 1.0f);
  e.getState(st, Engine::kStateSize);
  float p0 = st[0];
  render(e, 1.0f);
  e.getState(st, Engine::kStateSize);
  CHECK(std::fabs(st[0] - p0) < 0.02f, "hold freezes roam: %.3f -> %.3f", p0, st[0]);
  CHECK(st[8] > 0.f && st[8] < 1.0f, "DSP load meter should be a sane fraction of real time, got %.3f", st[8]);
  CHECK(Engine::kStateHeader == 12 && Engine::kStateSize == 12 + 64 + 51, "state layout is mirrored in EngineState.kt");
}

static void testFuzzAllParams() {
  std::printf("fuzz: random parameter sets\n");
  auto src = sine(180.f, 2.f, 0.5f);
  Rng rng(1234);
  for (int iter = 0; iter < 40; ++iter) {
    Engine e;
    e.prepare(iter % 3 == 0 ? 44100 : 48000);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
    for (int p = 0; p < P_COUNT; ++p) {
      const ParamInfo& pi = paramInfo(p);
      float v;
      float r = rng.uni();
      if (iter % 4 == 0) v = (r < 0.5f) ? pi.min : pi.max;  // extremes
      else v = pi.min + (pi.max - pi.min) * r;
      e.setParam(p, v);
    }
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_ORBIX_ENABLED, 1);
    e.snapParams();
    auto in = sine(300.f, 3.f, 0.5f);
    auto out = render(e, 3.f, &in, 37 + iter);  // odd chunk sizes on purpose
    bool ok = allFinite(out, 1.0f);
    CHECK(ok, "fuzz iter %d produced non-finite or clipped output", iter);
    if (!ok) {
      for (int p = 0; p < P_COUNT; ++p) std::printf("    %s=%g\n", paramInfo(p).id, e.getParam(p));
      break;
    }
  }
}

static void testSamplePublishRace() {
  std::printf("sample hand-over under load\n");
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_ORBIX_ENABLED, 1);
  e.setParam(P_ORBIX_INSTRUMENT, 3);
  e.snapParams();
  std::atomic<bool> stop{false};
  std::atomic<int> rendered{0};
  std::thread audio([&] {
    std::vector<float> buf(2 * 128);
    while (!stop.load()) {
      e.render(buf.data(), 128, nullptr);
      rendered.fetch_add(1);
    }
  });
  for (int i = 0; i < 300; ++i) {
    auto s = sine(100.f + static_cast<float>(i), 0.2f + 0.001f * static_cast<float>(i % 7), 0.3f);
    e.publishSample(s.data(), s.data(), static_cast<int>(s.size()), kSr);
    std::this_thread::sleep_for(std::chrono::microseconds(300));
  }
  stop = true;
  audio.join();
  CHECK(rendered.load() > 100, "audio thread kept running (%d blocks)", rendered.load());
}

static void testPerf() {
  std::printf("performance\n");
  auto src = sine(150.f, 6.f, 0.5f);
  Engine e;
  e.prepare(kSr);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_GRAIN_DENSITY, 100);
  e.setParam(P_GRAIN_SIZE, 4.f);
  e.setParam(P_ORBIX_ENABLED, 1);
  e.setParam(P_ORBIX_BALLS, 16);
  e.setParam(P_SHIMMER_MIX, 0.7f);
  e.setParam(P_SHIMMER_DUAL, 1);
  e.setParam(P_REVERB_MIX, 0.8f);
  e.setParam(P_DELAY_MIX, 0.5f);
  e.snapParams();
  auto t0 = std::chrono::steady_clock::now();
  render(e, 20.f);
  double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::printf("  worst case: 20 s of audio in %.2f s  (%.1fx real time)\n", dt, 20.0 / dt);
#if defined(__SANITIZE_ADDRESS__) || defined(__SANITIZE_THREAD__)
  (void)dt;  // sanitizer builds are far slower; the number is only meaningful for plain -O2 builds
#else
  CHECK(20.0 / dt > 5.0, "engine should be >5x real time on the host, got %.1fx", 20.0 / dt);  // sanity bound, machine dependent
#endif
}

int main() {
  testRegistry();
  testGranularPitch();
  testStopAndTail();
  testEq();
  testCompressor();
  testDelay();
  testReverbDecay();
  testShimmer();
  testShimmerLadder();
  testTape();
  testOrbix();
  testLimiterAndFinite();
  testRecording();
  testSampleRates();
  testRoamAndMotion();
  testFuzzAllParams();
  testSamplePublishRace();
  testPerf();
  std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
  return g_fail ? 1 : 0;
}
