// Host-side tests for the GrainBrick DSP engine. Uses only synthetic signals.
//   g++ -std=c++17 -O2 engine_test.cpp ../../app/src/main/cpp/engine/{engine,params}.cpp -pthread
#include <atomic>
#include <new>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>
#include <thread>

#include "fft.h"
#include "../../app/src/main/cpp/engine/engine.h"
#include "../../app/src/main/cpp/engine/reverb.h"
#include "../../app/src/main/cpp/engine/orbix_params.h"

using namespace gb;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond, ...)                                              \
  do {                                                                \
    ++g_checks;                                                       \
    if (!(cond)) {                                                    \
      ++g_fail;                                                       \
      std::printf("  FAIL %s:%d  %s  -- ", __FILE__, __LINE__, #cond); \
      std::printf(__VA_ARGS__);                                       \
      std::printf("\n");                                              \
    }                                                                 \
  } while (0)

static constexpr int kSr = 48000;

// ---- allocation counter: the audio path must not allocate once prepared --------------------------
static std::atomic<long> g_allocs{0};
static std::atomic<bool> g_countAllocs{false};
void* operator new(std::size_t n) {
  if (g_countAllocs.load(std::memory_order_relaxed)) g_allocs.fetch_add(1, std::memory_order_relaxed);
  void* p = std::malloc(n ? n : 1);
  if (!p) throw std::bad_alloc();
  return p;
}
void* operator new[](std::size_t n) { return operator new(n); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }

// ---- helpers --------------------------------------------------------------------------------
static std::vector<float> sine(float hz, float secs, float amp = 0.5f, int sr = kSr) {
  std::vector<float> v(static_cast<size_t>(secs * static_cast<float>(sr)));
  for (size_t i = 0; i < v.size(); ++i)
    v[i] = amp * std::sin(kTwoPi * hz * static_cast<float>(i) / static_cast<float>(sr));
  return v;
}

static double goertzel(const float* x, int n, double hz, double sr) {
  const double w = 2.0 * M_PI * hz / sr, c = 2.0 * std::cos(w);
  double s1 = 0, s2 = 0;
  for (int i = 0; i < n; ++i) {
    double win = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / (n - 1));  // Hann
    double s = x[i] * win + c * s1 - s2;
    s2 = s1;
    s1 = s;
  }
  double re = s1 - s2 * std::cos(w), im = s2 * std::sin(w);
  return std::sqrt(re * re + im * im) / n;
}

static double dominantHz(const float* x, int n, double lo, double hi, double sr = kSr) {
  double best = lo, bm = -1;
  for (double f = lo; f <= hi; f += 1.0) {
    double m = goertzel(x, n, f, sr);
    if (m > bm) { bm = m; best = f; }
  }
  return best;
}

// Energy (sum of squared Goertzel magnitudes) in a frequency band; robust against the +-30 Hz
// sidebands that the two-tap pitch shifter produces.
static double bandEnergy(const float* x, int n, double lo, double hi, double sr = kSr) {
  double e = 0;
  for (double f = lo; f <= hi; f += 3.0) {
    double m = goertzel(x, n, f, sr);
    e += m * m;
  }
  return e;
}

static double rmsOf(const float* x, int n) {
  double s = 0;
  for (int i = 0; i < n; ++i) s += static_cast<double>(x[i]) * x[i];
  return std::sqrt(s / std::max(1, n));
}

static void setNeutral(Engine& e) {
  // Everything that colours the sound off, so a test sees the module under test only.
  e.setParam(P_TAPE_ENABLED, 0);
  e.setParam(P_COMP_ENABLED, 0);
  e.setParam(P_REVERB_MIX, 0);
  e.setParam(P_SHIMMER_MIX, 0);
  e.setParam(P_DELAY_MIX, 0);
  e.setParam(P_ORBIX_ENABLED, 0);
  e.setParam(P_ORBIX_REVERB, 0);
  e.setParam(P_LEVEL_MASTER_DB, 0);
  e.setParam(P_LEVEL_INPUT_DB, 0);
  e.setParam(P_SMOOTH_PARAM_MS, 1);
}

// Renders `secs` of stereo audio; `in` (interleaved stereo, may be null) is fed frame-synchronously.
static std::vector<float> render(Engine& e, float secs, const std::vector<float>* inMono = nullptr,
                                 int chunk = 480) {
  const int total = static_cast<int>(secs * static_cast<float>(e.sampleRate()));
  std::vector<float> out(static_cast<size_t>(total) * 2);
  std::vector<float> in;
  for (int pos = 0; pos < total; pos += chunk) {
    const int n = std::min(chunk, total - pos);
    const float* inp = nullptr;
    if (inMono) {
      in.assign(static_cast<size_t>(n) * 2, 0.f);
      for (int k = 0; k < n; ++k) {
        size_t idx = static_cast<size_t>(pos + k);
        float s = idx < inMono->size() ? (*inMono)[idx] : 0.f;
        in[2 * static_cast<size_t>(k)] = in[2 * static_cast<size_t>(k) + 1] = s;
      }
      inp = in.data();
    }
    e.render(out.data() + 2 * static_cast<size_t>(pos), n, inp);
  }
  return out;
}
static std::vector<float> chan(const std::vector<float>& st, int c) {
  std::vector<float> m(st.size() / 2);
  for (size_t i = 0; i < m.size(); ++i) m[i] = st[2 * i + static_cast<size_t>(c)];
  return m;
}
static bool allFinite(const std::vector<float>& v, float lim = 1.0001f) {
  for (float x : v)
    if (!std::isfinite(x) || std::fabs(x) > lim) return false;
  return true;
}

// ---- tests ----------------------------------------------------------------------------------
static void testRegistry() {
  std::printf("registry\n");
  std::set<std::string> ids;
  for (int i = 0; i < paramCount(); ++i) {
    const ParamInfo& p = paramInfo(i);
    CHECK(ids.insert(p.id).second, "duplicate id %s", p.id);
    CHECK(p.def >= p.min && p.def <= p.max, "%s default %g outside [%g,%g]", p.id, p.def, p.min, p.max);
    CHECK(p.min < p.max, "%s range", p.id);
    CHECK(paramIndex(p.id) == i, "%s lookup", p.id);
    if (p.curve == Curve::Log) CHECK(p.min > 0, "%s log range needs min>0", p.id);
    if (p.kind == Kind::Choice) {
      CHECK(p.choices != nullptr, "%s needs choices", p.id);
      int count = 1;
      for (const char* c = p.choices ? p.choices : ""; *c; ++c) count += (*c == '|');
      CHECK(count == static_cast<int>(p.max - p.min) + 1, "%s has %d labels for range %g..%g", p.id, count,
            p.min, p.max);
    }
    CHECK(p.help && std::strlen(p.help) > 10, "%s help", p.id);
    for (const char* c = p.help; c && *c; ++c) CHECK(static_cast<unsigned char>(*c) < 128, "%s non-ascii help", p.id);
  }
  CHECK(paramIndex("nope") == -1, "unknown id");
  // Every key of the original AMBIENT.json project must exist.
  const char* orig[] = {"comp.attack", "comp.enabled", "comp.gain", "comp.mix", "comp.reduction", "comp.release",
    "delay.feedback", "delay.lowpass", "delay.mix", "delay.pingpong", "delay.spread", "delay.time", "eq.air",
    "eq.high", "eq.hmid", "eq.lmid", "eq.low", "eq.mid", "grain.density", "grain.enabled", "grain.pitch",
    "grain.position", "grain.size", "grain.spray", "level.input_db", "level.master_db", "motion.chaos",
    "motion.elastic", "motion.enabled", "motion.hold", "motion.jump", "motion.reverse", "orbix.attack",
    "orbix.balls", "orbix.bounce", "orbix.enabled", "orbix.gravity", "orbix.instrument", "orbix.octave",
    "orbix.release", "orbix.reverb", "orbix.root", "orbix.rotation", "orbix.scale", "orbix.shape",
    "orbix.volume", "reverb.damp", "reverb.decay", "reverb.diffuse", "reverb.mix", "reverb.mod",
    "reverb.motion", "reverb.predelay", "reverb.size", "reverb.width", "roam.enabled", "roam.mode",
    "roam.range", "roam.smooth", "roam.speed", "roam.wander", "shimmer.dual", "shimmer.feedback",
    "shimmer.mix", "shimmer.shift", "shimmer.smooth", "shimmer.spread", "shimmer.tone",
    "shimmer.voice2_level", "smooth.delay_ms", "smooth.overlap", "smooth.param_ms", "smooth.tail_ms",
    "smooth.xfade_ms", "tape.bit8", "tape.crinkle", "tape.dropout", "tape.enabled", "tape.flutter",
    "tape.hiss", "tape.saturation", "tape.wow", "transport.playing"};
  for (const char* k : orig) CHECK(paramIndex(k) >= 0, "original key missing: %s", k);
}

static void testGranularPitch() {
  std::printf("granular pitch\n");
  auto src = sine(220.f, 4.f, 0.5f);
  for (float semis : {0.f, 12.f, -12.f, 7.f}) {
    Engine e;
    e.prepare(kSr);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
    setNeutral(e);
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_GRAIN_DENSITY, 80);
    e.setParam(P_GRAIN_SIZE, 0.25f);
    e.setParam(P_GRAIN_SPRAY, 0.f);
    e.setParam(P_GRAIN_WIDTH, 0.f);
    e.setParam(P_GRAIN_PITCH, semis);
    e.setParam(P_GRAIN_POSITION, 0.3f);
    e.setParam(P_SMOOTH_OVERLAP, 1.f);
    e.setParam(P_MOTION_ENABLED, 0);
    e.snapParams();
    auto out = chan(render(e, 3.f), 0);
    const double expect = 220.0 * std::pow(2.0, semis / 12.0);
    const double got = dominantHz(out.data() + kSr, kSr, expect * 0.7, expect * 1.4);
    CHECK(std::fabs(got - expect) / expect < 0.04, "pitch %+g: expected %.1f Hz got %.1f Hz", semis, expect, got);
    CHECK(rmsOf(out.data() + kSr, kSr) > 0.02, "pitch %+g: output too quiet", semis);
    CHECK(allFinite(out), "pitch %+g: not finite", semis);
  }
}

static void testStopAndTail() {
  std::printf("transport stop\n");
  auto src = sine(330.f, 4.f, 0.5f);
  Engine e;
  e.prepare(kSr);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_GRAIN_SIZE, 0.2f);
  e.setParam(P_GRAIN_DENSITY, 80);
  e.setParam(P_SMOOTH_TAIL_MS, 100);
  e.snapParams();
  auto a = chan(render(e, 1.5f), 0);
  CHECK(rmsOf(a.data() + kSr, kSr / 2) > 0.02, "should be audible while playing");
  e.setParam(P_TRANSPORT_PLAYING, 0);
  auto b = chan(render(e, 1.5f), 0);
  CHECK(rmsOf(b.data() + kSr, kSr / 2) < 1e-4, "should be silent after stop, got %g", rmsOf(b.data() + kSr, kSr / 2));
  // stopped + tape hiss must stay silent too
  e.setParam(P_TAPE_ENABLED, 1);
  e.setParam(P_TAPE_HISS, 1.f);
  auto c = chan(render(e, 1.0f), 0);
  CHECK(rmsOf(c.data() + kSr / 2, kSr / 2) < 1e-4, "hiss must be gated when stopped, got %g",
        rmsOf(c.data() + kSr / 2, kSr / 2));
}

static void testEq() {
  std::printf("eq\n");
  auto gainDb = [](const char* band, float f, float db) {
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    for (int i : {P_EQ_LOW, P_EQ_LMID, P_EQ_MID, P_EQ_HMID, P_EQ_HIGH, P_EQ_AIR}) P[i] = 0;
    P[paramIndex(band)] = db;
    Eq6 eq;
    eq.prepare(kSr);
    auto x = sine(f, 1.0f, 0.1f);
    std::vector<float> l = x, r = x;
    eq.process(P, l.data(), r.data(), static_cast<int>(l.size()));
    double a = rmsOf(l.data() + kSr / 2, kSr / 2), b = rmsOf(x.data() + kSr / 2, kSr / 2);
    return 20.0 * std::log10(a / b);
  };
  double g;
  g = gainDb("eq.low", 40.f, 12.f);   CHECK(std::fabs(g - 12) < 1.5, "low shelf @40Hz = %.2f dB", g);
  g = gainDb("eq.low", 4000.f, 12.f); CHECK(std::fabs(g) < 0.5, "low shelf leaks @4k = %.2f dB", g);
  g = gainDb("eq.mid", 1000.f, -10.f); CHECK(std::fabs(g + 10) < 0.5, "mid @1k = %.2f dB", g);
  g = gainDb("eq.mid", 100.f, -10.f);  CHECK(std::fabs(g) < 1.5, "mid leaks @100 = %.2f dB", g);
  g = gainDb("eq.high", 16000.f, 9.f); CHECK(std::fabs(g - 9) < 1.5, "high shelf @16k = %.2f dB", g);
  g = gainDb("eq.air", 18000.f, 9.f);  CHECK(g > 6.5, "air @18k = %.2f dB", g);
  g = gainDb("eq.lmid", 250.f, 6.f);   CHECK(std::fabs(g - 6) < 0.5, "lmid @250 = %.2f dB", g);
  g = gainDb("eq.hmid", 3500.f, 6.f);  CHECK(std::fabs(g - 6) < 0.5, "hmid @3.5k = %.2f dB", g);
}

static void testCompressor() {
  std::printf("compressor\n");
  float P[P_COUNT];
  for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
  P[P_COMP_ENABLED] = 1; P[P_COMP_REDUCTION] = 80; P[P_COMP_GAIN] = 0; P[P_COMP_MIX] = 1;
  P[P_COMP_ATTACK] = 1; P[P_COMP_RELEASE] = 100;
  auto run = [&](float amp) {
    Compressor c;
    c.prepare(kSr);
    auto x = sine(440.f, 1.5f, amp);
    std::vector<float> l = x, r = x;
    for (size_t i = 0; i < l.size(); i += 64) c.process(P, l.data() + i, r.data() + i, static_cast<int>(std::min<size_t>(64, l.size() - i)));
    return 20.0 * std::log10(rmsOf(l.data() + kSr, kSr / 4) / rmsOf(x.data() + kSr, kSr / 4));
  };
  double loud = run(0.9f), quiet = run(0.002f);
  CHECK(loud < -6.0, "loud signal should be reduced, got %.2f dB", loud);
  CHECK(std::fabs(quiet) < 0.8, "very quiet signal should pass untouched, got %.2f dB", quiet);
  P[P_COMP_MIX] = 0;
  CHECK(std::fabs(run(0.9f)) < 0.1, "mix 0 = bypass");
}

static void testDelay() {
  std::printf("delay\n");
  float P[P_COUNT];
  for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
  P[P_DELAY_TIME] = 250; P[P_DELAY_FEEDBACK] = 0.5f; P[P_DELAY_MIX] = 1; P[P_DELAY_PINGPONG] = 0;
  P[P_DELAY_SPREAD] = 0; P[P_DELAY_LOWPASS] = 20000;
  StereoDelay d;
  d.prepare(kSr);
  std::vector<float> l(kSr, 0.f), r(kSr, 0.f);
  l[0] = r[0] = 1.f;
  for (size_t i = 0; i < l.size(); i += 64) d.process(P, l.data() + i, r.data() + i, 64);
  const int echo = kSr / 4;
  float peak1 = 0; int at1 = 0;
  for (int i = 100; i < echo * 3 / 2; ++i) if (std::fabs(l[static_cast<size_t>(i)]) > peak1) { peak1 = std::fabs(l[static_cast<size_t>(i)]); at1 = i; }
  CHECK(std::abs(at1 - echo) <= 2, "first echo at %d, expected %d", at1, echo);
  CHECK(peak1 > 0.3f && peak1 < 1.0f, "first echo level %g", peak1);
  float second = 0;
  for (int i = 2 * echo - 3; i <= 2 * echo + 3; ++i) second = std::max(second, std::fabs(l[static_cast<size_t>(i)]));
  CHECK(second > 0.1f && second < peak1, "second echo %g vs first %g", second, peak1);

  // ping-pong: first echo only on the left, second on the right (input centre -> mono mid)
  P[P_DELAY_PINGPONG] = 1;
  StereoDelay d2;
  d2.prepare(kSr);
  std::vector<float> l2(kSr, 0.f), r2(kSr, 0.f);
  l2[0] = 1.f; r2[0] = 0.f;
  for (size_t i = 0; i < l2.size(); i += 64) d2.process(P, l2.data() + i, r2.data() + i, 64);
  float pl = 0, pr2 = 0, pr1 = 0;
  for (int i = echo - 3; i <= echo + 3; ++i) { pl = std::max(pl, std::fabs(l2[static_cast<size_t>(i)])); pr1 = std::max(pr1, std::fabs(r2[static_cast<size_t>(i)])); }
  for (int i = 2 * echo - 3; i <= 2 * echo + 3; ++i) pr2 = std::max(pr2, std::fabs(r2[static_cast<size_t>(i)]));
  CHECK(pl > 0.2f && pr1 < 0.01f, "pingpong: first echo left only (L %.3f R %.3f)", pl, pr1);
  CHECK(pr2 > 0.05f, "pingpong: second echo on the right (%.3f)", pr2);
}

static void testReverbDecay() {
  std::printf("reverb decay\n");
  for (float rt : {1.0f, 3.0f}) {
    Reverb r;
    r.prepare(kSr, 0.1f);
    r.setParams(0.6f, rt, 20000.f, 0.5f, 0.f, 0.f, 0.f, 1.f);
    const int N = static_cast<int>(8 * kSr);
    std::vector<double> e2(static_cast<size_t>(N));
    for (int i = 0; i < N; ++i) {
      float l, rr;
      r.process(i == 0 ? 1.f : 0.f, i == 0 ? 1.f : 0.f, l, rr);
      e2[static_cast<size_t>(i)] = static_cast<double>(l) * l + static_cast<double>(rr) * rr;
    }
    // Schroeder backward integration
    std::vector<double> edc(static_cast<size_t>(N));
    double acc = 0;
    for (int i = N - 1; i >= 0; --i) { acc += e2[static_cast<size_t>(i)]; edc[static_cast<size_t>(i)] = acc; }
    auto at = [&](double db) {
      for (int i = 0; i < N; ++i) if (10.0 * std::log10(edc[static_cast<size_t>(i)] / edc[0]) < db) return static_cast<double>(i) / kSr;
      return 99.0;
    };
    double t5 = at(-5), t35 = at(-35);
    double rt60 = (t35 - t5) * 2.0;
    CHECK(rt60 > rt * 0.6 && rt60 < rt * 1.5, "RT60 target %.1fs measured %.2fs", rt, rt60);
  }
}

// The FILTER section: slopes, resonance, bypass, sweep, safety.
static void testFilter() {
  std::printf("filter\n");
  auto make = [&](float hp, float lp, float res, int slope, float sweep = 0.f) {
    std::vector<float> P(P_COUNT);
    for (int i = 0; i < P_COUNT; ++i) P[static_cast<size_t>(i)] = paramInfo(i).def;
    P[P_FILTER_ENABLED] = 1.f; P[P_FILTER_HP] = hp; P[P_FILTER_LP] = lp; P[P_FILTER_RES] = res;
    P[P_FILTER_SLOPE] = static_cast<float>(slope); P[P_FILTER_SWEEP] = sweep;
    return P;
  };
  // gain in dB of a sine through the filter, measured after it has settled
  auto gainDb = [&](const std::vector<float>& P, float freq) {
    gb::Filter f;
    f.prepare(kSr);
    std::vector<float> l(64), r(64);
    double ein = 0, eout = 0;
    for (int b = 0; b < 400; ++b) {
      for (int k = 0; k < 64; ++k) l[static_cast<size_t>(k)] = r[static_cast<size_t>(k)] = 0.3f * std::sin(6.2831853f * freq * static_cast<float>(b * 64 + k) / kSr);
      std::vector<float> ref = l;
      f.process(P.data(), true, l.data(), r.data(), 64);
      if (b >= 200) for (int k = 0; k < 64; ++k) { ein += ref[static_cast<size_t>(k)] * ref[static_cast<size_t>(k)]; eout += l[static_cast<size_t>(k)] * l[static_cast<size_t>(k)]; }
    }
    return 10.0 * std::log10(eout / ein + 1e-20);
  };
  auto lp12 = make(20, 1000, 0.f, 0), lp24 = make(20, 1000, 0.f, 1);
  CHECK(std::fabs(gainDb(lp12, 200)) < 0.7, "LP passes 200 Hz (%.2f dB)", gainDb(lp12, 200));
  const double a12 = gainDb(lp12, 4000), a24 = gainDb(lp24, 4000);
  CHECK(a12 < -20 && a12 > -30, "12 dB/oct LP at 2 octaves: %.1f dB", a12);
  CHECK(a24 < -36, "24 dB/oct LP at 2 octaves: %.1f dB", a24);
  auto hp12 = make(1000, 20000, 0.f, 0), hp24 = make(1000, 20000, 0.f, 1);
  CHECK(std::fabs(gainDb(hp12, 8000)) < 0.7, "HP passes 8 kHz");
  CHECK(gainDb(hp12, 250) < -20, "HP 12 dB at 2 octaves: %.1f dB", gainDb(hp12, 250));
  CHECK(gainDb(hp24, 250) < -36, "HP 24 dB at 2 octaves: %.1f dB", gainDb(hp24, 250));
  // resonance lifts the corner
  auto res = make(20, 1000, 0.9f, 0);
  CHECK(gainDb(res, 1000) > gainDb(lp12, 1000) + 8.0, "resonance boosts the cutoff (%.1f dB)", gainDb(res, 1000));
  // wide open = transparent, bit exact
  {
    auto P = make(20, 20000, 0.5f, 1);
    gb::Filter f;
    f.prepare(kSr);
    std::vector<float> l(64), r(64);
    for (int k = 0; k < 64; ++k) l[static_cast<size_t>(k)] = r[static_cast<size_t>(k)] = 0.1f * static_cast<float>(k % 7);
    auto ref = l;
    for (int b = 0; b < 20; ++b) f.process(P.data(), true, l.data(), r.data(), 64);
    CHECK(l == ref, "wide-open filter must not touch the signal");
    // inactive instance also leaves the signal alone
    auto P2 = make(500, 800, 0.5f, 1);
    f.process(P2.data(), false, l.data(), r.data(), 64);
    CHECK(l == ref, "inactive filter must not touch the signal");
  }
  // the sweep makes a steady tone breathe in level; no sweep = steady
  {
    auto levelRange = [&](float sweep) {
      auto P = make(20, 6000, 0.3f, 0, sweep);
      P[P_FILTER_RATE] = 2.f;
      gb::Filter f;
      f.prepare(kSr);
      std::vector<float> l(64), r(64);
      double lo = 1e9, hi = 0;
      for (int b = 0; b < 1500; ++b) {
        for (int k = 0; k < 64; ++k) l[static_cast<size_t>(k)] = r[static_cast<size_t>(k)] = 0.3f * std::sin(6.2831853f * 3000.f * static_cast<float>(b * 64 + k) / kSr);
        f.process(P.data(), true, l.data(), r.data(), 64);
        if (b < 300) continue;
        double e = 0;
        for (int k = 0; k < 64; ++k) e += l[static_cast<size_t>(k)] * l[static_cast<size_t>(k)];
        lo = std::min(lo, e); hi = std::max(hi, e);
      }
      return 10.0 * std::log10(hi / (lo + 1e-20));
    };
    CHECK(levelRange(0.f) < 0.5, "no sweep = steady level");
    CHECK(levelRange(1.f) > 10.0, "sweep opens and closes the low-pass (%.1f dB swing)", levelRange(1.f));
  }
  // dragging the cutoff must not click: a fast jump of the knob changes the output smoothly
  {
    auto P = make(20, 8000, 0.2f, 1);
    gb::Filter f;
    f.prepare(kSr);
    std::vector<float> l(64), r(64);
    float prev = 0, maxStep = 0;
    for (int b = 0; b < 600; ++b) {
      if (b == 300) P[P_FILTER_LP] = 300.f;
      for (int k = 0; k < 64; ++k) l[static_cast<size_t>(k)] = r[static_cast<size_t>(k)] = 0.3f * std::sin(6.2831853f * 220.f * static_cast<float>(b * 64 + k) / kSr);
      f.process(P.data(), true, l.data(), r.data(), 64);
      for (int k = 0; k < 64; ++k) { if (b > 10) maxStep = std::max(maxStep, std::fabs(l[static_cast<size_t>(k)] - prev)); prev = l[static_cast<size_t>(k)]; }
    }
    CHECK(maxStep < 0.1f, "cutoff jump clicks (max sample step %.3f)", maxStep);
  }
  // NaN safety
  {
    auto P = make(200, 3000, 1.f, 1);
    gb::Filter f;
    f.prepare(kSr);
    std::vector<float> l(64, 0.1f), r(64, 0.1f);
    l[3] = std::nanf("");
    f.process(P.data(), true, l.data(), r.data(), 64);
    std::vector<float> l2(64, 0.1f), r2(64, 0.1f);
    f.process(P.data(), true, l2.data(), r2.data(), 64);
    for (float v : l2) CHECK(std::isfinite(v), "filter recovers from NaN");
  }
}

// A shimmer has to climb in octaves, not just be a reverb: after a two-note chord the tail must carry
// strong energy one octave above the notes, with feedback up and not with feedback at zero. It must also
// stay bounded on a sustained chord at maximum feedback, and its weight must move upwards with feedback.
static void testShimmerLadder() {
  std::printf("shimmer octave ladder\n");
  int eng = 0;  // 0 = Cloud, 1 = Clean
  auto run = [&](float feedback, bool sustain, int dual, std::vector<float>& out) {
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    P[P_SHIMMER_FEEDBACK] = feedback;
    P[P_SHIMMER_ENGINE] = static_cast<float>(eng);
    P[P_SHIMMER_DUAL] = static_cast<float>(dual);
    const size_t total = static_cast<size_t>(kSr) * (sustain ? 12 : 4);
    const size_t noteLen = sustain ? total : static_cast<size_t>(kSr) / 2;
    gb::Shimmer sh;
    sh.prepare(kSr);
    sh.setParams(P);
    out.assign(total, 0.f);
    std::vector<float> a(64), b(64), r(64);
    for (size_t i = 0; i + 64 <= total; i += 64) {
      for (size_t k = 0; k < 64; ++k) {
        const size_t j = i + k;
        const float t = static_cast<float>(j) / kSr;
        const float env = j < noteLen ? std::min(1.f, t / 0.02f) * std::min(1.f, static_cast<float>(noteLen - j) / (0.05f * kSr)) : 0.f;
        a[k] = b[k] = 0.375f * 0.35f * env * (std::sin(6.2831853f * 220.f * t) + std::sin(6.2831853f * 330.f * t));
      }
      sh.processBlock(a.data(), b.data(), out.data() + i, r.data(), 64);
    }
  };
  auto band = [&](const std::vector<float>& x, size_t from, double lo, double hi) {
    const size_t N = 16384;
    auto p = ana::power(x, from, N);
    double e = 0;
    for (size_t i = 1; i < p.size(); ++i) {
      const double f = static_cast<double>(i) * kSr / N;
      if (f >= lo && f < hi) e += p[i];
    }
    return e;
  };
  for (eng = 0; eng < 2; ++eng) {
    std::vector<float> y;
    run(0.5f, false, 0, y);
    const size_t at = static_cast<size_t>(kSr) / 2 + kSr / 2;  // 0.5 s after the chord ended
    const double notes = band(y, at, 180, 400), oct1 = band(y, at, 400, 800);
    CHECK(10 * std::log10(oct1 / notes) > -9.0, "feedback 0.5: octave above is only %.1f dB under the notes", 10 * std::log10(oct1 / notes));
    run(0.0f, false, 0, y);
    const double n0 = band(y, at, 180, 400), o0 = band(y, at, 400, 800);
    CHECK(10 * std::log10(o0 / n0) < -30.0, "feedback 0: octave above leaks (%.1f dB)", 10 * std::log10(o0 / n0));
    // and it climbs further: two octaves up must show up too
    run(0.7f, false, 0, y);
    const double oct2 = band(y, at + kSr, 800, 1600), noteLate = band(y, at + kSr, 180, 400);
    CHECK(oct2 > noteLate, "feedback 0.7: after 1.5 s the 2nd octave should outweigh the notes");
    // dual: a voice goes down as well, so energy appears below the notes
    run(0.7f, false, 1, y);
    const double below = band(y, at + kSr / 2, 90, 180);
    CHECK(below > 0.0, "dual produces an octave below");
    // bounded at the maximum feedback with a never-ending chord
    run(0.95f, true, 1, y);
    float pk = 0;
    for (float v : y) { CHECK(std::isfinite(v), "NaN in the shimmer loop"); pk = std::max(pk, std::fabs(v)); }
    CHECK(pk < 1.5f, "shimmer loop must stay bounded, peak %.2f", pk);
  }
}

static void testShimmer() {
  std::printf("shimmer\n");

  // --- one pitch-shift voice -------------------------------------------------------------------
  {
    StShifter v;
    CHECK(v.prepare(kSr) && v.ok(), "SoundTouch voice must be created");
    v.setPitch(7.f);
    const double target = 440.0 * std::pow(2.0, 7.0 / 12.0);
    auto x = sine(440.f, 5.f, 0.3f);
    std::vector<float> y(x.size());
    std::vector<float> yr(x.size());
    for (size_t i = 0; i + 64 <= x.size(); i += 64) v.process(x.data() + i, x.data() + i, y.data() + i, yr.data() + i, 64);
    size_t first = 0;
    while (first < y.size() && y[first] == 0.f) ++first;
    CHECK(first > 0 && first < static_cast<size_t>(0.4 * kSr), "voice latency %.0f ms", 1000.0 * static_cast<double>(first) / kSr);
    const float* tail = y.data() + 3 * kSr;
    double hz = dominantHz(tail, kSr, 600, 720);
    CHECK(std::fabs(hz - target) < 2.0, "shifted pitch %.1f Hz, wanted %.1f", hz, target);
    double eTarget = bandEnergy(tail, kSr, target - 25, target + 25);
    double eAll = bandEnergy(tail, kSr, 100, 4000);
    CHECK(eTarget > 0.97 * eAll, "only %.1f%% of the energy sits at the target pitch", 100 * eTarget / eAll);
    double eSrc = bandEnergy(tail, kSr, 400, 480);
    CHECK(eSrc < 0.002 * eTarget, "voice leaks the source pitch");
    int run = 0, longest = 0;  // after it started, the stream must never run dry
    for (size_t i = first + kSr; i < y.size(); ++i) { run = (y[i] == 0.f) ? run + 1 : 0; longest = std::max(longest, run); }
    CHECK(longest < 8, "voice output ran dry for %d samples", longest);
  }

  // --- the loop at its most extreme must stay bounded and finite -------------------------------------
  {
    Engine e;
    e.prepare(kSr);
    setNeutral(e);
    e.setParam(P_SHIMMER_MIX, 1.f);
    e.setParam(P_SHIMMER_FEEDBACK, 0.95f);
    e.setParam(P_SHIMMER_SHIFT, 24.f);
    e.setParam(P_SHIMMER_DUAL, 1);
    e.setParam(P_SHIMMER_VOICE2, 1.f);
    e.setParam(P_SHIMMER_TONE, 20000.f);
    e.setParam(P_SHIMMER_SMOOTH, 1.f);
    e.setParam(P_LIVE_LEVEL, 1.f);
    e.snapParams();
    Rng rng(7);
    std::vector<float> noise(static_cast<size_t>(4 * kSr));
    for (auto& n : noise) n = rng.bi() * 0.5f;
    auto out = render(e, 14.f, &noise);
    CHECK(allFinite(out), "extreme shimmer must stay finite and below full scale");
    CHECK(rmsOf(out.data() + 13 * 2 * kSr, kSr) < 0.7, "extreme shimmer tail level %.3f", rmsOf(out.data() + 13 * 2 * kSr, kSr));
  }

  // --- a NaN inside the loop must not poison it forever ------------------------------------------------
  {
    Shimmer sh;
    sh.prepare(kSr);
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    P[P_SHIMMER_DUAL] = 1;
    sh.setParams(P);
    std::vector<float> inL(64, 0.1f), inR(64, 0.1f), oL(64), oR(64);
    for (int b = 0; b < 200; ++b) sh.processBlock(inL.data(), inR.data(), oL.data(), oR.data(), 64);
    inL[10] = std::nanf("");
    sh.processBlock(inL.data(), inR.data(), oL.data(), oR.data(), 64);
    inL[10] = 0.1f;
    bool finite = true;
    for (int b = 0; b < 400; ++b) {
      sh.processBlock(inL.data(), inR.data(), oL.data(), oR.data(), 64);
      for (int i = 0; i < 64; ++i) finite = finite && std::isfinite(oL[static_cast<size_t>(i)]) && std::isfinite(oR[static_cast<size_t>(i)]);
    }
    CHECK(finite, "shimmer did not recover from NaN input");
  }

  // --- real-time safety: no allocation while parameters sweep ---------------------------------------
  {
    Engine e;
    e.prepare(kSr);
    setNeutral(e);
    e.setParam(P_SHIMMER_MIX, 0.8f);
    e.setParam(P_SHIMMER_DUAL, 1);
    e.setParam(P_LIVE_LEVEL, 1.f);
    e.snapParams();
    std::vector<float> in(480 * 2, 0.2f), out(480 * 2);
    for (int i = 0; i < 480; ++i) in[static_cast<size_t>(2 * i)] = in[static_cast<size_t>(2 * i + 1)] = 0.3f * std::sin(0.05f * static_cast<float>(i));
    // settle first (lazy first-use work, if any, must not count)
    for (int c = 0; c < 20; ++c) e.render(out.data(), 480, in.data());
    g_allocs = 0;
    g_countAllocs = true;
    for (int c = 0; c < 1000; ++c) {  // 10 s
      const float ph = static_cast<float>(c) / 1000.f;
      e.setParam(P_SHIMMER_SHIFT, -12.f + 36.f * ph);
      e.setParam(P_SHIMMER_SMOOTH, 0.5f + 0.5f * std::sin(ph * 40.f));
      e.setParam(P_SHIMMER_DUAL, (c / 200) % 2);
      e.setParam(P_SHIMMER_TONE, 500.f + 19000.f * ph);
      e.setParam(P_SHIMMER_FEEDBACK, 0.3f + 0.65f * ph);
      e.render(out.data(), 480, in.data());
    }
    g_countAllocs = false;
    CHECK(g_allocs.load() == 0, "%ld heap allocations on the audio thread during a shimmer sweep", g_allocs.load());
  }

  // --- full engine: the shifted octave must show up in the tail (A/B against feedback = 0) -----------------
  // Band-limited noise, not a sine: with a 6 s reverb tail a lone sine mostly falls between the
  // (very narrow) modes of the reverb and says little about the loop.
  {
    Rng rng(99);
    std::vector<float> low(static_cast<size_t>(3 * kSr));
    float a = 0, b = 0, c = 0, d = 0;
    const float k = 1.f - std::exp(-kTwoPi * 180.f / static_cast<float>(kSr));
    for (auto& x : low) { a += k * (rng.bi() - a); b += k * (a - b); c += k * (b - c); d += k * (c - d); x = d; }
    float pk = 0;
    for (float x : low) pk = std::max(pk, std::fabs(x));
    for (auto& x : low) x *= 0.5f / pk;
    auto run = [&](float feedback) {
      Engine e;
      e.prepare(kSr);
      setNeutral(e);
      e.setParam(P_SHIMMER_MIX, 1.f);
      e.setParam(P_SHIMMER_FEEDBACK, feedback);
      e.setParam(P_SHIMMER_SHIFT, 12.f);
      e.setParam(P_SHIMMER_DUAL, 0);
      e.setParam(P_LIVE_LEVEL, 1.f);
      e.snapParams();
      auto out = chan(render(e, 6.f, &low), 0);
      const float* tail = out.data() + static_cast<size_t>(3.4 * kSr);
      struct R { double src, oct, rms; } r{bandEnergy(tail, 2 * kSr, 100, 300), bandEnergy(tail, 2 * kSr, 450, 900), rmsOf(tail, kSr)};
      return std::make_pair(r, allFinite(out));
    };
    auto fb = run(0.7f), nofb = run(0.f);
    CHECK(fb.second && nofb.second, "shimmer finite");
    CHECK(nofb.first.src > 1e-9, "shimmer wet path carries the source");
    CHECK(fb.first.oct > 8.0 * nofb.first.oct, "octave band with feedback %.3g vs without %.3g: no shifted energy", fb.first.oct, nofb.first.oct);
    CHECK(fb.first.rms > 1e-4, "shimmer tail should still ring");
  }
}

static void testTape() {
  std::printf("tape\n");
  auto run = [](float wow, float flutter) {
    float P[P_COUNT];
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    P[P_TAPE_ENABLED] = 1; P[P_TAPE_WOW] = wow; P[P_TAPE_FLUTTER] = flutter; P[P_TAPE_HISS] = 0;
    P[P_TAPE_SATURATION] = 0; P[P_TAPE_CRINKLE] = 0; P[P_TAPE_DROPOUT] = 0; P[P_TAPE_BIT8] = 0;
    Tape t;
    t.prepare(kSr);
    auto x = sine(1000.f, 4.f, 0.3f);
    std::vector<float> l = x, r = x;
    for (size_t i = 0; i < l.size(); i += 64) t.process(P, l.data() + i, r.data() + i, 64);
    // Estimate instantaneous frequency via zero crossings in 50 ms windows after settling.
    double lo = 1e9, hi = -1e9;
    const int win = kSr / 20;
    for (int s = kSr; s + win < static_cast<int>(l.size()); s += win / 2) {
      int z = 0;
      for (int i = s + 1; i < s + win; ++i) if ((l[static_cast<size_t>(i - 1)] < 0) != (l[static_cast<size_t>(i)] < 0)) ++z;
      double hz = z * 0.5 / (static_cast<double>(win) / kSr);
      lo = std::min(lo, hz); hi = std::max(hi, hz);
    }
    return hi - lo;
  };
  double none = run(0, 0), wow = run(1.f, 0.f), flut = run(0.f, 1.f);
  CHECK(none < 25.0, "no modulation should be steady, spread %.1f Hz", none);
  CHECK(wow > none + 10.0, "wow should wobble pitch: %.1f vs %.1f Hz", wow, none);
  CHECK(flut > none + 3.0, "flutter should wobble pitch: %.1f vs %.1f Hz", flut, none);
}

// ---- ORBIX voices played directly (no balls): the synth voices behave the way their controls claim ----
static std::vector<float> voiceNote(const OrbixCtl& c, float midi, double secs, float vel = 1.5f) {
  Orbix ob;
  ob.prepare(kSr);
  OrbixCtl cc = c;
  cc.enabled = false;
  ob.playNote(cc, midi, vel, 0.f);
  const size_t total = static_cast<size_t>(secs * kSr);
  std::vector<float> l(total), r(total);
  for (size_t i = 0; i + 64 <= total; i += 64) ob.process(cc, l.data() + i, r.data() + i, 64);
  return l;
}

static double bandDb(const std::vector<float>& x, double t, double hz, size_t n = 8192) {
  auto p = ana::power(x, static_cast<size_t>(t * kSr), n);
  const double bin = static_cast<double>(kSr) / static_cast<double>(n);
  double m = 1e-30;
  for (size_t i = static_cast<size_t>(hz * 0.97 / bin); i <= static_cast<size_t>(hz * 1.03 / bin) + 1 && i < p.size(); ++i) m = std::max(m, p[i]);
  return 10.0 * std::log10(m);
}

static void testOrbixVoices() {
  std::printf("orbix voices (fm / mini / modal)\n");
  std::vector<float> P(P_COUNT);
  auto defaults = [&]() { for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def; };
  auto set = [&](const char* id, float v) { P[static_cast<size_t>(paramIndex(id))] = v; };

  // 1. Everything finite and bounded at the corners of every control, over the whole note range.
  const int inst[3] = {6, 7, 8};
  for (int pass = 0; pass < 2; ++pass) {
    for (int in : inst) {
      defaults();
      set("orbix.instrument", static_cast<float>(in));
      const float v = pass ? 1.f : 0.f;
      for (const char* id : {"orbix.fm_index", "orbix.fm_fb", "orbix.psw_shape", "orbix.psw_res", "orbix.psw_env", "orbix.psw_detune",
                             "orbix.m_exciter", "orbix.m_hardness", "orbix.m_geometry", "orbix.m_bright", "orbix.m_damp", "orbix.m_pos"}) {
        const ParamInfo& pi = paramInfo(paramIndex(id));
        set(id, pi.min + v * (pi.max - pi.min));
      }
      set("orbix.fm_ratio", pass ? 7.f : 0.f);
      set("orbix.psw_cutoff", pass ? 12000.f : 80.f);
      set("orbix.psw_width", pass ? 95.f : 5.f);
      set("orbix.attack", pass ? 1.f : 1500.f);
      set("orbix.release", pass ? 1.f : 3000.f);
      OrbixCtl c = orbixCtlFromParams(P.data());
      bool fin = true; float pk = 0.f;
      for (int midi : {12, 36, 60, 84, 108, 127}) {
        auto x = voiceNote(c, static_cast<float>(midi), 1.2);
        for (float s : x) { if (!std::isfinite(s)) fin = false; pk = std::max(pk, std::fabs(s)); }
      }
      CHECK(fin, "voice %d corner %d: non-finite output", in, pass);
      CHECK(pk < 1.5f, "voice %d corner %d: peak %.2f", in, pass, pk);
    }
  }

  // 2. Modal "Rhodes": strong fundamental, a second harmonic, a short-lived bar partial at 6.27x.
  defaults();
  set("orbix.instrument", 8); set("orbix.m_exciter", 0); set("orbix.m_hardness", 65); set("orbix.m_geometry", 33);
  set("orbix.m_bright", 68); set("orbix.m_damp", 40); set("orbix.m_pos", 22);
  {
    OrbixCtl c = orbixCtlFromParams(P.data());
    auto x = voiceNote(c, 60.f, 3.0);
    const double f0 = 261.6256;
    const double a1 = bandDb(x, 0.1, f0), a2 = bandDb(x, 0.1, 2 * f0), a6 = bandDb(x, 0.1, 6.27 * f0);
    CHECK(a2 < a1 - 3 && a2 > a1 - 30, "rhodes 2nd harmonic at %.1f dB re fundamental", a2 - a1);
    CHECK(a6 < a1 - 12 && a6 > a1 - 50, "rhodes bar partial at %.1f dB re fundamental", a6 - a1);
    const double d1 = a1 - bandDb(x, 0.9, f0), d6 = a6 - bandDb(x, 0.9, 6.27 * f0);
    CHECK(d6 > d1 + 6, "rhodes bark must die faster than the fundamental (%.1f vs %.1f dB)", d6, d1);
    CHECK(d1 > 6 && d1 < 80, "rhodes fundamental decay %.1f dB in 0.8 s", d1);
  }
  // Damping shortens the ring, geometry moves the overtones.
  {
    set("orbix.m_damp", 10);
    auto longRing = voiceNote(orbixCtlFromParams(P.data()), 60.f, 2.5);
    set("orbix.m_damp", 90);
    auto dry = voiceNote(orbixCtlFromParams(P.data()), 60.f, 2.5);
    CHECK(bandDb(longRing, 1.0, 261.6) > bandDb(dry, 1.0, 261.6) + 30, "damping: %.1f vs %.1f dB at 1 s", bandDb(longRing, 1.0, 261.6), bandDb(dry, 1.0, 261.6));
    set("orbix.m_damp", 40); set("orbix.m_geometry", 66);
    auto bar = voiceNote(orbixCtlFromParams(P.data()), 60.f, 1.0);
    CHECK(bandDb(bar, 0.05, 2.756 * 261.6) > bandDb(bar, 0.05, 2.0 * 261.6) + 6, "bar geometry: 2.756x partial should beat the 2nd harmonic");
  }
  // 3. Bowed strings: a harmonic series that keeps going while the bow is on, and builds with Attack.
  defaults();
  set("orbix.instrument", 8); set("orbix.m_exciter", 100); set("orbix.m_hardness", 25); set("orbix.m_geometry", 0);
  set("orbix.m_bright", 55); set("orbix.m_damp", 35); set("orbix.m_pos", 12); set("orbix.attack", 500); set("orbix.release", 1400);
  {
    OrbixCtl c = orbixCtlFromParams(P.data());
    auto x = voiceNote(c, 60.f, 3.4);
    auto rmsDb = [&](double t0, double t1) {
      double e = 0; size_t a = static_cast<size_t>(t0 * kSr), b = static_cast<size_t>(t1 * kSr);
      for (size_t i = a; i < b; ++i) e += static_cast<double>(x[i]) * x[i];
      return 10 * std::log10(e / static_cast<double>(b - a) + 1e-20);
    };
    CHECK(rmsDb(0.0, 0.1) < rmsDb(1.0, 1.5) - 20, "bow should swell: %.1f dB at start vs %.1f dB at 1 s", rmsDb(0.0, 0.1), rmsDb(1.0, 1.5));
    CHECK(std::fabs(rmsDb(1.0, 1.5) - rmsDb(1.9, 2.4)) < 4, "bowed note should sustain (%.1f vs %.1f dB)", rmsDb(1.0, 1.5), rmsDb(1.9, 2.4));
    const double f0 = 261.6256;
    const double h1 = bandDb(x, 1.5, f0, 16384);
    for (int k = 2; k <= 4; ++k) {
      double hk = bandDb(x, 1.5, k * f0, 16384);
      CHECK(hk > h1 - 40, "string harmonic %d is missing (%.1f dB re fundamental)", k, hk - h1);
    }
    CHECK(rmsDb(0.5, 1.0) > -60 && rmsDb(1.0, 1.5) < -3, "string level %.1f dB", rmsDb(1.0, 1.5));
  }
  // 4. Mini synth: PolyBLEP keeps a bright saw clean in the playing range (the top octaves of an open
  //    filter still show some folding, like any PolyBLEP oscillator).
  defaults();
  set("orbix.instrument", 7); set("orbix.psw_shape", 50); set("orbix.psw_cutoff", 12000); set("orbix.psw_res", 0);
  set("orbix.psw_detune", 0); set("orbix.psw_env", 0); set("orbix.attack", 1);
  {
    OrbixCtl c = orbixCtlFromParams(P.data());
    const float midi = 72.f;  // C5, filter wide open: the worst case for aliasing
    const double f0 = 440.0 * std::pow(2.0, (midi - 69) / 12.0);
    auto x = voiceNote(c, midi, 1.0);
    const size_t n = 16384;
    auto p = ana::power(x, 12000, n);
    const double bin = static_cast<double>(kSr) / static_cast<double>(n);
    double harm = 0, other = 0;
    for (size_t i = 8; i < p.size(); ++i) {
      double hz = static_cast<double>(i) * bin, k = std::round(hz / f0);
      (k >= 1 && std::fabs(hz - k * f0) < 4 * bin ? harm : other) += p[i];
    }
    CHECK(10 * std::log10(other / harm) < -35, "saw aliasing: inharmonic energy %.1f dB re harmonics", 10 * std::log10(other / harm));
  }
  // 5. FM: index 0 is a pure sine, a high index adds strong overtones; the index decays with its time.
  defaults();
  set("orbix.instrument", 6); set("orbix.fm_ratio", 3); set("orbix.fm_fb", 0); set("orbix.fm_decay", 300);
  {
    set("orbix.fm_index", 0);
    auto pure = voiceNote(orbixCtlFromParams(P.data()), 60.f, 1.0);
    CHECK(bandDb(pure, 0.2, 2 * 261.6) < bandDb(pure, 0.2, 261.6) - 60, "FM index 0 should be a sine");
    set("orbix.fm_index", 80);
    auto bright = voiceNote(orbixCtlFromParams(P.data()), 60.f, 2.0);
    const double early = bandDb(bright, 0.02, 4 * 261.6) - bandDb(bright, 0.02, 261.6);
    const double late = bandDb(bright, 1.5, 4 * 261.6) - bandDb(bright, 1.5, 261.6);
    CHECK(early > late + 10, "FM brightness should decay: %.1f dB early vs %.1f dB late", early, late);
  }
}

// ---- RINGS and ELEMENTS ORBIX: the real Mutable Instruments DSP behind the Orbix note engine ----
static void testMutable() {
  std::printf("rings + elements orbix\n");
  std::vector<float> P(P_COUNT);
  auto defaults = [&]() { for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def; };
  auto set = [&](const char* id, float v) { P[static_cast<size_t>(paramIndex(id))] = v; };
  auto play = [&](const OrbixCtl& c, float midi, double secs, std::vector<float>* rOut, double sr = kSr) {
    Orbix ob;
    ob.prepare(sr, c.instrument == 10 ? OrbixBank::Elements : OrbixBank::Rings);
    OrbixCtl cc = c;
    cc.enabled = false;
    ob.playNote(cc, midi, 1.5f, 0.f);
    const size_t total = static_cast<size_t>(secs * sr);
    std::vector<float> l(total), r(total);
    for (size_t i = 0; i + 64 <= total; i += 64) ob.process(cc, l.data() + i, r.data() + i, 64);
    if (rOut) *rOut = r;
    return l;
  };
  auto peakFinite = [&](const OrbixCtl& c, const char* what, int a, int b) {
    bool fin = true; float pk = 0.f;
    for (int midi : {12, 36, 60, 84, 108, 127}) {
      std::vector<float> r;
      auto l = play(c, static_cast<float>(midi), 1.5, &r);
      for (size_t i = 0; i < l.size(); ++i) {
        if (!std::isfinite(l[i]) || !std::isfinite(r[i])) fin = false;
        pk = std::max(pk, std::max(std::fabs(l[i]), std::fabs(r[i])));
      }
    }
    CHECK(fin, "%s %d/%d: non-finite", what, a, b);
    CHECK(pk < 1.5f, "%s %d/%d: peak %.2f", what, a, b, pk);
  };
  // 1. Rings: every model, controls at their corners, whole keyboard: finite and bounded
  for (int model = 0; model < 6; ++model) {
    for (int pass = 0; pass < 2; ++pass) {
      defaults();
      set("rings.model", static_cast<float>(model));
      for (const char* id : {"rings.structure", "rings.brightness", "rings.damping", "rings.position"}) set(id, pass ? 100.f : 0.f);
      set("rings.poly", pass ? 2.f : 0.f);
      set("rings.chord", pass ? 10.f : 0.f);
      peakFinite(ringsCtlFromParams(P.data()), "rings model", model, pass);
    }
  }
  // 2. Rings modal: sound, and even/odd modes in different channels (stereo split)
  defaults();
  set("rings.model", 0); set("rings.poly", 0); set("rings.structure", 0); set("rings.brightness", 70); set("rings.damping", 60); set("rings.position", 20);
  {
    std::vector<float> r;
    auto l = play(ringsCtlFromParams(P.data()), 60.f, 1.0, &r);
    const double f0 = 261.6256;
    const double lf = bandDb(l, 0.1, f0), rf = bandDb(r, 0.1, f0), l2 = bandDb(l, 0.1, 2 * f0), r2 = bandDb(r, 0.1, 2 * f0);
    std::printf("  rings modal: f0 L %.1f R %.1f dB | 2f0 L %.1f R %.1f dB\n", lf, rf, l2, r2);
    CHECK(std::fabs(lf - rf) > 6 || std::fabs(l2 - r2) > 6, "rings modal: odd and even modes should split across the channels");
    CHECK(std::max(lf, rf) > -90, "rings modal: no fundamental");
  }
  // 3. Rings string: in tune
  for (float st : {0.f, 80.f}) {
    defaults();
    set("rings.model", 2); set("rings.poly", 0); set("rings.structure", st); set("rings.brightness", 60); set("rings.damping", 60); set("rings.position", 10);
    for (int midi : {48, 60, 72}) {
      std::vector<float> r;
      auto l = play(ringsCtlFromParams(P.data()), static_cast<float>(midi), 1.0, &r);
      for (size_t i = 0; i < l.size(); ++i) l[i] += r[i];
      const double f0 = 440.0 * std::pow(2.0, (midi - 69) / 12.0);
      const size_t n = 32768;
      auto p = ana::power(l, 4000, n);
      const double bin = static_cast<double>(kSr) / static_cast<double>(n);
      size_t best = 0; double bv = 0;
      for (size_t i = static_cast<size_t>(0.7 * f0 / bin); i < static_cast<size_t>(1.3 * f0 / bin); ++i) if (p[i] > bv) { bv = p[i]; best = i; }
      const double a = std::log(p[best - 1] + 1e-30), b = std::log(p[best] + 1e-30), c = std::log(p[best + 1] + 1e-30);
      const double hz = (static_cast<double>(best) + 0.5 * (a - c) / (a - 2 * b + c)) * bin;
      const double cents = 1200.0 * std::log2(hz / f0);
      std::printf("  rings string midi %d structure %.0f: %+.1f cents\n", midi, st, cents);
      // Structure stiffens the string (the partials, and with them the pitch, rise): only the plain string must be in tune.
      if (st == 0.f) CHECK(std::fabs(cents) < 35.0, "rings string midi %d structure %.0f: %.1f cents off", midi, st, cents);
    }
  }
  // 4. Rings polyphony: with 4 voices the first note is still ringing after three more, with 1 it is gone
  {
    double lev[2];
    int k = 0;
    for (int pol : {0, 2}) {
      defaults();
      set("rings.model", 0); set("rings.poly", static_cast<float>(pol)); set("rings.damping", 100); set("rings.structure", 0);
      OrbixCtl c = ringsCtlFromParams(P.data());
      c.enabled = false;
      Orbix ob;
      ob.prepare(kSr, OrbixBank::Rings);
      std::vector<float> all;
      std::vector<float> l(64), r(64);
      for (int note = 0; note < 4; ++note) {
        ob.playNote(c, 60.f + 7.f * static_cast<float>(note), 1.5f, 0.f);
        for (int b = 0; b < 60; ++b) { std::fill(l.begin(), l.end(), 0.f); std::fill(r.begin(), r.end(), 0.f); ob.process(c, l.data(), r.data(), 64); }
      }
      std::vector<float> tail;
      for (int b = 0; b < 400; ++b) { std::fill(l.begin(), l.end(), 0.f); std::fill(r.begin(), r.end(), 0.f); ob.process(c, l.data(), r.data(), 64); for (int i = 0; i < 64; ++i) tail.push_back(l[i] + r[i]); }
      lev[k++] = bandDb(tail, 0.1, 261.6256);
    }
    std::printf("  rings polyphony: first note after 3 more: poly1 %.1f dB, poly4 %.1f dB\n", lev[0], lev[1]);
    CHECK(lev[1] > lev[0] + 6, "rings poly 4 should keep the first note ringing (%.1f vs %.1f dB)", lev[1], lev[0]);
  }
  // 5. Elements: every model and exciter at its corners, finite and bounded; strike makes sound
  for (int model = 0; model < 3; ++model) {
    for (int pass = 0; pass < 2; ++pass) {
      defaults();
      set("elements.model", static_cast<float>(model));
      for (const char* id : {"elements.geometry", "elements.brightness", "elements.damping", "elements.position", "elements.space", "elements.contour",
                             "elements.bow", "elements.bow_timbre", "elements.blow", "elements.flow", "elements.blow_timbre", "elements.strike",
                             "elements.mallet", "elements.strike_timbre"}) set(id, pass ? 100.f : 0.f);
      set("elements.gate", pass ? 2000.f : 10.f);
      peakFinite(elementsCtlFromParams(P.data()), "elements model", model, pass);
    }
  }
  defaults();
  {
    std::vector<float> r;
    auto l = play(elementsCtlFromParams(P.data()), 60.f, 1.0, &r);
    double e = 0; for (float v : l) e += static_cast<double>(v) * v;
    CHECK(e > 1e-4, "elements: a strike should be audible (energy %.6f)", e);
  }
  // 6. Elements pitch: string model, strike
  {
    defaults();
    set("elements.model", 1); set("elements.geometry", 20); set("elements.damping", 80); set("elements.brightness", 40);
    for (int midi : {48, 60, 72}) {
      std::vector<float> r;
      auto l = play(elementsCtlFromParams(P.data()), static_cast<float>(midi), 1.0, &r);
      for (size_t i = 0; i < l.size(); ++i) l[i] += r[i];
      const double f0 = 440.0 * std::pow(2.0, (midi - 69) / 12.0);
      const size_t n = 32768;
      auto p = ana::power(l, 4000, n);
      const double bin = static_cast<double>(kSr) / static_cast<double>(n);
      size_t best = 0; double bv = 0;
      for (size_t i = static_cast<size_t>(0.7 * f0 / bin); i < static_cast<size_t>(1.3 * f0 / bin); ++i) if (p[i] > bv) { bv = p[i]; best = i; }
      const double a = std::log(p[best - 1] + 1e-30), b = std::log(p[best] + 1e-30), c = std::log(p[best + 1] + 1e-30);
      const double hz = (static_cast<double>(best) + 0.5 * (a - c) / (a - 2 * b + c)) * bin;
      const double cents = 1200.0 * std::log2(hz / f0);
      std::printf("  elements string midi %d: %+.1f cents\n", midi, cents);
      CHECK(std::fabs(cents) < 50.0, "elements string midi %d: %.1f cents off", midi, cents);
    }
  }
  // 7. both work at 44.1 kHz and 48 kHz (they run at 48 / 32 kHz inside and are resampled)
  for (double sr : {44100.0, 48000.0}) {
    defaults();
    std::vector<float> r, r2;
    auto l = play(ringsCtlFromParams(P.data()), 60.f, 1.0, &r, sr);
    auto l2 = play(elementsCtlFromParams(P.data()), 60.f, 1.0, &r2, sr);
    double e1 = 0, e2 = 0;
    for (size_t i = 0; i < l.size(); ++i) e1 += static_cast<double>(l[i]) * l[i] + static_cast<double>(r[i]) * r[i];
    for (size_t i = 0; i < l2.size(); ++i) e2 += static_cast<double>(l2[i]) * l2[i] + static_cast<double>(r2[i]) * r2[i];
    CHECK(e1 > 1e-5 && e2 > 1e-5, "rings/elements silent at %.0f Hz (%.6f, %.6f)", sr, e1, e2);
  }
  // 8. through the engine: each of the two ORBIXes sounds on its own and independently of the others
  for (int which = 0; which < 2; ++which) {
    Engine e;
    e.prepare(kSr);
    defaults();
    const char* pre = which ? "elements." : "rings.";
    set("transport.playing", 1); set("orbix.enabled", 0);
    set((std::string(pre) + "enabled").c_str(), 1);
    set((std::string(pre) + "balls").c_str(), 8); set((std::string(pre) + "rotation").c_str(), 80); set((std::string(pre) + "gravity").c_str(), 30);
    for (int i = 0; i < P_COUNT; ++i) e.setParam(i, P[static_cast<size_t>(i)]);
    std::vector<float> out(128);
    double energy = 0;
    for (int b = 0; b < 1500; ++b) { e.render(out.data(), 64, nullptr); for (float v : out) energy += static_cast<double>(v) * v; }
    CHECK(energy > 1e-3, "%s ORBIX should be audible through the engine (energy %.6f)", which ? "ELEMENTS" : "RINGS", energy);
  }
}

static void testOrbix() {
  std::printf("orbix\n");
  auto src = sine(261.6f, 2.f, 0.4f);
  for (int inst = 0; inst < 9; ++inst) {
    Engine e;
    e.prepare(kSr);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
    setNeutral(e);
    e.setParam(P_GRAIN_ENABLED, 0);
    e.setParam(P_ORBIX_ENABLED, 1);
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_ORBIX_INSTRUMENT, static_cast<float>(inst));
    e.setParam(P_ORBIX_BALLS, 6);
    e.setParam(P_ORBIX_VOLUME, 80);
    e.setParam(P_ORBIX_ROTATION, 50);
    e.setParam(P_ORBIX_RELEASE, 300);
    e.snapParams();
    int maxVoices = 0;
    double rms = 0; int cnt = 0;
    float st[Engine::kStateSize];
    bool inside = true;
    for (int s = 0; s < 20; ++s) {
      auto o = chan(render(e, 0.5f), 0);
      rms += rmsOf(o.data(), static_cast<int>(o.size())); ++cnt;
      e.getState(st, Engine::kStateSize);
      maxVoices = std::max(maxVoices, static_cast<int>(st[6]));
      const float* ob = st + Engine::kStateHeader + Granular::kMaxGrains;
      int nb = static_cast<int>(ob[2]);
      for (int b = 0; b < nb; ++b) {
        float x = ob[3 + 3 * b], y = ob[4 + 3 * b];
        if (!std::isfinite(x) || !std::isfinite(y) || x * x + y * y > 1.2f) inside = false;
      }
      CHECK(nb == 6, "ball count %d", nb);
    }
    CHECK(maxVoices > 0, "instrument %d: no notes played", inst);
    CHECK(rms / cnt > 0.003, "instrument %d: too quiet (%.5f)", inst, rms / cnt);
    CHECK(inside, "instrument %d: a ball left the arena", inst);
  }
  // Stopping the transport must stop new notes, ringing voices must end.
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  e.setParam(P_GRAIN_ENABLED, 0);
  e.setParam(P_ORBIX_ENABLED, 1);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_ORBIX_INSTRUMENT, 0);
  e.setParam(P_ORBIX_RELEASE, 100);
  e.snapParams();
  render(e, 3.f);
  e.setParam(P_TRANSPORT_PLAYING, 0);
  render(e, 3.f);
  auto o = chan(render(e, 1.f), 0);
  CHECK(rmsOf(o.data(), static_cast<int>(o.size())) < 1e-4, "orbix silent after stop");
}

static void testLimiterAndFinite() {
  std::printf("limiter / loud input\n");
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  e.setParam(P_LIVE_LEVEL, 1.f);
  e.setParam(P_LEVEL_INPUT_DB, 24.f);
  e.setParam(P_LEVEL_MASTER_DB, 12.f);
  e.snapParams();
  auto in = sine(100.f, 2.f, 1.0f);
  auto out = render(e, 2.f, &in);
  CHECK(allFinite(out, 1.0f), "output must never exceed full scale");
  CHECK(rmsOf(out.data(), static_cast<int>(out.size())) > 0.3, "loud output expected");
}

static void testRecording() {
  std::printf("recording\n");
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  CHECK(e.startRecording(), "start");
  CHECK(!e.startRecording(), "double start rejected");
  auto in = sine(500.f, 1.0f, 0.4f);
  // The input thread delivers odd-sized blocks, the output callback runs at its own cadence (and
  // may even see no input at all): the recording must still be complete and bit-exact.
  {
    std::vector<float> inter(in.size() * 2);
    for (size_t i = 0; i < in.size(); ++i) inter[2 * i] = inter[2 * i + 1] = in[i];
    size_t pos = 0;
    int chunk = 97;
    while (pos < in.size()) {
      const size_t n = std::min<size_t>(static_cast<size_t>(chunk), in.size() - pos);
      e.recordInput(inter.data() + 2 * pos, static_cast<int>(n));
      pos += n;
      chunk = chunk == 97 ? 480 : (chunk == 480 ? 33 : 97);
      std::vector<float> o(2 * 128);
      e.render(o.data(), 128, nullptr);  // output side is independent of what the input thread did
    }
  }
  e.stopRecording();
  {
    std::vector<float> junk(2 * 256, 0.9f);
    e.recordInput(junk.data(), 256);  // after stop: ignored
  }
  const int fr = e.recordedFrames();
  CHECK(fr == kSr, "recorded %d frames, expected %d", fr, kSr);
  std::vector<float> got(static_cast<size_t>(fr) * 2);
  CHECK(e.copyRecording(got.data(), fr) == fr, "copy");
  double err = 0;
  for (int i = 0; i < fr; ++i) {
    err = std::max(err, static_cast<double>(std::fabs(got[2 * static_cast<size_t>(i)] - in[static_cast<size_t>(i)])));
    err = std::max(err, static_cast<double>(std::fabs(got[2 * static_cast<size_t>(i) + 1] - in[static_cast<size_t>(i)])));
  }
  CHECK(err < 1e-6, "recording must be bit-exact, err %g", err);
  CHECK(std::fabs(e.recordingSampleRate() - kSr) < 0.5, "rate defaults to the output rate");

  // render() must not record on its own any more (that path used to lose audio)
  CHECK(e.startRecording(), "restart");
  CHECK(e.recordedFrames() == 0, "a new take starts empty");
  render(e, 0.5f, &in);
  CHECK(e.recordedFrames() == 0, "the output callback does not feed the recording");

  // the input stream's real rate is what the recording is saved at
  e.stopRecording();
  e.setInputSampleRate(44100);
  CHECK(e.startRecording(), "start at 44.1k");
  CHECK(std::fabs(e.recordingSampleRate() - 44100.0) < 0.5, "recording rate follows the input stream");
  std::vector<float> nan(2 * 64, 0.25f);
  nan[10] = std::nanf("");
  nan[11] = INFINITY;
  e.recordInput(nan.data(), 64);
  std::vector<float> back(2 * 64);
  CHECK(e.copyRecording(back.data(), 64) == 64, "copy 64");
  CHECK(back[10] == 0.f && back[11] == 0.f && back[12] == 0.25f, "non-finite samples are replaced by silence");

  // the buffer fills up: recording stops by itself at the limit and nothing is written past it
  e.stopRecording();
  e.setInputSampleRate(0);
  CHECK(e.startRecording(), "start for the limit");
  std::vector<float> blk(2 * 4800, 0.1f);
  const int limit = kSr * Engine::kMaxRecSeconds;
  for (int i = 0; i < limit / 4800 + 3; ++i) e.recordInput(blk.data(), 4800);
  CHECK(!e.isRecording(), "recording ends when the buffer is full");
  CHECK(e.recordedFrames() == limit, "limit %d, recorded %d", limit, e.recordedFrames());
}

static void testSampleRates() {
  std::printf("sample rates\n");
  auto src = sine(200.f, 3.f, 0.5f, 44100);
  for (int sr : {22050, 44100, 48000, 96000}) {
    Engine e;
    e.prepare(sr);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), 44100);
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_ORBIX_ENABLED, 1);
    e.setParam(P_SHIMMER_MIX, 0.5f);
    e.setParam(P_REVERB_MIX, 0.5f);
    e.snapParams();
    auto out = render(e, 3.f);
    CHECK(allFinite(out), "sr %d finite", sr);
    CHECK(rmsOf(out.data(), static_cast<int>(out.size())) > 0.005, "sr %d audible", sr);
  }
  // sample rate conversion of grains: a 44.1k sample played at 48k keeps its pitch
  Engine e;
  e.prepare(48000);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), 44100);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_GRAIN_SIZE, 0.25f);
  e.setParam(P_GRAIN_DENSITY, 80);
  e.setParam(P_GRAIN_SPRAY, 0.f);
  e.setParam(P_SMOOTH_OVERLAP, 1.f);
  e.snapParams();
  auto o = chan(render(e, 3.f), 0);
  double f = dominantHz(o.data() + kSr, kSr, 150, 260);
  CHECK(std::fabs(f - 200.0) < 4.0, "44.1k->48k pitch kept: %.1f Hz", f);
}

static void testRoamAndMotion() {
  std::printf("roam / motion\n");
  auto src = sine(220.f, 4.f, 0.5f);
  Engine e;
  e.prepare(kSr);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_ROAM_ENABLED, 1);
  e.setParam(P_ROAM_MODE, 0);
  e.setParam(P_ROAM_RANGE, 1.f);
  e.setParam(P_ROAM_SPEED, 0.5f);
  e.setParam(P_ROAM_SMOOTH, 0.f);
  e.snapParams();
  float lo = 2, hi = -1, st[Engine::kStateSize];
  for (int i = 0; i < 40; ++i) {
    render(e, 0.1f);
    e.getState(st, Engine::kStateSize);
    lo = std::min(lo, st[0]); hi = std::max(hi, st[0]);
  }
  CHECK(hi - lo > 0.4f, "roam should move the playhead: %.2f..%.2f", lo, hi);
  e.setParam(P_MOTION_HOLD, 1.f);
  render(e, 1.0f);
  e.getState(st, Engine::kStateSize);
  float p0 = st[0];
  render(e, 1.0f);
  e.getState(st, Engine::kStateSize);
  CHECK(std::fabs(st[0] - p0) < 0.02f, "hold freezes roam: %.3f -> %.3f", p0, st[0]);
  CHECK(st[8] > 0.f && st[8] < 1.0f, "DSP load meter should be a sane fraction of real time, got %.3f", st[8]);
  CHECK(Engine::kStateHeader == 12 && Engine::kStateSize == 12 + 64 + 51 + 51 + 51, "state layout is mirrored in EngineState.kt");
}

static void testFuzzAllParams() {
  std::printf("fuzz: random parameter sets\n");
  auto src = sine(180.f, 2.f, 0.5f);
  Rng rng(1234);
  for (int iter = 0; iter < 40; ++iter) {
    Engine e;
    e.prepare(iter % 3 == 0 ? 44100 : 48000);
    e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
    for (int p = 0; p < P_COUNT; ++p) {
      const ParamInfo& pi = paramInfo(p);
      float v;
      float r = rng.uni();
      if (iter % 4 == 0) v = (r < 0.5f) ? pi.min : pi.max;  // extremes
      else v = pi.min + (pi.max - pi.min) * r;
      e.setParam(p, v);
    }
    e.setParam(P_TRANSPORT_PLAYING, 1);
    e.setParam(P_ORBIX_ENABLED, 1);
    e.snapParams();
    auto in = sine(300.f, 3.f, 0.5f);
    auto out = render(e, 3.f, &in, 37 + iter);  // odd chunk sizes on purpose
    bool ok = allFinite(out, 1.0f);
    CHECK(ok, "fuzz iter %d produced non-finite or clipped output", iter);
    if (!ok) {
      for (int p = 0; p < P_COUNT; ++p) std::printf("    %s=%g\n", paramInfo(p).id, e.getParam(p));
      break;
    }
  }
}

static void testSamplePublishRace() {
  std::printf("sample hand-over under load\n");
  Engine e;
  e.prepare(kSr);
  setNeutral(e);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_ORBIX_ENABLED, 1);
  e.setParam(P_ORBIX_INSTRUMENT, 3);
  e.snapParams();
  std::atomic<bool> stop{false};
  std::atomic<int> rendered{0};
  std::thread audio([&] {
    std::vector<float> buf(2 * 128);
    while (!stop.load()) {
      e.render(buf.data(), 128, nullptr);
      rendered.fetch_add(1);
    }
  });
  for (int i = 0; i < 300; ++i) {
    auto s = sine(100.f + static_cast<float>(i), 0.2f + 0.001f * static_cast<float>(i % 7), 0.3f);
    e.publishSample(s.data(), s.data(), static_cast<int>(s.size()), kSr);
    std::this_thread::sleep_for(std::chrono::microseconds(300));
  }
  stop = true;
  audio.join();
  CHECK(rendered.load() > 100, "audio thread kept running (%d blocks)", rendered.load());
}

static void testPerf() {
  std::printf("performance\n");
  auto src = sine(150.f, 6.f, 0.5f);
  Engine e;
  e.prepare(kSr);
  e.publishSample(src.data(), src.data(), static_cast<int>(src.size()), kSr);
  e.setParam(P_TRANSPORT_PLAYING, 1);
  e.setParam(P_GRAIN_DENSITY, 100);
  e.setParam(P_GRAIN_SIZE, 4.f);
  e.setParam(P_ORBIX_ENABLED, 1);
  e.setParam(P_ORBIX_BALLS, 16);
  e.setParam(P_SHIMMER_MIX, 0.7f);
  e.setParam(P_SHIMMER_DUAL, 1);
  e.setParam(P_REVERB_MIX, 0.8f);
  e.setParam(P_DELAY_MIX, 0.5f);
  e.snapParams();
  auto t0 = std::chrono::steady_clock::now();
  render(e, 20.f);
  double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::printf("  worst case: 20 s of audio in %.2f s  (%.1fx real time)\n", dt, 20.0 / dt);
#if defined(__SANITIZE_ADDRESS__) || defined(__SANITIZE_THREAD__)
  (void)dt;  // sanitizer builds are far slower; the number is only meaningful for plain -O2 builds
#else
  CHECK(20.0 / dt > 5.0, "engine should be >5x real time on the host, got %.1fx", 20.0 / dt);  // sanity bound, machine dependent
#endif
}

int main() {
  testRegistry();
  testGranularPitch();
  testStopAndTail();
  testEq();
  testCompressor();
  testDelay();
  testReverbDecay();
  testShimmer();
  testShimmerLadder();
  testFilter();
  testTape();
  testOrbix();
  testOrbixVoices();
  testMutable();
  testLimiterAndFinite();
  testRecording();
  testSampleRates();
  testRoamAndMotion();
  testFuzzAllParams();
  testSamplePublishRace();
  testPerf();
  std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
  return g_fail ? 1 : 0;
}
