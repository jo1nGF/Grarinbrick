// Minimal WAV reader/writer for the host-side tools and tests (PCM16/24/32, float32).
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

struct WavData {
  int channels = 0;
  int sampleRate = 0;
  std::vector<float> l, r;  // r == l for mono
};

inline bool readWav(const std::string& path, WavData& out) {
  FILE* f = std::fopen(path.c_str(), "rb");
  if (!f) return false;
  std::vector<unsigned char> d;
  unsigned char buf[65536];
  size_t n;
  while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) d.insert(d.end(), buf, buf + n);
  std::fclose(f);
  if (d.size() < 44 || std::memcmp(d.data(), "RIFF", 4) != 0 || std::memcmp(d.data() + 8, "WAVE", 4) != 0)
    return false;
  size_t p = 12;
  int fmt = 0, ch = 0, bits = 0, sr = 0;
  size_t dataOff = 0, dataLen = 0;
  auto u16 = [&](size_t o) { return static_cast<int>(d[o] | (d[o + 1] << 8)); };
  auto u32 = [&](size_t o) { return static_cast<uint32_t>(d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (static_cast<uint32_t>(d[o + 3]) << 24)); };
  while (p + 8 <= d.size()) {
    uint32_t sz = u32(p + 4);
    if (std::memcmp(&d[p], "fmt ", 4) == 0) {
      fmt = u16(p + 8); ch = u16(p + 10); sr = static_cast<int>(u32(p + 12)); bits = u16(p + 22);
      if (fmt == 0xFFFE && sz >= 26) fmt = u16(p + 8 + 24);
    } else if (std::memcmp(&d[p], "data", 4) == 0) {
      dataOff = p + 8;
      dataLen = std::min<size_t>(sz, d.size() - dataOff);
      break;
    }
    p += 8 + sz + (sz & 1);
  }
  if (!dataOff || ch < 1 || bits == 0) return false;
  const size_t bytes = static_cast<size_t>(bits / 8);
  const size_t frames = dataLen / (bytes * static_cast<size_t>(ch));
  out.channels = ch;
  out.sampleRate = sr;
  out.l.assign(frames, 0.f);
  out.r.assign(frames, 0.f);
  for (size_t i = 0; i < frames; ++i) {
    for (int c = 0; c < std::min(ch, 2); ++c) {
      const unsigned char* s = &d[dataOff + (i * static_cast<size_t>(ch) + static_cast<size_t>(c)) * bytes];
      float v = 0.f;
      if (fmt == 3 && bits == 32) { float x; std::memcpy(&x, s, 4); v = x; }
      else if (bits == 16) v = static_cast<int16_t>(s[0] | (s[1] << 8)) / 32768.f;
      else if (bits == 24) v = (static_cast<int32_t>((s[0] << 8) | (s[1] << 16) | (static_cast<uint32_t>(s[2]) << 24)) >> 8) / 8388608.f;
      else if (bits == 32) v = static_cast<int32_t>(u32(static_cast<size_t>(s - d.data()))) / 2147483648.f;
      else if (bits == 8) v = (s[0] - 128) / 128.f;
      (c == 0 ? out.l : out.r)[i] = v;
    }
    if (ch == 1) out.r[i] = out.l[i];
  }
  return true;
}

inline bool writeWav16(const std::string& path, const std::vector<float>& interleaved, int sr) {
  FILE* f = std::fopen(path.c_str(), "wb");
  if (!f) return false;
  uint32_t dataBytes = static_cast<uint32_t>(interleaved.size() * 2);
  auto w32 = [&](uint32_t v) { std::fwrite(&v, 4, 1, f); };
  auto w16 = [&](uint16_t v) { std::fwrite(&v, 2, 1, f); };
  std::fwrite("RIFF", 1, 4, f); w32(36 + dataBytes); std::fwrite("WAVEfmt ", 1, 8, f);
  w32(16); w16(1); w16(2); w32(static_cast<uint32_t>(sr)); w32(static_cast<uint32_t>(sr) * 4); w16(4); w16(16);
  std::fwrite("data", 1, 4, f); w32(dataBytes);
  for (float x : interleaved) {
    float c = x > 1.f ? 1.f : (x < -1.f ? -1.f : x);
    int16_t s = static_cast<int16_t>(c * 32767.f);
    std::fwrite(&s, 2, 1, f);
  }
  std::fclose(f);
  return true;
}
