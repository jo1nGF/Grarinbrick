// Offline evaluation of the shimmer: the current implementation against the frozen first one
// (tests/host/legacy_shimmer.h), on a sustained pad, with a few objective "harshness" measures.
//
//   shimmer_eval demo-pad.wav [seconds] [dump_dir]
//
// The numbers are a compass, not a verdict: they say whether the sound got darker, less ringing and
// less rough, they cannot say whether it is beautiful. With dump_dir the WAVs of every run are
// written so they can be listened to.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "fft.h"
#include "legacy_shimmer.h"
#include "wav.h"
#include "../../app/src/main/cpp/engine/reverb.h"

using namespace gb;

namespace {

constexpr int kSr = 48000;

struct Preset {
  const char* name;
  float mix, feedback, shift, dual, voice2, tone, spread, smooth;
};

// "AMBIENT" = the values of the project that ships with the original beta (shift 19, dual, tone wide open).
const Preset kPresets[] = {
    {"AMBIENT (shift 19, dual, tone 20k)", 0.7f, 0.7f, 19.f, 1.f, 0.5f, 20000.f, 0.65f, 1.0f},
    {"defaults (shift 12, tone 8k)", 0.25f, 0.5f, 12.f, 0.f, 0.5f, 8000.f, 0.6f, 0.5f},
    {"heavy (shift 12, dual, fb 0.9)", 0.6f, 0.9f, 12.f, 1.f, 0.5f, 12000.f, 0.8f, 0.7f},
};

void fill(float* P, const Preset& p) {
  for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
  P[P_SHIMMER_MIX] = p.mix;
  P[P_SHIMMER_FEEDBACK] = p.feedback;
  P[P_SHIMMER_SHIFT] = p.shift;
  P[P_SHIMMER_DUAL] = p.dual;
  P[P_SHIMMER_VOICE2] = p.voice2;
  P[P_SHIMMER_TONE] = p.tone;
  P[P_SHIMMER_SPREAD] = p.spread;
  P[P_SHIMMER_SMOOTH] = p.smooth;
}

struct Metrics {
  double centroid = 0, above4k = 0, above8k = 0, peaky = 0, rough = 0, rmsDb = 0, peakDb = 0;
};

// Welch-averaged power spectrum, 8192-point Hann frames.
std::vector<double> welch(const std::vector<float>& x, size_t from, size_t to) {
  const size_t N = 8192, hop = 4096;
  std::vector<double> acc(N / 2 + 1, 0.0);
  int frames = 0;
  for (size_t s = from; s + N <= to; s += hop) {
    auto p = ana::power(x, s, N);
    for (size_t i = 0; i < acc.size(); ++i) acc[i] += p[i];
    ++frames;
  }
  for (auto& v : acc) v /= std::max(1, frames);
  return acc;
}

Metrics measure(const std::vector<float>& x) {
  Metrics m;
  const size_t from = x.size() / 2, to = x.size();
  auto sp = welch(x, from, to);
  const double bin = static_cast<double>(kSr) / 8192.0;
  double tot = 0, cen = 0, e4 = 0, e8 = 0;
  for (size_t i = 1; i < sp.size(); ++i) {
    const double f = static_cast<double>(i) * bin;
    tot += sp[i];
    cen += sp[i] * f;
    if (f > 4000) e4 += sp[i];
    if (f > 8000) e8 += sp[i];
  }
  m.centroid = cen / std::max(tot, 1e-30);
  m.above4k = 10 * std::log10(std::max(e4 / std::max(tot, 1e-30), 1e-12));
  m.above8k = 10 * std::log10(std::max(e8 / std::max(tot, 1e-30), 1e-12));

  // ringing / metallic peaks: spread of the long-term spectrum above 2 kHz, 95th percentile vs median
  std::vector<double> band;
  for (size_t i = static_cast<size_t>(2000 / bin); i < static_cast<size_t>(10000 / bin); ++i) band.push_back(sp[i]);
  std::sort(band.begin(), band.end());
  if (!band.empty()) m.peaky = 10 * std::log10(band[band.size() * 95 / 100] / std::max(band[band.size() / 2], 1e-30));

  // roughness: modulation of the 2-8 kHz envelope between 20 and 150 Hz
  Biquad hp, lp;
  hp.setHighpass(static_cast<float>(kSr), 2000.f);
  lp.setLowpass(static_cast<float>(kSr), 8000.f);
  std::vector<float> env;
  float e = 0;
  const float k = 1.f - std::exp(-1.f / (0.002f * kSr));
  for (size_t i = from; i < to; ++i) {
    float b = lp.process(hp.process(x[i]));
    e += k * (std::fabs(b) - e);
    if ((i - from) % 48 == 0) env.push_back(e);  // 1 kHz envelope
  }
  double mean = 0;
  for (float v : env) mean += v;
  mean /= std::max<size_t>(1, env.size());
  std::vector<float> dc(env.size());
  for (size_t i = 0; i < env.size(); ++i) dc[i] = static_cast<float>(env[i] - mean);
  size_t n = 1;
  while (n * 2 <= dc.size()) n *= 2;
  auto ps = ana::power(dc, 0, n);
  double mod = 0;
  for (size_t i = 1; i < ps.size(); ++i) {
    const double f = static_cast<double>(i) * 1000.0 / static_cast<double>(n);
    if (f >= 20 && f <= 150) mod += ps[i];
  }
  // normalise: energy of the modulation relative to the envelope mean (squared) and the window
  m.rough = 10 * std::log10(std::max(mod / (static_cast<double>(n) * n * 0.375 * mean * mean + 1e-30), 1e-12));

  double s2 = 0, pk = 0;
  for (size_t i = from; i < to; ++i) { s2 += static_cast<double>(x[i]) * x[i]; pk = std::max(pk, static_cast<double>(std::fabs(x[i]))); }
  m.rmsDb = 10 * std::log10(s2 / static_cast<double>(to - from) + 1e-20);
  m.peakDb = 20 * std::log10(pk + 1e-20);
  return m;
}

void writeWav(const std::string& path, const std::vector<float>& l, const std::vector<float>& r) {
  FILE* f = std::fopen(path.c_str(), "wb");
  if (!f) return;
  const uint32_t n = static_cast<uint32_t>(l.size()), bytes = n * 4;
  auto w32 = [&](uint32_t v) { std::fwrite(&v, 4, 1, f); };
  auto w16 = [&](uint16_t v) { std::fwrite(&v, 2, 1, f); };
  std::fwrite("RIFF", 1, 4, f); w32(36 + bytes); std::fwrite("WAVEfmt ", 1, 8, f);
  w32(16); w16(1); w16(2); w32(kSr); w32(kSr * 4); w16(4); w16(16); std::fwrite("data", 1, 4, f); w32(bytes);
  for (size_t i = 0; i < l.size(); ++i) {
    int16_t a = static_cast<int16_t>(std::lround(std::max(-1.f, std::min(1.f, l[i])) * 32767.f));
    int16_t b = static_cast<int16_t>(std::lround(std::max(-1.f, std::min(1.f, r[i])) * 32767.f));
    std::fwrite(&a, 2, 1, f); std::fwrite(&b, 2, 1, f);
  }
  std::fclose(f);
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) { std::fprintf(stderr, "usage: shimmer_eval pad.wav [seconds] [dump_dir]\n"); return 2; }
  WavData w;
  if (!readWav(argv[1], w)) { std::fprintf(stderr, "cannot read %s\n", argv[1]); return 2; }
  if (w.sampleRate != kSr) {  // plain linear resampling is enough for an evaluation signal
    const double ratio = static_cast<double>(w.sampleRate) / kSr;
    const size_t n = static_cast<size_t>(static_cast<double>(w.l.size()) / ratio);
    std::vector<float> l(n), r(n);
    for (size_t i = 0; i < n; ++i) {
      const double pos = static_cast<double>(i) * ratio;
      const size_t i0 = static_cast<size_t>(pos), i1 = std::min(i0 + 1, w.l.size() - 1);
      const float f = static_cast<float>(pos - static_cast<double>(i0));
      l[i] = w.l[i0] + (w.l[i1] - w.l[i0]) * f;
      r[i] = w.r[i0] + (w.r[i1] - w.r[i0]) * f;
    }
    w.l.swap(l); w.r.swap(r); w.sampleRate = kSr;
  }
  const double secs = argc > 2 ? std::atof(argv[2]) : 24.0;
  const std::string dump = argc > 3 ? argv[3] : "";
  const size_t total = static_cast<size_t>(secs * kSr);

  std::printf("%-38s %-7s %9s %8s %8s %8s %8s %8s\n", "", "", "centroid", ">4k dB", ">8k dB", "peaky", "rough", "rms dB");
  for (const auto& pr : kPresets) {
    float P[P_COUNT];
    fill(P, pr);
    for (int which = 0; which < 2; ++which) {
      std::vector<float> outL(total), outR(total);
      if (which == 0) {
        legacy::Shimmer sh;
        sh.prepare(kSr);
        sh.setParams(P);
        for (size_t i = 0; i < total; ++i) {
          const size_t j = i % w.l.size();
          sh.process(w.l[j] * pr.mix, w.r[j] * pr.mix, outL[i], outR[i]);
        }
      } else {
        Shimmer sh;
        sh.prepare(kSr);
        sh.setParams(P);
        std::vector<float> iL(64), iR(64);
        for (size_t i = 0; i + 64 <= total; i += 64) {
          for (size_t k = 0; k < 64; ++k) { const size_t j = (i + k) % w.l.size(); iL[k] = w.l[j] * pr.mix; iR[k] = w.r[j] * pr.mix; }
          sh.processBlock(iL.data(), iR.data(), outL.data() + i, outR.data() + i, 64);
        }
      }
      const Metrics m = measure(outL);
      std::printf("%-38s %-7s %7.0f Hz %8.1f %8.1f %6.1f dB %6.1f dB %6.1f\n", which == 0 ? pr.name : "", which == 0 ? "legacy" : "new",
                  m.centroid, m.above4k, m.above8k, m.peaky, m.rough, m.rmsDb);
      if (!dump.empty()) {
        std::string tag = std::string(pr.name).substr(0, 7);
        for (auto& c : tag) if (c == ' ' || c == '(') c = '_';
        writeWav(dump + "/shim_" + tag + (which == 0 ? "_legacy.wav" : "_new.wav"), outL, outR);
      }
    }
  }
  return 0;
}
