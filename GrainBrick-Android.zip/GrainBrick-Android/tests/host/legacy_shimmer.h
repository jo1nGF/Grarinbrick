// Frozen copy of the first shimmer implementation (two-tap delay-line pitch shifter in a reverb
// feedback loop). Kept ONLY for the evaluation tools in tests/host, so the new SoundTouch based
// shimmer can be compared against what it replaced. Not part of the app.
#pragma once
#include "../../app/src/main/cpp/engine/reverb.h"

namespace gb {
namespace legacy {

// ---------------------------------------------------------------------------------------------
// Two-tap crossfading delay-line pitch shifter (mono).
// ---------------------------------------------------------------------------------------------
class PitchShifter {
 public:
  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    buf_.init(static_cast<int>(0.25f * sr_));
    phase_ = 0.f;
  }
  void reset() { buf_.clear(); phase_ = 0.f; }
  void setPhase(float p) { phase_ = p; }
  void set(float ratio, float windowSamples) {
    ratio_ = ratio;
    win_ = clampf(windowSamples, 64.f, static_cast<float>(buf_.capacity() - 16));
  }
  inline float process(float x) {
    buf_.write(x);
    phase_ += (1.0f - ratio_) / win_;
    phase_ -= std::floor(phase_);
    float p2 = phase_ + 0.5f;
    if (p2 >= 1.f) p2 -= 1.f;
    float d1 = phase_ * win_ + 2.f, d2 = p2 * win_ + 2.f;
    float tri = 1.0f - std::fabs(2.0f * phase_ - 1.0f);
    float w1 = smoothstep(tri);
    return w1 * buf_.read(d1) + (1.0f - w1) * buf_.read(d2);
  }

 private:
  float sr_ = 48000.f, phase_ = 0.f, ratio_ = 2.f, win_ = 2048.f;
  DelayLine buf_;
};

// ---------------------------------------------------------------------------------------------
// Shimmer: long reverb whose output is pitch shifted and fed back into its own input.
// ---------------------------------------------------------------------------------------------
class Shimmer {
 public:
  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    rev_.prepare(sampleRate, 0.05f);
    for (int v = 0; v < 2; ++v) {
      for (int c = 0; c < 2; ++c) {
        ps_[v][c].prepare(sampleRate);
        ps_[v][c].setPhase(0.25f * static_cast<float>(v * 2 + c));
      }
    }
    reset();
  }
  void reset() {
    rev_.reset();
    for (int v = 0; v < 2; ++v) for (int c = 0; c < 2; ++c) ps_[v][c].reset();
    fbL_ = fbR_ = 0.f;
    lpL_.reset(); lpR_.reset(); hpL_.reset(); hpR_.reset();
  }

  void setParams(const float* P) {
    fb_ = P[P_SHIMMER_FEEDBACK];
    dual_ = P[P_SHIMMER_DUAL] > 0.5f;
    v2_ = dual_ ? P[P_SHIMMER_VOICE2] : 0.f;
    spread_ = P[P_SHIMMER_SPREAD];
    toneA_ = lowpassCoef(P[P_SHIMMER_TONE], sr_);
    hpA_ = lowpassCoef(120.f, sr_);
    const float shift = P[P_SHIMMER_SHIFT];
    const float win = (0.03f + 0.09f * P[P_SHIMMER_SMOOTH]) * sr_;
    for (int c = 0; c < 2; ++c) {
      ps_[0][c].set(semitonesToRatio(shift), win);
      ps_[1][c].set(semitonesToRatio(clampf(shift - 7.f, -24.f, 24.f)), win);
    }
    rev_.setParams(0.75f, 6.0f, P[P_SHIMMER_TONE], 0.8f, 0.4f, 0.3f, 0.f, 1.f);
  }

  inline void process(float inL, float inR, float& wetL, float& wetR) {
    float xl = inL + fbL_ * fb_, xr = inR + fbR_ * fb_;
    float wl, wr;
    rev_.process(xl, xr, wl, wr);
    float vl = ps_[0][0].process(wl), vr = ps_[0][1].process(wr);
    if (dual_) {
      float s2l = ps_[1][0].process(wl), s2r = ps_[1][1].process(wr);
      float k = 1.0f / (1.0f + v2_);
      vl = (vl + v2_ * s2l) * k;
      vr = (vr + v2_ * s2r) * k;
    }
    float m = 0.5f * (vl + vr), s = 0.5f * (vl - vr) * (0.4f + 1.2f * spread_);
    vl = m + s;
    vr = m - s;
    fbL_ = hpL_.hp(lpL_.lp(vl, toneA_), hpA_);
    fbR_ = hpR_.hp(lpR_.lp(vr, toneA_), hpA_);
    wetL = wl;
    wetR = wr;
  }

 private:
  float sr_ = 48000.f, fb_ = 0.5f, v2_ = 0.f, spread_ = 0.6f, toneA_ = 0.5f, hpA_ = 0.01f;
  bool dual_ = false;
  Reverb rev_;
  PitchShifter ps_[2][2];
  float fbL_ = 0.f, fbR_ = 0.f;
  OnePole lpL_, lpR_, hpL_, hpR_;
};


}  // namespace legacy
}  // namespace gb
