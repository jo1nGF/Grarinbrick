// Tiny radix-2 FFT + analysis helpers for the host-side evaluation tools. Not used by the app.
#pragma once
#include <cmath>
#include <complex>
#include <vector>

namespace ana {

inline void fft(std::vector<std::complex<double>>& a) {
  const size_t n = a.size();
  for (size_t i = 1, j = 0; i < n; ++i) {
    size_t bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) std::swap(a[i], a[j]);
  }
  for (size_t len = 2; len <= n; len <<= 1) {
    double ang = -2.0 * M_PI / static_cast<double>(len);
    std::complex<double> wl(std::cos(ang), std::sin(ang));
    for (size_t i = 0; i < n; i += len) {
      std::complex<double> w(1);
      for (size_t j = 0; j < len / 2; ++j) {
        auto u = a[i + j], v = a[i + j + len / 2] * w;
        a[i + j] = u + v;
        a[i + j + len / 2] = u - v;
        w *= wl;
      }
    }
  }
}

// Power spectrum (Hann window) of x[start .. start+n), n power of two. Returns n/2+1 bins.
inline std::vector<double> power(const std::vector<float>& x, size_t start, size_t n) {
  std::vector<std::complex<double>> a(n);
  for (size_t i = 0; i < n; ++i) {
    double w = 0.5 - 0.5 * std::cos(2.0 * M_PI * static_cast<double>(i) / static_cast<double>(n));
    a[i] = (start + i < x.size() ? x[start + i] : 0.f) * w;
  }
  fft(a);
  std::vector<double> p(n / 2 + 1);
  for (size_t i = 0; i < p.size(); ++i) p[i] = std::norm(a[i]);
  return p;
}

}  // namespace ana
