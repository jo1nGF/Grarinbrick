// GrainBrick Android: the original header drives a hardware debug pin of the module. The resonator only
// includes it; nothing is used on Android, so this stub is intentionally empty.
#ifndef ELEMENTS_DRIVERS_DEBUG_PIN_H_
#define ELEMENTS_DRIVERS_DEBUG_PIN_H_
#endif
