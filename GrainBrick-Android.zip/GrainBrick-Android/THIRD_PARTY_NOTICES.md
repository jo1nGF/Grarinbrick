# Third-party notices

## Oboe 1.11.0

* Location: `third_party/oboe/` (unmodified source of the library; the full license text is in `third_party/oboe/LICENSE`).
* Copyright 2016 The Android Open Source Project
* License: Apache License 2.0 — <https://www.apache.org/licenses/LICENSE-2.0>
* Project: <https://github.com/google/oboe>

Oboe is compiled into `libgrainbrick.so` and is used for low-latency audio output and input.

## SoundTouch 2.3.2

* Location: `third_party/soundtouch/` (license text: `third_party/soundtouch/COPYING.LGPL-2.1.txt`).
* Copyright (c) Olli Parviainen
* License: GNU Lesser General Public License 2.1 — <https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html>
* Project: <https://www.surina.net/soundtouch/> / <https://codeberg.org/soundtouch/soundtouch>

SoundTouch pitch-shifts the voices of the shimmer. The source was taken from the SoundTouch
source archive that is redistributed (as LGPL compliance material) with GrainBrick 1.0.0-beta.1.
A few small changes keep it from allocating memory on the audio thread; each one is marked
"GrainBrick change" in the code and listed in `third_party/soundtouch/MODIFICATIONS.txt`.

It is built as a separate shared library (`libSoundTouch.so`) that the app reaches only through
the plain C functions in `app/src/main/cpp/engine/st_bridge.h`. As the LGPL asks, you can rebuild
the app from this repository, or replace `libSoundTouch.so` inside the APK with your own build
of SoundTouch that exports the same functions (`app/src/main/cpp/soundtouch/st_bridge.cpp`).

## Mutable Instruments Rings and Elements (and stmlib)

* Location: `third_party/mutable/` (`rings/`, `elements/`, `stmlib/`; license text: `third_party/mutable/stmlib/LICENSE`).
* Copyright 2012-2015 Emilie Gillet (Mutable Instruments)
* License: MIT — the copyright and permission notice is kept in every file and in `stmlib/LICENSE`.
* Project: <https://github.com/pichenettes/eurorack>

The original firmware DSP of the Rings and Elements modules is used for the RINGS and ELEMENTS ORBIX
(compiled with `-DTEST`, i.e. without the ARM assembly). Changes: the string-synth part of Rings is left
out, `elements/drivers/debug_pin.h` is an empty stub, and `elements/dsp/voice.cc` clamps the damping to 1
(marked "GrainBrick Android"). No code of the GPL-3 VCV Rack wrapper is used.

## Build-time tools (not distributed in the APK)

* Android Gradle Plugin, Kotlin Gradle Plugin, Gradle wrapper — Apache License 2.0.
* Android SDK / NDK / CMake — see the respective vendors' licenses.

## Relationship to the original GrainBrick

This application is an independent re-implementation. It contains no code, binaries, audio or presets from *GrainBrick 1.0.0-beta.1* (TrimUI Brick / KNULLI) and is not affiliated with its author. The one thing it shares with that package is SoundTouch, an open-source library (LGPL-2.1) that the original also links against and whose source is distributed with it. The project file format (`parameters` dictionary with keys such as `grain.size`) is read for interoperability.
