// Top-level build file. Versions follow the documented compatibility matrix:
//   AGP 8.13.0 needs Gradle >= 8.13 (the wrapper uses 8.14.3) and supports compileSdk up to 36.1;
//   Kotlin 2.3.21 supports AGP 8.2.2 - 9.0.0 and Gradle 7.6.3 - 9.3.0.
plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "2.3.21" apply false
}
