package com.grainbrick.android

import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

const val KIND_KNOB = 0
const val KIND_TOGGLE = 1
const val KIND_CHOICE = 2
const val CURVE_LOG = 1

/** One engine parameter. The registry lives in C++ (engine/params.h) and is read once at startup. */
class ParamDef(
    val index: Int,
    val id: String,
    val group: String,
    val label: String,
    val unit: String,
    val min: Float,
    val max: Float,
    val def: Float,
    val kind: Int,
    val curve: Int,
    val choices: List<String>,
    val help: String,
) {
    val isToggle: Boolean get() = kind == KIND_TOGGLE
    val isChoice: Boolean get() = kind == KIND_CHOICE

    fun toNorm(v: Float): Float {
        val c = v.coerceIn(min, max)
        return if (curve == CURVE_LOG && min > 0f) ln(c / min) / ln(max / min) else (c - min) / (max - min)
    }

    fun fromNorm(n: Float): Float {
        val t = n.coerceIn(0f, 1f)
        val v = if (curve == CURVE_LOG && min > 0f) min * exp(t * ln(max / min)) else min + t * (max - min)
        return v.coerceIn(min, max) // exp/ln rounding must never push a knob past its range
    }

    fun choiceIndex(v: Float): Int = (v - min).roundToInt().coerceIn(0, (choices.size - 1).coerceAtLeast(0))

    fun format(v: Float): String {
        if (isToggle) return if (v > 0.5f) "ON" else "OFF"
        if (isChoice) return choices.getOrElse(choiceIndex(v)) { v.roundToInt().toString() }
        val l = Locale.US
        return when (unit) {
            "Hz" -> if (v >= 1000f) String.format(l, "%.1f kHz", v / 1000f) else String.format(l, "%.0f Hz", v)
            "ms" -> if (v >= 1000f) String.format(l, "%.2f s", v / 1000f) else if (v < 10f) String.format(l, "%.1f ms", v) else String.format(l, "%.0f ms", v)
            "s" -> String.format(l, "%.2f s", v)
            "%" -> String.format(l, "%.0f%%", v)
            "dB" -> String.format(l, "%+.1f dB", v)
            "st" -> String.format(l, "%+.1f st", v)
            else -> if (abs(max - min) <= 2f) String.format(l, "%.2f", v) else String.format(l, "%.1f", v)
        }
    }
}

object Params {
    /** Display order of the parameter pages. */
    val groupOrder = listOf(
        "GRAIN", "MOTION", "ROAM", "TAPE", "EQ", "COMP", "DELAY", "REVERB", "SHIMMER", "ORBIX", "SMOOTH", "MIX",
    )

    var all: List<ParamDef> = emptyList()
        private set
    private var byIdMap: Map<String, ParamDef> = emptyMap()

    /** Parses one line of the native registry (see jni_bridge.cpp nParamInfo); null if malformed. */
    fun parse(index: Int, line: String): ParamDef? {
        val f = line.split('\t')
        if (f.size < 11) return null
        return try {
            ParamDef(
                index = index,
                id = f[0], group = f[1], label = f[2], unit = f[3],
                min = f[4].toFloat(), max = f[5].toFloat(), def = f[6].toFloat(),
                kind = f[7].toInt(), curve = f[8].toInt(),
                choices = if (f[9].isEmpty()) emptyList() else f[9].split('|'),
                help = f[10],
            )
        } catch (e: NumberFormatException) {
            null
        }
    }

    fun install(defs: List<ParamDef>) {
        all = defs
        byIdMap = defs.associateBy { it.id }
    }

    fun load() {
        if (all.isNotEmpty()) return
        val n = NativeEngine.nParamCount()
        val list = ArrayList<ParamDef>(n)
        for (i in 0 until n) parse(i, NativeEngine.nParamInfo(i))?.let { list.add(it) }
        install(list)
    }

    fun byId(id: String): ParamDef? = byIdMap[id]

    fun inGroup(group: String): List<ParamDef> = all.filter { it.group == group && it.id != "transport.playing" }

    val playing: ParamDef get() = byIdMap.getValue("transport.playing")
}
