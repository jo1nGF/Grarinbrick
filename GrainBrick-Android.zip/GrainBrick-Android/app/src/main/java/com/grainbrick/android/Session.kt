package com.grainbrick.android

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.grainbrick.android.audio.AudioDecoder
import com.grainbrick.android.audio.DemoSample
import com.grainbrick.android.audio.ProjectCodec
import com.grainbrick.android.audio.ProjectData
import com.grainbrick.android.audio.ProjectStore
import com.grainbrick.android.audio.RecordingCleanup
import com.grainbrick.android.audio.WavIO
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Process-wide app state: the engine, the loaded sample, the project library and the audio
 * lifecycle. Everything that touches UI-visible state runs on the main thread; file decoding and
 * writing happen on one background thread.
 */
object Session {
    private const val PREFS = "grainbrick"
    private const val KEY_OUT = "out_device"
    private const val KEY_IN = "in_device"
    private const val IDLE_SHUTDOWN_MS = 20_000L
    private const val AUTOSAVE = "autosave.json"
    private const val LIVE_ID = "live.level"
    private const val PLAYING_ID = "transport.playing"

    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "gb-io").also { it.isDaemon = true } }
    private var initialized = false

    lateinit var projects: ProjectStore
        private set
    lateinit var samplesDir: File
        private set

    val context: Context get() = app

    var sample: SampleBuffer? = null
        private set
    var projectName: String = "UNTITLED"
        private set

    /** Bumped whenever parameters change from outside the controls (project load). */
    var paramRevision = 0
        private set
    var sampleRevision = 0
        private set
    var libraryRevision = 0
        private set

    var outputDeviceId = 0
        private set
    var inputDeviceId = 0
        private set

    var activityVisible = false
        set(v) {
            field = v
            if (v) {
                cancelIdleShutdown()
                if (initialized) ensureAudio()
            } else if (!isPlaying && !recording) {
                scheduleIdleShutdown()
            }
        }

    var recording = false
        private set
    private var inputForced = false

    /** Human-readable notices (errors, "sample not found"...). The activity shows them as toasts. */
    var messageListener: ((String) -> Unit)? = null
    private val pendingMessages = ArrayList<String>()

    private var presetCache: List<ProjectData>? = null

    // ------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------
    fun init(context: Context) {
        if (initialized) return
        app = context.applicationContext
        NativeEngine.nInit()
        Params.load()
        projects = ProjectStore(File(app.filesDir, "projects"))
        samplesDir = File(app.filesDir, "samples").also { it.mkdirs() }
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        outputDeviceId = prefs.getInt(KEY_OUT, 0)
        inputDeviceId = prefs.getInt(KEY_IN, 0)
        initialized = true

        var restored = false
        val auto = File(app.filesDir, AUTOSAVE)
        if (auto.isFile) {
            try {
                val p = ProjectCodec.decode(auto.readText(Charsets.UTF_8), "UNTITLED")
                applyProject(p)
                restored = true
            } catch (e: Exception) {
                auto.delete()
            }
        }
        if (!restored) {
            val first = presets().firstOrNull()
            if (first != null) applyProject(first) else loadDemoAsync()
        }
    }

    fun saveAutosave() {
        if (!initialized) return
        try {
            val tmp = File(app.filesDir, "$AUTOSAVE.tmp")
            tmp.writeText(ProjectCodec.encode(captureProject(projectName)), Charsets.UTF_8)
            val dst = File(app.filesDir, AUTOSAVE)
            if (!tmp.renameTo(dst)) {
                dst.delete()
                tmp.renameTo(dst)
            }
        } catch (_: Exception) {
        }
    }

    fun say(msg: String) {
        main.post {
            val l = messageListener
            if (l != null) l(msg) else synchronized(pendingMessages) { pendingMessages.add(msg) }
        }
    }

    fun drainMessages(): List<String> = synchronized(pendingMessages) {
        val copy = ArrayList(pendingMessages)
        pendingMessages.clear()
        copy
    }

    // ------------------------------------------------------------------------------------
    // parameters
    // ------------------------------------------------------------------------------------
    fun getParam(d: ParamDef): Float = NativeEngine.nGetParam(d.index)
    fun setParam(d: ParamDef, v: Float) = NativeEngine.nSetParam(d.index, v)
    fun setParam(id: String, v: Float) {
        val d = Params.byId(id) ?: return
        NativeEngine.nSetParam(d.index, v)
    }

    fun getParam(id: String): Float = Params.byId(id)?.let { NativeEngine.nGetParam(it.index) } ?: 0f

    /** Called when a user gesture on a control ends. */
    fun onParamGestureEnd(d: ParamDef) {
        if (d.id == LIVE_ID) applyRouting()
    }

    // ------------------------------------------------------------------------------------
    // transport & audio
    // ------------------------------------------------------------------------------------
    val isPlaying: Boolean get() = initialized && Params.byId(PLAYING_ID)?.let { NativeEngine.nGetParam(it.index) > 0.5f } == true

    fun setPlaying(on: Boolean) {
        val d = Params.byId(PLAYING_ID) ?: return
        if (on) {
            cancelIdleShutdown()
            ensureAudio()
            PlaybackService.start(app)
        }
        NativeEngine.nSetParam(d.index, if (on) 1f else 0f)
        if (!on) scheduleIdleShutdown()
        paramRevision++
    }

    fun hasMicPermission(): Boolean =
        app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun desiredInput(): Boolean = hasMicPermission() && (inputForced || getParam(LIVE_ID) > 0.001f)

    /** Starts the audio streams if they are not running. Returns an error text or "". */
    fun ensureAudio(): String {
        if (!initialized || NativeEngine.nIsRunning()) return ""
        return startAudioNow()
    }

    private fun startAudioNow(): String {
        val err = NativeEngine.nStartAudio(outputDeviceId, inputDeviceId, desiredInput())
        if (err.isNotEmpty()) say(err)
        val m = NativeEngine.nMessage()
        if (err.isEmpty() && m.isNotEmpty()) say(m)
        return err
    }

    fun restartAudio() {
        if (!initialized) return
        NativeEngine.nStopAudio()
        startAudioNow()
    }

    /** Set by the activity: asks for the microphone permission and calls back once it is granted. */
    var micRequest: ((() -> Unit) -> Unit)? = null

    /** Re-opens the streams when the need for the input device changed (live level, recording). */
    fun applyRouting() {
        if (!initialized || !NativeEngine.nIsRunning()) return
        if (getParam(LIVE_ID) > 0.001f && !hasMicPermission()) {
            micRequest?.invoke { applyRouting() }
            return
        }
        val want = desiredInput()
        if (want != NativeEngine.nInputActive()) {
            if (want) say("Live input on - use headphones to avoid feedback.")
            restartAudio()
        }
    }

    fun setDevices(outId: Int, inId: Int) {
        outputDeviceId = outId
        inputDeviceId = inId
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_OUT, outId).putInt(KEY_IN, inId).apply()
        if (NativeEngine.nIsRunning()) restartAudio()
    }

    fun audioStatus(): String {
        if (!NativeEngine.nIsRunning()) return "Audio stopped"
        val inTxt = if (NativeEngine.nInputActive()) " | input on" else ""
        return "${NativeEngine.nSampleRate()} Hz | burst ${NativeEngine.nFramesPerBurst()}$inTxt"
    }

    private val idleRunnable = Runnable {
        if (!isPlaying && !recording) {
            PlaybackService.stop(app)
            if (!activityVisible) NativeEngine.nStopAudio()
        }
    }

    private fun scheduleIdleShutdown() {
        main.removeCallbacks(idleRunnable)
        main.postDelayed(idleRunnable, IDLE_SHUTDOWN_MS)
    }

    private fun cancelIdleShutdown() = main.removeCallbacks(idleRunnable)

    // ------------------------------------------------------------------------------------
    // samples
    // ------------------------------------------------------------------------------------
    fun setSample(buf: SampleBuffer?) {
        sample = buf
        if (buf == null) NativeEngine.nSetSample(null, null, 0, 48000)
        else NativeEngine.nSetSample(buf.left, if (buf.mono) buf.left else buf.right, buf.frames, buf.sampleRate)
        sampleRevision++
    }

    fun listSamples(): List<File> =
        (samplesDir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) } ?: emptyArray())
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })

    fun loadDemoAsync() {
        io.execute {
            try {
                val f = File(samplesDir, DemoSample.FILE)
                val buf = if (f.isFile) readSampleFile(f) else DemoSample.generate().also { writeWav(f, it) }
                buf.name = DemoSample.NAME
                buf.relPath = "samples/${DemoSample.FILE}"
                main.post { setSample(buf) }
            } catch (e: Throwable) {
                say("Could not prepare the demo sample: ${e.message}")
            }
        }
    }

    fun loadSampleFileAsync(f: File) {
        io.execute {
            try {
                val buf = readSampleFile(f)
                main.post { setSample(buf) }
            } catch (e: OutOfMemoryError) {
                say("Not enough memory to load ${f.name}")
            } catch (e: Exception) {
                say("Could not load ${f.name}: ${e.message}")
            }
        }
    }

    private fun readSampleFile(f: File): SampleBuffer {
        val d = f.inputStream().buffered().use { WavIO.read(it, maxSeconds = AudioDecoder.MAX_SECONDS) }
        val buf = SampleBuffer(f.name.removeSuffix(".wav").removeSuffix(".WAV"), d.left, d.right, d.sampleRate, "samples/${f.name}", d.mono)
        return buf
    }

    private fun writeWav(f: File, s: SampleBuffer) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        FileOutputStream(tmp).buffered().use { WavIO.write(it, s.left, s.right, s.sampleRate, s.mono) }
        if (!tmp.renameTo(f)) {
            f.delete()
            if (!tmp.renameTo(f)) throw java.io.IOException("Could not write ${f.name}")
        }
    }

    private fun uniqueSampleFile(base: String): File {
        val clean = ProjectCodec.sanitizeName(base)
        var f = File(samplesDir, "$clean.wav")
        var i = 2
        while (f.exists()) f = File(samplesDir, "$clean $i.wav").also { i++ }
        return f
    }

    fun importSampleAsync(uri: Uri, displayName: String) {
        io.execute {
            try {
                val r = AudioDecoder.decode(app, uri, displayName)
                val buf = r.sample
                val file = uniqueSampleFile(buf.name)
                writeWav(file, buf)
                buf.name = file.name.removeSuffix(".wav")
                buf.relPath = "samples/${file.name}"
                main.post {
                    setSample(buf)
                    libraryRevision++
                }
                say(if (r.truncated) "Loaded the first ${AudioDecoder.MAX_SECONDS} s of ${buf.name}" else "Loaded ${buf.name}")
            } catch (e: OutOfMemoryError) {
                say("Not enough memory to load that file")
            } catch (e: Exception) {
                say("Could not load the file: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun deleteSample(f: File): Boolean {
        val ok = f.delete()
        if (ok) libraryRevision++
        return ok
    }

    /** Saves the selected part of the current sample as a new file and switches to it. */
    fun trimAsync(startFrac: Float, endFrac: Float) {
        val s = sample ?: return
        io.execute {
            try {
                val cropped = s.crop(startFrac, endFrac, s.name.removeSuffix(" trim") + " trim")
                val file = uniqueSampleFile(cropped.name)
                writeWav(file, cropped)
                cropped.name = file.name.removeSuffix(".wav")
                cropped.relPath = "samples/${file.name}"
                main.post {
                    setSample(cropped)
                    libraryRevision++
                }
                say("Saved ${cropped.name} (${Math.round(cropped.seconds * 10f) / 10f} s)")
            } catch (e: Exception) {
                say("Trim failed: ${e.message}")
            }
        }
    }

    // ------------------------------------------------------------------------------------
    // recording
    // ------------------------------------------------------------------------------------
    /** @return an error message, or null when recording started. */
    fun startRecording(): String? {
        if (!initialized) return "Not ready"
        if (recording) return null
        if (!hasMicPermission()) return "Microphone permission is required to record."
        inputForced = true
        if (NativeEngine.nIsRunning() && !NativeEngine.nInputActive()) restartAudio() else ensureAudio()
        if (!NativeEngine.nInputActive()) {
            inputForced = false
            return "No audio input is available."
        }
        if (!NativeEngine.nStartRecording()) {
            inputForced = false
            return "Could not start recording."
        }
        recording = true
        cancelIdleShutdown()
        return null
    }

    fun stopRecording() {
        if (!recording) return
        recording = false
        NativeEngine.nStopRecording()
        val frames = NativeEngine.nRecordedFrames()
        val rate = NativeEngine.nRecordingSampleRate()
        inputForced = false
        if (frames < rate / 10) {
            say("Recording too short - nothing saved.")
            applyRouting()
            return
        }
        val inter = NativeEngine.nGetRecording()
        applyRouting()
        if (inter == null || inter.size < 2) return
        io.execute {
            try {
                val n = inter.size / 2
                val l = FloatArray(n)
                val r = FloatArray(n)
                var same = true
                for (i in 0 until n) {
                    l[i] = inter[2 * i]
                    r[i] = inter[2 * i + 1]
                    if (l[i] != r[i]) same = false
                }
                val take = RecordingCleanup.process(l, if (same) l else r, rate)
                if (take.silent) {
                    say("Nothing was recorded (silence). Check the microphone permission and the input device in SAMPLE > AUDIO I/O.")
                    return@execute
                }
                val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                val buf = SampleBuffer("REC $stamp", l, if (same) l else r, rate, null, same)
                val file = uniqueSampleFile(buf.name)
                writeWav(file, buf)
                buf.relPath = "samples/${file.name}"
                main.post {
                    setSample(buf)
                    libraryRevision++
                }
                val gainTxt = if (take.gain > 1.01f) String.format(Locale.US, " (+%.0f dB)", take.gainDb) else ""
                say("Recorded ${Math.round(buf.seconds * 10f) / 10f} s$gainTxt")
            } catch (e: Exception) {
                say("Could not save the recording: ${e.message}")
            }
        }
    }

    // ------------------------------------------------------------------------------------
    // projects
    // ------------------------------------------------------------------------------------
    fun presets(): List<ProjectData> {
        presetCache?.let { return it }
        val out = ArrayList<ProjectData>()
        val names = try { app.assets.list("presets") } catch (e: Exception) { null } ?: emptyArray()
        for (n in names.sorted()) {
            if (!n.endsWith(".json")) continue
            try {
                app.assets.open("presets/$n").bufferedReader(Charsets.UTF_8).use {
                    out.add(ProjectCodec.decode(it.readText(), n.removeSuffix(".json")))
                }
            } catch (e: Exception) {
                // a broken bundled preset must never break start-up
            }
        }
        presetCache = out
        return out
    }

    fun captureProject(name: String): ProjectData {
        val p = ProjectData(name)
        for (d in Params.all) {
            if (d.id == PLAYING_ID || d.id == LIVE_ID) continue
            p.params[d.id] = NativeEngine.nGetParam(d.index)
        }
        val s = sample
        val rel = s?.relPath
        if (rel != null) {
            p.samplePath = rel
            p.sampleType = if (rel.endsWith(DemoSample.FILE)) ProjectCodec.TYPE_BUILTIN else ProjectCodec.TYPE_RELATIVE
        }
        return p
    }

    /** Loads every parameter (missing ones go back to their default) and the project's sample. */
    fun applyProject(p: ProjectData) {
        for (d in Params.all) {
            if (d.id == PLAYING_ID || d.id == LIVE_ID) continue
            NativeEngine.nSetParam(d.index, p.params[d.id] ?: d.def)
        }
        projectName = p.name
        paramRevision++

        val fn = p.sampleFileName()
        when {
            p.sampleType == ProjectCodec.TYPE_BUILTIN || fn == DemoSample.FILE -> loadDemoAsync()
            fn != null -> {
                val f = File(samplesDir, fn)
                val safe = try { f.canonicalFile.parentFile == samplesDir.canonicalFile } catch (e: Exception) { false }
                if (safe && f.isFile) {
                    loadSampleFileAsync(f)
                } else {
                    say("Sample \"$fn\" is not in this app - keeping the current sample. Load it from the SAMPLE tab.")
                    if (sample == null) loadDemoAsync()
                }
            }
            else -> if (sample == null) loadDemoAsync()
        }
    }

    fun saveProject(name: String) {
        val p = captureProject(ProjectCodec.sanitizeName(name))
        projects.save(p)
        projectName = p.name
        libraryRevision++
    }

    fun deleteProject(name: String) {
        projects.delete(name)
        libraryRevision++
    }

    /** Imports project JSON text (also accepts the original GrainBrick format). Returns the project name. */
    fun importProjectText(text: String, fallbackName: String): String {
        val p = ProjectCodec.decode(text, fallbackName)
        p.name = projects.uniqueName(p.name)
        projects.save(p)
        libraryRevision++
        applyProject(p)
        return p.name
    }

    fun exportProjectText(name: String): String? = try {
        if (name == projectName || !projects.exists(name)) ProjectCodec.encode(captureProject(name))
        else ProjectCodec.encode(projects.load(name))
    } catch (e: Exception) {
        null
    }
}
