package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.Space
import com.grainbrick.android.ParamDef
import com.grainbrick.android.Params
import com.grainbrick.android.Session

/** Anything that mirrors an engine parameter and can re-read it (after a project load, say). */
interface ParamControl {
    fun sync()
}

/**
 * A square key with a label and a lamp: for ON/OFF parameters that live in a grid of knobs
 * (the TAPE page). Tap toggles, long-press shows the help text.
 */
class ToggleChip(context: Context, val def: ParamDef, private val onHelp: (ParamDef) -> Unit) :
    View(context), ParamControl {
    private val d = resources.displayMetrics.density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Ui.MONO_BOLD; textAlign = Paint.Align.CENTER; letterSpacing = 0.08f }
    private val lamp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f * d }
    private var on = Session.getParam(def) > 0.5f
    private val name = (if (def.id.endsWith(".enabled")) "ON/OFF" else def.label).uppercase()
    private val longPress = Runnable {
        held = true
        onHelp(def)
    }
    private var moved = false
    private var held = false

    init {
        isClickable = true
        contentDescription = def.label
    }

    override fun sync() {
        val v = Session.getParam(def) > 0.5f
        if (v != on) {
            on = v
            invalidate()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), resolveSize((100 * d).toInt(), heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = minOf(w * 0.62f, h * 0.56f)
        val cx = w / 2f
        val top = h * 0.08f
        frame.color = if (on) Ui.ACCENT else Ui.STROKE
        canvas.drawRect(cx - s / 2f, top, cx + s / 2f, top + s * 0.8f, frame)
        lamp.color = if (on) Ui.ACCENT else Ui.SURFACE2
        val r = s * 0.14f
        val cy = top + s * 0.4f
        if (on) {
            lamp.color = 0x44FF9F43
            canvas.drawCircle(cx, cy, r * 2.2f, lamp)
            lamp.color = Ui.ACCENT
        }
        canvas.drawCircle(cx, cy, r, lamp)
        text.textSize = 11f * d
        text.color = if (on) Ui.TEXT else Ui.DIM
        canvas.drawText(name, cx, h - 6f * d, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false
                held = false
                postDelayed(longPress, 500L)
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.x < 0f || e.y < 0f || e.x > width || e.y > height) {
                    moved = true
                    removeCallbacks(longPress)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (!held && !moved) {
                    Session.setParam(def, if (Session.getParam(def) > 0.5f) 0f else 1f)
                    Session.onParamGestureEnd(def)
                    sync()
                    onHelp(def)
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longPress)
        }
        return true
    }
}

object ParamViews {
    /** Lays views out in rows of [columns] equally wide cells. */
    fun rows(ctx: Context, views: List<View>, columns: Int, gapDp: Int = 6): LinearLayout {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val gap = Ui.dp(ctx, gapDp)
        var i = 0
        while (i < views.size) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until columns) {
                val v: View = if (i + c < views.size) views[i + c] else Space(ctx)
                val lp = Ui.lp(0, Ui.WRAP, 1f)
                lp.setMargins(if (c == 0) 0 else gap / 2, gap / 2, if (c == columns - 1) 0 else gap / 2, gap / 2)
                row.addView(v, lp)
            }
            col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP))
            i += columns
        }
        return col
    }

    fun columnsFor(ctx: Context, minCellDp: Int = 84): Int {
        val dm = ctx.resources.displayMetrics
        val wDp = dm.widthPixels / dm.density - 32f
        return (wDp / minCellDp).toInt().coerceIn(3, 8)
    }

    fun knob(ctx: Context, id: String, controls: MutableList<ParamControl>, onHelp: (ParamDef) -> Unit): View? {
        val d = Params.byId(id) ?: return null
        val v = KnobView(ctx, d, onHelp)
        controls.add(v)
        return v
    }

    fun toggle(ctx: Context, id: String, controls: MutableList<ParamControl>, onHelp: (ParamDef) -> Unit): View? {
        val d = Params.byId(id) ?: return null
        val v = ToggleChip(ctx, d, onHelp)
        controls.add(v)
        return v
    }

    /**
     * One display panel: a title bar and a line per parameter of [group] (the STATE switch first,
     * then the other switches, the choices, the knobs).
     */
    fun lcdPanel(
        ctx: Context,
        group: String,
        controls: MutableList<ParamControl>,
        onHelp: (ParamDef) -> Unit,
        title: String = group,
    ): LinearLayout {
        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.glass(ctx)
        }
        panel.addView(
            Ui.text(ctx, title, 11f, Ui.ACCENT, true).apply {
                letterSpacing = 0.2f
                setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 10), Ui.dp(ctx, 12), Ui.dp(ctx, 8))
            },
            Ui.lp(Ui.MATCH, Ui.WRAP),
        )
        panel.addView(View(ctx).apply { setBackgroundColor(Ui.STROKE) }, Ui.lp(Ui.MATCH, Ui.dp(ctx, 1)))
        val defs = Params.inGroup(group)
        val ordered = defs.filter { it.isToggle && it.id.endsWith(".enabled") } +
            defs.filter { it.isToggle && !it.id.endsWith(".enabled") } +
            defs.filter { it.isChoice } +
            defs.filter { !it.isToggle && !it.isChoice }
        for (d in ordered) {
            val row = LcdRowView(ctx, d, onHelp)
            controls.add(row)
            panel.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        return panel
    }

    /** Panels next to each other on wide screens, stacked on phones. */
    fun columns(ctx: Context, panels: List<View>, gapDp: Int = 10): LinearLayout {
        val wide = Ui.isWide(ctx) && panels.size > 1
        val root = LinearLayout(ctx).apply {
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.TOP
        }
        val gap = Ui.dp(ctx, gapDp)
        for ((i, p) in panels.withIndex()) {
            val lp = if (wide) Ui.lp(0, Ui.WRAP, 1f) else Ui.lp(Ui.MATCH, Ui.WRAP)
            if (i > 0) { if (wide) lp.leftMargin = gap else lp.topMargin = gap }
            root.addView(p, lp)
        }
        return root
    }
}
