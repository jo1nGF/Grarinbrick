package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * Two-axis touch surface drawn like a plotter screen: fine grid, a cross-hair with a square
 * reticle, mono axis captions. Values are normalised 0..1 (y = 1 at the top).
 */
class XyPadView(context: Context) : View(context) {
    var onChange: ((Float, Float) -> Unit)? = null
    var xLabel = "POSITION"
    var yLabel = "SIZE"

    private var nx = 0.5f
    private var ny = 0.5f
    private var touching = false
    private val density = resources.displayMetrics.density
    private val grid = Paint().apply { color = 0xFF141A22.toInt(); strokeWidth = 1f }
    private val gridMajor = Paint().apply { color = Ui.STROKE; strokeWidth = 1f }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT_DIM; strokeWidth = 1f * density }
    private val reticle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT; style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT }
    private val marks = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.DIM; strokeWidth = 1.5f * density }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; textSize = 10f * density; typeface = Ui.MONO_BOLD; letterSpacing = 0.12f
    }

    init {
        background = Ui.glass(context)
    }

    fun setValues(x: Float, y: Float) {
        if (touching) return
        val cx = x.coerceIn(0f, 1f)
        val cy = y.coerceIn(0f, 1f)
        if (cx != nx || cy != ny) {
            nx = cx
            ny = cy
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1 until 16) {
            val p = if (i % 4 == 0) gridMajor else grid
            canvas.drawLine(w * i / 16f, 0f, w * i / 16f, h, p)
            canvas.drawLine(0f, h * i / 16f, w, h * i / 16f, p)
        }
        Ui.cornerMarks(canvas, w, h, 10f * density, marks)
        val px = nx * w
        val py = (1f - ny) * h
        canvas.drawLine(px, 0f, px, h, cross)
        canvas.drawLine(0f, py, w, py, cross)
        val r = (if (touching) 17f else 12f) * density
        canvas.drawRect(px - r, py - r, px + r, py + r, reticle)
        canvas.drawCircle(px, py, 2.5f * density, dot)
        label.textAlign = Paint.Align.LEFT
        canvas.drawText("Y " + yLabel, 12f * density, 20f * density, label)
        label.textAlign = Paint.Align.RIGHT
        canvas.drawText("X " + xLabel, w - 12f * density, h - 12f * density, label)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                parent?.requestDisallowInterceptTouchEvent(true)
                update(e)
            }
            MotionEvent.ACTION_MOVE -> update(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
            }
        }
        return true
    }

    private fun update(e: MotionEvent) {
        if (width <= 0 || height <= 0) return
        nx = (e.x / width).coerceIn(0f, 1f)
        ny = (1f - e.y / height).coerceIn(0f, 1f)
        onChange?.invoke(nx, ny)
        invalidate()
    }
}
