package com.grainbrick.android

/** Thin JNI facade over the C++ engine (see app/src/main/cpp/jni_bridge.cpp). */
object NativeEngine {
    init {
        System.loadLibrary("grainbrick")
    }

    external fun nInit(): Boolean

    // parameter registry
    external fun nParamCount(): Int
    external fun nParamInfo(index: Int): String
    external fun nSetParam(index: Int, value: Float)
    external fun nGetParam(index: Int): Float
    external fun nSnapParams()

    // sample
    external fun nSetSample(left: FloatArray?, right: FloatArray?, frames: Int, sampleRate: Int)

    // audio streams
    external fun nStartAudio(outDevice: Int, inDevice: Int, useInput: Boolean): String
    external fun nStopAudio()
    external fun nIsRunning(): Boolean
    external fun nInputActive(): Boolean
    external fun nSampleRate(): Int
    external fun nFramesPerBurst(): Int
    external fun nMessage(): String

    // UI state polling
    external fun nStateSize(): Int
    external fun nGetState(out: FloatArray)

    // recording
    external fun nStartRecording(): Boolean
    external fun nStopRecording()
    external fun nRecordedFrames(): Int
    external fun nRecordingSampleRate(): Int
    external fun nGetRecording(): FloatArray?
}
