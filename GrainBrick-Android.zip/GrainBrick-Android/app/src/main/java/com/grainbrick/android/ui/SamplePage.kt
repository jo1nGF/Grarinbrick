package com.grainbrick.android.ui

import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.grainbrick.android.EngineState
import com.grainbrick.android.Session
import com.grainbrick.android.audio.AudioDevices
import com.grainbrick.android.audio.DeviceItem
import java.io.File

/** Load, record, trim and manage samples; choose audio devices (USB audio included). */
class SamplePage(private val host: Host) : Page() {
    override val title = "SAMPLE"

    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private lateinit var nameText: TextView
    private lateinit var detailText: TextView
    private lateinit var trimText: TextView
    private lateinit var wave: WaveformView
    private lateinit var recButton: TextView
    private lateinit var trimButton: TextView
    private lateinit var inMeter: MeterView
    private lateinit var recText: TextView
    private lateinit var outSpinner: Spinner
    private lateinit var inSpinner: Spinner
    private lateinit var audioText: TextView
    private lateinit var library: LinearLayout
    private var outItems: List<DeviceItem> = emptyList()
    private var inItems: List<DeviceItem> = emptyList()
    private var binding = false
    private var shownRec: Boolean? = null
    private var shownAudio = ""

    override fun build(): View {
        val pad = Ui.dp(ctx, 16)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, Ui.dp(ctx, 8), pad, Ui.dp(ctx, 28))
        }

        // ---- current sample ----
        val card = Ui.card(ctx)
        nameText = Ui.text(ctx, "", 15f, Ui.TEXT, true).apply { letterSpacing = 0.04f }
        detailText = Ui.text(ctx, "", 12f, Ui.DIM).apply { setPadding(0, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 10)) }
        card.addView(nameText)
        card.addView(detailText)
        wave = WaveformView(ctx, WaveformView.MODE_TRIM)
        wave.onTrimChanged = { _, _ -> updateTrimText() }
        card.addView(wave, Ui.lp(Ui.MATCH, Ui.dp(ctx, 140)))
        trimText = Ui.text(ctx, "", 12f, Ui.DIM).apply { setPadding(0, Ui.dp(ctx, 8), 0, 0) }
        card.addView(trimText)
        col.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))

        // ---- actions ----
        val load = Ui.button(ctx, "LOAD FILE", true) { host.pickSampleFile() }
        recButton = Ui.button(ctx, "RECORD") { toggleRecord() }
        trimButton = Ui.button(ctx, "SAVE TRIM") { applyTrim() }
        val demo = Ui.button(ctx, "DEMO PAD") { Session.loadDemoAsync() }
        col.addView(ParamViews.rows(ctx, listOf(load, recButton, trimButton, demo), 2, 8), Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 12) })

        // ---- recording / live input ----
        col.addView(Ui.heading(ctx, "INPUT"))
        val inRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        inMeter = MeterView(ctx)
        recText = Ui.text(ctx, "INPUT IDLE", 12f, Ui.DIM)
        inRow.addView(inMeter, Ui.lp(0, Ui.dp(ctx, 12), 1f))
        inRow.addView(recText, Ui.lp(Ui.WRAP, Ui.WRAP).apply { leftMargin = Ui.dp(ctx, 12) })
        col.addView(inRow, Ui.lp(Ui.MATCH, Ui.WRAP))
        val live = ParamViews.knob(ctx, "live.level", controls, host::showHelp)
        if (live != null) {
            col.addView(ParamViews.rows(ctx, listOf(live), 4), Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 6) })
            col.addView(Ui.text(ctx, "Live in sends the microphone / USB input through the effects. Use headphones.", 11f, Ui.DIM))
        }

        // ---- audio devices ----
        col.addView(Ui.heading(ctx, "AUDIO I/O"))
        col.addView(Ui.text(ctx, "OUTPUT", 10f, Ui.DIM, true).apply { letterSpacing = 0.15f; setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 2)) })
        outSpinner = Spinner(ctx)
        col.addView(outSpinner, Ui.lp(Ui.MATCH, Ui.WRAP))
        col.addView(Ui.text(ctx, "INPUT", 10f, Ui.DIM, true).apply { letterSpacing = 0.15f; setPadding(0, Ui.dp(ctx, 10), 0, Ui.dp(ctx, 2)) })
        inSpinner = Spinner(ctx)
        col.addView(inSpinner, Ui.lp(Ui.MATCH, Ui.WRAP))
        audioText = Ui.text(ctx, "", 11f, Ui.DIM).apply { setPadding(0, Ui.dp(ctx, 6), 0, 0) }
        col.addView(audioText)
        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (binding) return
                val o = outItems.getOrNull(outSpinner.selectedItemPosition)?.id ?: 0
                val i = inItems.getOrNull(inSpinner.selectedItemPosition)?.id ?: 0
                if (o != Session.outputDeviceId || i != Session.inputDeviceId) Session.setDevices(o, i)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        outSpinner.onItemSelectedListener = listener
        inSpinner.onItemSelectedListener = listener

        // ---- library ----
        col.addView(Ui.heading(ctx, "SAMPLE LIBRARY"))
        library = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(library, Ui.lp(Ui.MATCH, Ui.WRAP))

        bindDevices()
        onSampleChanged()
        onLibraryChanged()
        return ScrollView(ctx).apply {
            setBackgroundColor(Ui.BG)
            addView(col, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun bindDevices() {
        binding = true
        outItems = AudioDevices.outputs(ctx)
        inItems = AudioDevices.inputs(ctx)
        outSpinner.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, outItems)
        inSpinner.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, inItems)
        outSpinner.setSelection(outItems.indexOfFirst { it.id == Session.outputDeviceId }.coerceAtLeast(0), false)
        inSpinner.setSelection(inItems.indexOfFirst { it.id == Session.inputDeviceId }.coerceAtLeast(0), false)
        binding = false
    }

    private fun toggleRecord() {
        if (Session.recording) {
            Session.stopRecording()
            return
        }
        host.requestMicrophone {
            val err = Session.startRecording()
            if (err != null) Session.say(err)
        }
    }

    private fun applyTrim() {
        val s = wave.trimStart
        val e = wave.trimEnd
        if (Session.sample == null) return
        if (s <= 0.0005f && e >= 0.9995f) {
            Session.say("Drag the handles on the waveform to choose the part to keep.")
            return
        }
        Session.trimAsync(s, e)
    }

    private fun updateTrimText() {
        val smp = Session.sample
        if (smp == null) {
            trimText.text = ""
            return
        }
        val a = wave.trimStart * smp.seconds
        val b = wave.trimEnd * smp.seconds
        trimText.text = "Selection ${Ui.formatTime(a)} - ${Ui.formatTime(b)}  (${Ui.formatTime(b - a)})"
    }

    override fun onSampleChanged() {
        val s = Session.sample
        wave.setSample(s)
        nameText.text = s?.name?.uppercase() ?: "NO SAMPLE"
        detailText.text = if (s == null) "Load a file, record from the microphone or use the demo pad."
        else "${Ui.formatTime(s.seconds)}  |  ${s.sampleRate} Hz  |  ${if (s.mono) "MONO" else "STEREO"}"
        updateTrimText()
    }

    override fun onLibraryChanged() {
        library.removeAllViews()
        val files = Session.listSamples()
        if (files.isEmpty()) {
            library.addView(Ui.text(ctx, "Nothing saved yet. Loaded and recorded samples appear here.", 12f, Ui.DIM))
            return
        }
        for (f in files) library.addView(libraryRow(f), Ui.lp(Ui.MATCH, Ui.WRAP).apply { bottomMargin = Ui.dp(ctx, 6) })
    }

    private fun libraryRow(f: File): View {
        val kb = f.length() / 1024
        val size = if (kb >= 1024) String.format(java.util.Locale.US, "%.1f MB", kb / 1024f) else "$kb KB"
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = Ui.glass(ctx)
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12))
            isClickable = true
            setOnClickListener { Session.loadSampleFileAsync(f) }
            setOnLongClickListener {
                host.confirm("Delete sample", "Delete \"${f.name}\" from this device?", "DELETE") {
                    if (!Session.deleteSample(f)) Session.say("Could not delete ${f.name}")
                }
                true
            }
        }
        row.addView(Ui.text(ctx, f.name.removeSuffix(".wav"), 13f, Ui.TEXT), Ui.lp(0, Ui.WRAP, 1f))
        row.addView(Ui.text(ctx, size, 11f, Ui.DIM))
        return row
    }

    override fun sync() {
        for (c in controls) c.sync()
    }

    override fun onShown() {
        sync()
        bindDevices()
    }

    override fun onTick(state: FloatArray) {
        if (state.size < EngineState.HEADER) return
        inMeter.setLevel(state[EngineState.IN_PEAK])
        val rec = Session.recording
        if (shownRec != rec) {
            shownRec = rec
            recButton.text = if (rec) "STOP" else "RECORD"
            Ui.styleButton(recButton, filled = false, danger = rec)
        }
        recText.text = when {
            rec -> "REC " + Ui.formatTime(state[EngineState.REC_SECONDS])
            Session.hasMicPermission() -> "INPUT IDLE"
            else -> "MIC PERMISSION NEEDED"
        }
        val a = Session.audioStatus()
        if (a != shownAudio) {
            shownAudio = a
            audioText.text = a
        }
    }
}
