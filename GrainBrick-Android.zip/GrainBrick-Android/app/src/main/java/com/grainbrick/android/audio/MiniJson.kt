package com.grainbrick.android.audio

/**
 * Tiny dependency-free JSON reader / writer.
 *
 * Why not org.json? It is part of the Android framework but only a stub on a plain JVM, which
 * would make the project/preset code impossible to unit test. Objects are returned as
 * LinkedHashMap<String, Any?>, arrays as ArrayList<Any?>, numbers as Double.
 */
object MiniJson {
    class JsonException(message: String) : Exception(message)

    private const val MAX_DEPTH = 48

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value(0)
        p.skipWs()
        if (!p.atEnd()) throw JsonException("Unexpected data at offset ${p.pos}")
        return v
    }

    fun stringify(value: Any?, pretty: Boolean = true): String {
        val sb = StringBuilder()
        write(sb, value, pretty, 0)
        if (pretty) sb.append('\n')
        return sb.toString()
    }

    // ------------------------------------------------------------------------------------
    private class Parser(private val s: String) {
        var pos = 0

        fun atEnd() = pos >= s.length

        fun skipWs() {
            while (pos < s.length) {
                val c = s[pos]
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '﻿') pos++ else break
            }
        }

        fun value(depth: Int): Any? {
            if (depth > MAX_DEPTH) throw JsonException("Nesting too deep")
            if (atEnd()) throw JsonException("Unexpected end of input")
            return when (val c = s[pos]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> str()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> if (c == '-' || c in '0'..'9') num() else throw JsonException("Unexpected '$c' at offset $pos")
            }
        }

        private fun literal(word: String, v: Any?): Any? {
            if (!s.startsWith(word, pos)) throw JsonException("Bad literal at offset $pos")
            pos += word.length
            return v
        }

        private fun num(): Double {
            val start = pos
            while (pos < s.length) {
                val c = s[pos]
                if (c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E' || c in '0'..'9') pos++ else break
            }
            val d = s.substring(start, pos).toDoubleOrNull() ?: throw JsonException("Bad number at offset $start")
            if (d.isNaN() || d.isInfinite()) throw JsonException("Number out of range at offset $start")
            return d
        }

        private fun str(): String {
            pos++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw JsonException("Unterminated string")
                val c = s[pos++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (atEnd()) throw JsonException("Unterminated escape")
                        when (val e = s[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > s.length) throw JsonException("Bad \\u escape")
                                val cp = s.substring(pos, pos + 4).toIntOrNull(16) ?: throw JsonException("Bad \\u escape")
                                sb.append(cp.toChar())
                                pos += 4
                            }
                            else -> throw JsonException("Bad escape '\\$e'")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun arr(depth: Int): ArrayList<Any?> {
            pos++ // [
            val out = ArrayList<Any?>()
            skipWs()
            if (!atEnd() && s[pos] == ']') { pos++; return out }
            while (true) {
                skipWs()
                out.add(value(depth + 1))
                skipWs()
                if (atEnd()) throw JsonException("Unterminated array")
                val c = s[pos++]
                if (c == ',') continue
                if (c == ']') return out
                throw JsonException("Expected ',' or ']' at offset ${pos - 1}")
            }
        }

        private fun obj(depth: Int): LinkedHashMap<String, Any?> {
            pos++ // {
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (!atEnd() && s[pos] == '}') { pos++; return out }
            while (true) {
                skipWs()
                if (atEnd() || s[pos] != '"') throw JsonException("Expected string key at offset $pos")
                val k = str()
                skipWs()
                if (atEnd() || s[pos] != ':') throw JsonException("Expected ':' at offset $pos")
                pos++
                skipWs()
                out[k] = value(depth + 1)
                skipWs()
                if (atEnd()) throw JsonException("Unterminated object")
                val c = s[pos++]
                if (c == ',') continue
                if (c == '}') return out
                throw JsonException("Expected ',' or '}' at offset ${pos - 1}")
            }
        }
    }

    // ------------------------------------------------------------------------------------
    private fun write(sb: StringBuilder, v: Any?, pretty: Boolean, indent: Int) {
        when (v) {
            null -> sb.append("null")
            is String -> quote(sb, v)
            is Boolean -> sb.append(if (v) "true" else "false")
            is Float -> sb.append(if (v.isNaN() || v.isInfinite()) "0" else v.toString())
            is Double -> sb.append(if (v.isNaN() || v.isInfinite()) "0" else v.toString())
            is Int, is Long -> sb.append(v.toString())
            is Map<*, *> -> {
                if (v.isEmpty()) { sb.append("{}"); return }
                sb.append('{')
                var first = true
                for ((k, value) in v) {
                    if (!first) sb.append(',')
                    first = false
                    if (pretty) { sb.append('\n'); pad(sb, indent + 1) }
                    quote(sb, k.toString())
                    sb.append(if (pretty) ": " else ":")
                    write(sb, value, pretty, indent + 1)
                }
                if (pretty) { sb.append('\n'); pad(sb, indent) }
                sb.append('}')
            }
            is List<*> -> {
                if (v.isEmpty()) { sb.append("[]"); return }
                sb.append('[')
                var first = true
                for (value in v) {
                    if (!first) sb.append(',')
                    first = false
                    if (pretty) { sb.append('\n'); pad(sb, indent + 1) }
                    write(sb, value, pretty, indent + 1)
                }
                if (pretty) { sb.append('\n'); pad(sb, indent) }
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun pad(sb: StringBuilder, n: Int) {
        for (i in 0 until n) sb.append("  ")
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append(String.format("\\u%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }
}
