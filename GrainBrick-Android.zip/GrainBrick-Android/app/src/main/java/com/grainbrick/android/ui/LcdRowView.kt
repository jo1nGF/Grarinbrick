package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import com.grainbrick.android.ParamDef
import com.grainbrick.android.Session
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Only one row at a time carries the amber cursor. */
object LcdSelection {
    private var current: LcdRowView? = null
    fun select(v: LcdRowView) {
        if (current === v) return
        current?.setSelectedRow(false)
        current = v
        v.setSelectedRow(true)
    }
    fun clear() {
        current?.setSelectedRow(false)
        current = null
    }
}

/**
 * One parameter as a line of an instrument display:
 *
 *     > PITCH                      +7.0 st
 *       |||||||||||||.....:......
 *
 * Knob parameters: drag sideways on the row (two fingers = fine). Toggles: tap. Choices: tap the
 * right half for the next value, the left half for the previous one. Tap also selects the row and
 * shows its help text, double-tap resets to the default, long-press shows the help too.
 */
class LcdRowView(context: Context, val def: ParamDef, private val onHelp: (ParamDef) -> Unit) : View(context), ParamControl {
    private val d = resources.displayMetrics.density
    private val slop = 8f * d

    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Ui.MONO_BOLD; textSize = 12f * d; letterSpacing = 0.06f }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Ui.MONO_BOLD; textSize = 12f * d; textAlign = Paint.Align.RIGHT }
    private val seg = Paint().apply { style = Paint.Style.FILL }
    private val led = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val hair = Paint().apply { color = 0xFF161C25.toInt(); strokeWidth = 1f }
    private val tri = Path()

    private var value = def.def
    private var selected = false
    private var downX = 0f
    private var downY = 0f
    private var downNorm = 0f
    private var dragging = false
    private var lastTapAt = 0L
    private var longPressed = false
    private val longPress = Runnable {
        longPressed = true
        select()
        onHelp(def)
    }

    private val title: String = if (def.id.endsWith(".enabled")) "STATE" else def.label.uppercase()

    init {
        isClickable = true
        contentDescription = def.label
    }

    override fun sync() {
        val v = Session.getParam(def)
        if (v != value) {
            value = v
            invalidate()
        }
    }

    fun setSelectedRow(on: Boolean) {
        if (selected != on) {
            selected = on
            invalidate()
        }
    }

    private fun select() {
        LcdSelection.select(this)
    }

    private fun commit(v: Float) {
        value = v.coerceIn(def.min, def.max)
        Session.setParam(def, value)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (if (def.isToggle || def.isChoice) 40 else 46) * d
        setMeasuredDimension(w, resolveSize(h.toInt(), heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 12f * d
        val on = selected
        label.color = if (on) Ui.ACCENT else Ui.TEXT
        valuePaint.color = if (on) Ui.ACCENT else Ui.TEXT

        if (on) canvas.drawRect(0f, 0f, w, h, seg.apply { color = 0x1AFF9F43 })
        canvas.drawLine(pad, h - 0.5f, w - pad, h - 0.5f, hair)

        val textY = (if (def.isToggle || def.isChoice) h / 2f + label.textSize * 0.36f else h * 0.40f + label.textSize * 0.36f)
        if (on) canvas.drawText(">", 3f * d, textY, label)
        canvas.drawText(title, pad, textY, label)

        when {
            def.isToggle -> {
                val onState = value > 0.5f
                val txt = if (onState) "ON" else "OFF"
                valuePaint.color = if (onState) Ui.ACCENT else Ui.DIM
                canvas.drawText(txt, w - pad - 16f * d, textY, valuePaint)
                led.color = if (onState) Ui.ACCENT else Ui.STROKE
                canvas.drawCircle(w - pad - 5f * d, h / 2f, 4f * d, led)
                if (onState) {
                    led.color = 0x44FF9F43
                    canvas.drawCircle(w - pad - 5f * d, h / 2f, 7f * d, led)
                }
            }
            def.isChoice -> {
                val txt = def.format(value)
                val ah = 5f * d
                arrow.color = if (on) Ui.ACCENT else Ui.DIM
                // right arrow
                val rx = w - pad
                tri.reset(); tri.moveTo(rx - ah, h / 2f - ah); tri.lineTo(rx, h / 2f); tri.lineTo(rx - ah, h / 2f + ah); tri.close()
                canvas.drawPath(tri, arrow)
                canvas.drawText(txt, rx - ah - 8f * d, textY, valuePaint)
                // left arrow, in front of the text
                val tw = valuePaint.measureText(txt)
                val lx = rx - ah - 8f * d - tw - 8f * d
                tri.reset(); tri.moveTo(lx, h / 2f - ah); tri.lineTo(lx - ah, h / 2f); tri.lineTo(lx, h / 2f + ah); tri.close()
                canvas.drawPath(tri, arrow)
            }
            else -> {
                canvas.drawText(def.format(value), w - pad, textY, valuePaint)
                drawBar(canvas, pad, w - pad, h - 11f * d, 5f * d, on)
            }
        }
    }

    /** 28 little blocks; bipolar parameters fill from the middle. */
    private fun drawBar(canvas: Canvas, x0: Float, x1: Float, top: Float, height: Float, on: Boolean) {
        val n = 28
        val gap = 2f * d
        val cell = (x1 - x0 - gap * (n - 1)) / n
        val norm = def.toNorm(value)
        val bipolar = def.min < 0f && def.max > 0f
        val zero = if (bipolar) def.toNorm(0f) else 0f
        val lo = min(norm, zero)
        val hi = max(norm, zero)
        for (i in 0 until n) {
            val c0 = i.toFloat() / n
            val c1 = (i + 1f) / n
            val filled = if (bipolar) (c1 > lo + 0.0001f && c0 < hi - 0.0001f) else (c0 + 0.5f / n < norm)
            seg.color = if (filled) (if (on) Ui.ACCENT else Ui.TEAL) else Ui.STROKE
            val x = x0 + i * (cell + gap)
            canvas.drawRect(x, top, x + cell, top + height, seg)
        }
        if (bipolar) {
            seg.color = Ui.DIM
            val zx = x0 + zero * (x1 - x0)
            canvas.drawRect(zx - 0.5f * d, top - 2f * d, zx + 0.5f * d, top + height + 2f * d, seg)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                downNorm = def.toNorm(value)
                dragging = false
                longPressed = false
                postDelayed(longPress, 500L)
            }
            MotionEvent.ACTION_MOVE -> {
                if (def.isToggle || def.isChoice) {
                    if (abs(e.x - downX) > slop || abs(e.y - downY) > slop) removeCallbacks(longPress)
                    return true
                }
                val dx = e.x - downX
                val dy = e.y - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy)) {
                    dragging = true
                    removeCallbacks(longPress)
                    parent?.requestDisallowInterceptTouchEvent(true)
                    select()
                    onHelp(def)
                    downX = e.x // start the drag from where it was recognised, no jump
                    downNorm = def.toNorm(value)
                } else if (!dragging && abs(dy) > slop) {
                    removeCallbacks(longPress)
                }
                if (dragging) {
                    val fine = if (e.pointerCount > 1) 0.2f else 1f
                    val n = downNorm + fine * (e.x - downX) / (max(width.toFloat(), 1f) * 0.85f)
                    commit(def.fromNorm(n.coerceIn(0f, 1f)))
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) {
                    Session.onParamGestureEnd(def)
                } else if (!longPressed) {
                    tap(e.x)
                }
                dragging = false
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) Session.onParamGestureEnd(def)
                dragging = false
            }
        }
        return true
    }

    private fun tap(x: Float) {
        val now = SystemClock.uptimeMillis()
        val double = now - lastTapAt < 320L
        lastTapAt = now
        select()
        onHelp(def)
        when {
            def.isToggle -> {
                commit(if (value > 0.5f) 0f else 1f)
                Session.onParamGestureEnd(def)
            }
            def.isChoice -> {
                val count = def.choices.size.coerceAtLeast(1)
                var idx = def.choiceIndex(value)
                idx = if (x > width / 2f) (idx + 1) % count else (idx - 1 + count) % count
                commit(def.min + idx)
                Session.onParamGestureEnd(def)
            }
            double -> {
                commit(def.def)
                Session.onParamGestureEnd(def)
            }
        }
    }
}
