package com.grainbrick.android.ui

import android.view.View
import android.widget.TextView
import com.grainbrick.android.EngineState
import com.grainbrick.android.Session

/** Levels, the smoothing times of the grain engine, and a status line for the audio streams. */
class SettingsPage(private val host: Host) : Page() {
    override val title = "SETUP"

    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private lateinit var status: TextView
    private var shownStatus = ""

    override fun build(): View {
        val col = Ui.pageColumn(ctx)
        val panels = listOf(
            ParamViews.lcdPanel(ctx, "MIX", controls, host::showHelp, "LEVELS"),
            ParamViews.lcdPanel(ctx, "SMOOTH", controls, host::showHelp, "SMOOTHING"),
        )
        col.addView(ParamViews.columns(ctx, panels), Ui.lp(Ui.MATCH, Ui.WRAP))

        col.addView(Ui.heading(ctx, "AUDIO"))
        status = Ui.text(ctx, "", 12f, Ui.TEXT, true)
        col.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 8) })
        col.addView(
            Ui.text(
                ctx,
                "DSP is the share of the real-time budget the engine uses (top bar). Above about 85% " +
                    "the sound can crackle: lower the number of grains (DENSITY), turn SHIMMER or REVERB " +
                    "down, or switch sections off.",
                11f, Ui.DIM,
            ).apply { setPadding(0, Ui.dp(ctx, 8), 0, 0); setLineSpacing(0f, 1.15f) },
        )

        col.addView(Ui.heading(ctx, "ABOUT"))
        col.addView(
            Ui.text(
                ctx,
                "GrainBrick for Android is an independent re-creation and is not affiliated with the " +
                    "original GrainBrick (TrimUI Brick / KNULLI).\n\n" +
                    "The shimmer pitch-shifts with SoundTouch (LGPL 2.1, (c) Olli Parviainen), built as " +
                    "its own library so it can be replaced. Audio output uses Oboe (Apache 2.0). " +
                    "Source and licences: see THIRD_PARTY_NOTICES.md in the repository.",
                11f, Ui.DIM,
            ).apply { setPadding(0, Ui.dp(ctx, 8), 0, 0); setLineSpacing(0f, 1.15f) },
        )
        sync()
        return Ui.scrollPage(ctx, col)
    }

    override fun sync() {
        for (c in controls) c.sync()
    }

    override fun onShown() = sync()

    override fun onTick(state: FloatArray) {
        val load = if (state.size > EngineState.DSP_LOAD) state[EngineState.DSP_LOAD] else 0f
        val t = Session.audioStatus() + "  |  DSP " + Math.round(load * 100f) + "%"
        if (t != shownStatus) {
            shownStatus = t
            status.text = t
        }
    }
}
