package com.grainbrick.android.ui

import android.app.AlertDialog
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.grainbrick.android.Session
import com.grainbrick.android.audio.ProjectData

/** Presets, saved projects, import / export. */
class ProjectsPage(private val host: Host) : Page() {
    override val title = "SAVE"

    private val ctx = host.context
    private lateinit var current: TextView
    private lateinit var presets: LinearLayout
    private lateinit var mine: LinearLayout

    override fun build(): View {
        val pad = Ui.dp(ctx, 16)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, Ui.dp(ctx, 8), pad, Ui.dp(ctx, 28))
        }
        val card = Ui.card(ctx)
        card.addView(Ui.text(ctx, "CURRENT PROJECT", 10f, Ui.DIM, true).apply { letterSpacing = 0.15f })
        current = Ui.text(ctx, "", 17f, Ui.TEXT, true).apply { setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 12)) }
        card.addView(current)
        val save = Ui.button(ctx, "SAVE", true) { save(Session.projectName) }
        val saveAs = Ui.button(ctx, "SAVE AS...") {
            host.prompt("Save project as", Session.projects.uniqueName(Session.projectName), "SAVE") { name -> save(name, askOverwrite = true) }
        }
        val import = Ui.button(ctx, "IMPORT .JSON") { host.pickProjectFile() }
        val export = Ui.button(ctx, "EXPORT") { host.exportProject(Session.projectName) }
        card.addView(ParamViews.rows(ctx, listOf(save, saveAs, import, export), 2, 8), Ui.lp(Ui.MATCH, Ui.WRAP))
        col.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))

        col.addView(Ui.heading(ctx, "PRESETS"))
        presets = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(presets, Ui.lp(Ui.MATCH, Ui.WRAP))

        col.addView(Ui.heading(ctx, "MY PROJECTS"))
        mine = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(mine, Ui.lp(Ui.MATCH, Ui.WRAP))

        col.addView(
            Ui.text(
                ctx,
                "Projects from the original GrainBrick (TrimUI Brick) can be imported: the parameter names are the same, " +
                    "but values may sound a little different. Copy the sample into the SAMPLE tab separately.\n\n" +
                    "GrainBrick for Android is an independent, clean-room re-creation and is not affiliated with the original.",
                11f, Ui.DIM,
            ).apply { setPadding(0, Ui.dp(ctx, 24), 0, 0); setLineSpacing(0f, 1.15f) },
        )
        onLibraryChanged()
        sync()
        return ScrollView(ctx).apply {
            setBackgroundColor(Ui.BG)
            addView(col, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun save(name: String, askOverwrite: Boolean = false) {
        val doSave = {
            try {
                Session.saveProject(name)
                Session.say("Saved ${Session.projectName}")
            } catch (e: Exception) {
                Session.say("Could not save: ${e.message}")
            }
        }
        if (askOverwrite && Session.projects.exists(name) && !name.equals(Session.projectName, true)) {
            host.confirm("Overwrite", "A project named \"$name\" already exists. Replace it?", "REPLACE") { doSave() }
        } else {
            doSave()
        }
    }

    override fun sync() {
        current.text = Session.projectName
    }

    override fun onShown() {
        sync()
        onLibraryChanged()
    }

    override fun onLibraryChanged() {
        sync()
        presets.removeAllViews()
        for (p in Session.presets()) presets.addView(row(p.name, "PRESET") { Session.applyProject(p) }, rowLp())
        mine.removeAllViews()
        val names = Session.projects.list()
        if (names.isEmpty()) {
            mine.addView(Ui.text(ctx, "Nothing saved yet - press SAVE AS.", 12f, Ui.DIM))
        }
        for (n in names) {
            val v = row(n, "") {
                try {
                    Session.applyProject(Session.projects.load(n))
                } catch (e: Exception) {
                    Session.say("Could not open $n: ${e.message}")
                }
            }
            v.setOnLongClickListener {
                projectMenu(n)
                true
            }
            mine.addView(v, rowLp())
        }
    }

    private fun projectMenu(name: String) {
        AlertDialog.Builder(ctx)
            .setTitle(name)
            .setItems(arrayOf("Export as .json", "Delete")) { _, which ->
                if (which == 0) host.exportProject(name)
                else host.confirm("Delete project", "Delete \"$name\"?", "DELETE") { Session.deleteProject(name) }
            }
            .show()
    }

    private fun rowLp() = Ui.lp(Ui.MATCH, Ui.WRAP).apply { bottomMargin = Ui.dp(ctx, 6) }

    private fun row(title: String, tag: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = Ui.glass(ctx)
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 13), Ui.dp(ctx, 12), Ui.dp(ctx, 13))
            isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(Ui.text(ctx, title, 13f, Ui.TEXT, true), Ui.lp(0, Ui.WRAP, 1f))
        if (tag.isNotEmpty()) r.addView(Ui.text(ctx, tag, 10f, Ui.DIM, true))
        return r
    }
}
