package com.grainbrick.android.audio

import com.grainbrick.android.SampleBuffer
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A small library of generated sound sources. Each one is rendered by code the first time it is
 * chosen (no audio is shipped), cached as a WAV in the app's sample folder, and loops without a
 * seam, so the grain engine can scan it forever. They are starting points: material with a lot of
 * slow movement is what clouds of grains like best.
 */
object SourceGen {
    const val RATE = 44100
    private const val SECONDS = 14
    private const val OVERLAP = 2          // seconds crossfaded to make the loop seamless

    class Source(
        val id: String,
        val label: String,
        val description: String,
        internal val render: (Int) -> Pair<FloatArray, FloatArray>,
    ) {
        val file: String get() = "src-$id.wav"
        fun generate(): SampleBuffer {
            val total = RATE * (SECONDS + OVERLAP)
            val (l, r) = render(total)
            return loop(l, r, id, label, file)
        }
    }

    val all: List<Source> = listOf(
        Source("pad", "WARM PAD", "Detuned saw chord (D minor 9) under a slowly moving low-pass. Wide, warm, safe.", ::pad),
        Source("choir", "CHOIR", "Four voices with vowel formants morphing between ah, oh and ee, with vibrato.", ::choir),
        Source("glass", "GLASS", "Inharmonic sine partials that twinkle in and out. Great into the shimmer.", ::glass),
        Source("wind", "AIR & WIND", "Filtered noise with two slowly drifting resonances. Textural, no pitch.", ::wind),
        Source("drone", "SUB DRONE", "Low fifths with slow beating. Feed it to a long reverb.", ::drone),
        Source("pluck", "PLUCK GARDEN", "Sparse plucked strings in a pentatonic scale (Karplus-Strong).", ::pluck),
    )

    fun byId(id: String): Source? = all.firstOrNull { it.id == id }
    fun byFile(file: String): Source? = all.firstOrNull { it.file == file }

    // ------------------------------------------------------------------------------------------
    // finishing: seamless loop, level
    // ------------------------------------------------------------------------------------------
    internal fun loop(l: FloatArray, r: FloatArray, id: String, label: String, file: String): SampleBuffer {
        val ov = RATE * OVERLAP
        val n = l.size - ov
        val ol = FloatArray(n)
        val or = FloatArray(n)
        for (i in 0 until n) {
            var a = l[i]
            var b = r[i]
            if (i < ov) {
                val t = i.toFloat() / ov
                val fin = sin(t * PI.toFloat() * 0.5f)      // equal-power crossfade of the tail into the head
                val fout = cos(t * PI.toFloat() * 0.5f)
                a = l[i] * fin + l[n + i] * fout
                b = r[i] * fin + r[n + i] * fout
            }
            ol[i] = a
            or[i] = b
        }
        // remove DC, then normalise to -2 dBFS
        var ml = 0.0
        var mr = 0.0
        for (i in 0 until n) { ml += ol[i]; mr += or[i] }
        ml /= n; mr /= n
        var peak = 1e-6f
        for (i in 0 until n) {
            ol[i] -= ml.toFloat(); or[i] -= mr.toFloat()
            peak = max(peak, max(abs(ol[i]), abs(or[i])))
        }
        val g = 0.8f / peak
        for (i in 0 until n) { ol[i] *= g; or[i] *= g }
        return SampleBuffer(label, ol, or, RATE, "samples/$file", mono = false)
    }

    private fun hz(note: Int) = 440.0 * 2.0.pow((note - 69) / 12.0)

    /** Equal-power pan gains for pan in -1..1. */
    private fun panL(p: Double) = cos((p + 1.0) * PI * 0.25) * 1.4142135623730951
    private fun panR(p: Double) = sin((p + 1.0) * PI * 0.25) * 1.4142135623730951

    // ------------------------------------------------------------------------------------------
    // WARM PAD: 6 notes x 5 detuned saws per channel, two-pole low-pass sweeping slowly
    // ------------------------------------------------------------------------------------------
    private fun pad(total: Int): Pair<FloatArray, FloatArray> {
        val notes = intArrayOf(38, 50, 53, 57, 60, 64, 67) // D2 D3 F3 A3 C4 E4 G4
        val cents = doubleArrayOf(-11.0, -5.0, 0.0, 5.0, 11.0)
        val out = arrayOf(FloatArray(total), FloatArray(total))
        val rnd = Random(11)
        for (ch in 0..1) {
            val phase = DoubleArray(notes.size * cents.size) { rnd.nextDouble() }
            val inc = DoubleArray(phase.size) { k ->
                val ni = k / cents.size
                val ci = k % cents.size
                val c = if (ch == 0) cents[ci] else -cents[ci]
                hz(notes[ni]) * 2.0.pow(c / 1200.0) / RATE
            }
            val amp = DoubleArray(phase.size) { k -> 0.045 / sqrt(1.0 + (k / cents.size) * 0.5) }
            var y1 = 0.0
            var y2 = 0.0
            val cyc = 3 + ch   // integer LFO cycles over the render
            for (i in 0 until total) {
                var s = 0.0
                for (k in phase.indices) {
                    val p = phase[k]
                    s += (2.0 * p - 1.0) * amp[k]
                    var np = p + inc[k]
                    if (np >= 1.0) np -= 1.0
                    phase[k] = np
                }
                val lfo = 0.5 + 0.5 * sin(2.0 * PI * cyc * i / total + ch * 1.3)
                val fc = 450.0 + 1500.0 * lfo * lfo
                val a = 1.0 - exp(-2.0 * PI * fc / RATE)
                y1 += a * (s - y1)
                y2 += a * (y1 - y2)
                out[ch][i] = y2.toFloat()
            }
        }
        return out[0] to out[1]
    }

    // ------------------------------------------------------------------------------------------
    // CHOIR: additive voices shaped by vowel formants
    // ------------------------------------------------------------------------------------------
    private val vowels = arrayOf(
        doubleArrayOf(800.0, 1150.0, 2900.0),  // ah
        doubleArrayOf(450.0, 800.0, 2830.0),   // oh
        doubleArrayOf(300.0, 2200.0, 3010.0),  // ee-ish
    )

    private fun formantGain(f: Double, a: DoubleArray, b: DoubleArray, mix: Double): Double {
        var g = 0.0
        val lf = ln(f)
        for (j in 0..2) {
            val fj = a[j] * (1.0 - mix) + b[j] * mix
            val d = (lf - ln(fj)) / 0.2
            g += (if (j == 0) 1.0 else if (j == 1) 0.6 else 0.3) * exp(-0.5 * d * d)
        }
        return g + 0.02
    }

    private fun choir(total: Int): Pair<FloatArray, FloatArray> {
        val f0s = doubleArrayOf(hz(48), hz(55), hz(60), hz(64), hz(67)) // C3 G3 C4 E4 G4
        val l = FloatArray(total)
        val r = FloatArray(total)
        val rnd = Random(5)
        val block = 64
        for ((vi, f0) in f0s.withIndex()) {
            val nh = min(26, (5200.0 / f0).toInt())
            val cr = DoubleArray(nh) { 1.0 }
            val ci = DoubleArray(nh)
            for (k in 0 until nh) { val p = rnd.nextDouble() * 2.0 * PI; cr[k] = cos(p); ci[k] = sin(p) }
            val gain = DoubleArray(nh)
            val gainNext = DoubleArray(nh)
            val pan = (vi - 2) * 0.35
            val gl = panL(pan)
            val gr = panR(pan)
            val vibRate = 4.6 + vi * 0.35
            val vibPh = rnd.nextDouble() * 2 * PI
            val morphCycles = 2 + vi % 3
            var pos = 0
            fun computeGains(t: Double, dst: DoubleArray) {
                val u = ((t * morphCycles + vi * 0.21) % 1.0) * 3.0
                val idx = u.toInt().coerceIn(0, 2)
                val frac = u - idx
                val sm = frac * frac * (3 - 2 * frac)
                val a = vowels[idx]
                val b = vowels[(idx + 1) % 3]
                for (k in 0 until nh) {
                    val f = f0 * (k + 1)
                    dst[k] = formantGain(f, a, b, sm) / (k + 1.0).pow(0.8)
                }
            }
            computeGains(0.0, gain)
            val cw = DoubleArray(nh)
            val sw = DoubleArray(nh)
            while (pos < total) {
                val end = min(total, pos + block)
                computeGains(end.toDouble() / total, gainNext)
                val vib = 1.0 + 0.007 * sin(2.0 * PI * vibRate * pos / RATE + vibPh) + 0.0025 * sin(2.0 * PI * 0.31 * pos / RATE + vi)
                for (k in 0 until nh) {
                    val w = 2.0 * PI * f0 * vib * (k + 1) / RATE
                    cw[k] = cos(w); sw[k] = sin(w)
                }
                val len = end - pos
                for (i in 0 until len) {
                    var s = 0.0
                    val tt = i.toDouble() / len
                    for (k in 0 until nh) {
                        val g = gain[k] + (gainNext[k] - gain[k]) * tt
                        s += cr[k] * g
                        val nc = cr[k] * cw[k] - ci[k] * sw[k]
                        ci[k] = ci[k] * cw[k] + cr[k] * sw[k]
                        cr[k] = nc
                    }
                    val env = 0.6 + 0.4 * sin(2.0 * PI * (2 + vi) * (pos + i).toDouble() / total + vi * 0.9)
                    val v = s * 0.05 * env
                    l[pos + i] += (v * gl).toFloat()
                    r[pos + i] += (v * gr).toFloat()
                }
                for (k in 0 until nh) {
                    // keep the phasors on the unit circle
                    val m = sqrt(cr[k] * cr[k] + ci[k] * ci[k])
                    cr[k] /= m; ci[k] /= m
                    gain[k] = gainNext[k]
                }
                pos = end
            }
        }
        // a little breath
        var bl = 0.0
        var br = 0.0
        for (i in 0 until total) {
            bl += 0.08 * ((rnd.nextDouble() * 2 - 1) - bl)
            br += 0.08 * ((rnd.nextDouble() * 2 - 1) - br)
            l[i] += (bl * 0.006).toFloat()
            r[i] += (br * 0.006).toFloat()
        }
        return l to r
    }

    // ------------------------------------------------------------------------------------------
    // GLASS: inharmonic partials with independent slow twinkling
    // ------------------------------------------------------------------------------------------
    private fun glass(total: Int): Pair<FloatArray, FloatArray> {
        val roots = doubleArrayOf(hz(72), hz(76), hz(79), hz(84), hz(88), hz(91)) // C5 E5 G5 C6 E6 G6
        val ratios = doubleArrayOf(1.0, 2.76, 5.40, 8.93)
        val l = FloatArray(total)
        val r = FloatArray(total)
        val rnd = Random(77)
        for ((ri, root) in roots.withIndex()) {
            for ((pi, ratio) in ratios.withIndex()) {
                val f = root * ratio
                if (f > 9000.0) continue
                val w = 2.0 * PI * f / RATE
                val cycles = 1 + rnd.nextInt(6)
                val ph = rnd.nextDouble() * 2 * PI
                val ph0 = rnd.nextDouble() * 2 * PI
                val pan = rnd.nextDouble() * 1.6 - 0.8
                val gl = panL(pan)
                val gr = panR(pan)
                val a = 0.05 / (1.0 + pi * 0.9) / sqrt(1.0 + ri * 0.2)
                var c = cos(ph0)
                var s = sin(ph0)
                val cw = cos(w)
                val sw = sin(w)
                for (i in 0 until total) {
                    val tw = 0.5 + 0.5 * sin(2.0 * PI * cycles * i / total + ph)
                    val env = tw * tw * tw           // mostly quiet, then a bloom
                    val v = s * env * a
                    l[i] += (v * gl).toFloat()
                    r[i] += (v * gr).toFloat()
                    val nc = c * cw - s * sw
                    s = s * cw + c * sw
                    c = nc
                    if ((i and 4095) == 0) { val m = sqrt(c * c + s * s); c /= m; s /= m }
                }
            }
        }
        return l to r
    }

    // ------------------------------------------------------------------------------------------
    // AIR & WIND: noise through two drifting resonant band-passes (TPT state-variable filters)
    // ------------------------------------------------------------------------------------------
    private class Svf {
        var ic1 = 0.0
        var ic2 = 0.0
        fun bandpass(x: Double, fc: Double, q: Double): Double {
            val g = kotlin.math.tan(PI * min(fc, RATE * 0.4) / RATE)
            val k = 1.0 / q
            val a1 = 1.0 / (1.0 + g * (g + k))
            val a2 = g * a1
            val a3 = g * a2
            val v3 = x - ic2
            val v1 = a1 * ic1 + a2 * v3
            val v2 = ic2 + a2 * ic1 + a3 * v3
            ic1 = 2.0 * v1 - ic1
            ic2 = 2.0 * v2 - ic2
            return v1
        }
    }

    private fun wind(total: Int): Pair<FloatArray, FloatArray> {
        val out = arrayOf(FloatArray(total), FloatArray(total))
        for (ch in 0..1) {
            val rnd = Random(300L + ch)
            val f1 = Svf(); val f2 = Svf(); val f3 = Svf()
            var rumble = 0.0
            for (i in 0 until total) {
                val n = rnd.nextDouble() * 2 - 1
                val t = i.toDouble() / total
                val c1 = 650.0 * 2.0.pow(1.1 * sin(2 * PI * (2 + ch) * t + ch))
                val c2 = 2400.0 * 2.0.pow(0.8 * sin(2 * PI * (3 + ch) * t + 1.7 + ch))
                val amp1 = 0.5 + 0.5 * sin(2 * PI * 4 * t + 0.3 * ch)
                val a = f1.bandpass(n, c1, 9.0) * (0.35 + 0.65 * amp1)
                val b = f2.bandpass(n, c2, 14.0) * 0.45
                val c = f3.bandpass(n, 180.0 + 80.0 * sin(2 * PI * 2 * t), 3.0) * 0.8
                rumble += 0.002 * (n - rumble)
                out[ch][i] = ((a + b + c) * 0.5 + rumble * 2.0).toFloat()
            }
        }
        return out[0] to out[1]
    }

    // ------------------------------------------------------------------------------------------
    // SUB DRONE: fifths with slowly beating detuned pairs
    // ------------------------------------------------------------------------------------------
    private fun drone(total: Int): Pair<FloatArray, FloatArray> {
        val l = FloatArray(total)
        val r = FloatArray(total)
        val bases = doubleArrayOf(hz(33), hz(40), hz(45), hz(52)) // A1 E2 A2 E3
        for ((bi, f) in bases.withIndex()) {
            for (side in 0..1) {
                val det = if (side == 0) -0.22 else 0.22
                val w = 2.0 * PI * (f + det * (bi + 1)) / RATE
                var ph = bi * 1.9 + side * 0.7
                val a = 0.16 / (1.0 + bi * 0.6)
                val cyc = 1 + bi
                for (i in 0 until total) {
                    val sw = 0.7 + 0.3 * sin(2 * PI * cyc * i.toDouble() / total + side)
                    // sine + 2nd + 3rd harmonic, a little saturated
                    val s = sin(ph) + 0.28 * sin(2 * ph + 0.4) + 0.12 * sin(3 * ph + 1.1)
                    val v = (s * a * sw).toFloat()
                    if (side == 0) l[i] += v else r[i] += v
                    ph += w
                }
            }
        }
        return l to r
    }

    // ------------------------------------------------------------------------------------------
    // PLUCK GARDEN: Karplus-Strong notes at random moments (wrap-around handled by the crossfade)
    // ------------------------------------------------------------------------------------------
    private fun pluck(total: Int): Pair<FloatArray, FloatArray> {
        val l = FloatArray(total)
        val r = FloatArray(total)
        val rnd = Random(909)
        val scale = intArrayOf(0, 2, 4, 7, 9) // major pentatonic
        val notes = 24
        for (n in 0 until notes) {
            val start = (n.toDouble() / notes * total + rnd.nextDouble() * 0.6 * total / notes).toInt()
            val note = 55 + scale[rnd.nextInt(scale.size)] + 12 * rnd.nextInt(3)
            val f = hz(note)
            val p = max(2, (RATE / f).toInt())
            val line = DoubleArray(p) { rnd.nextDouble() * 2 - 1 }
            // soften the burst
            var prev = 0.0
            for (i in 0 until p) { line[i] = 0.5 * (line[i] + prev); prev = line[i] }
            val pan = rnd.nextDouble() * 1.4 - 0.7
            val gl = panL(pan)
            val gr = panR(pan)
            val amp = 0.20 * (0.6 + 0.4 * rnd.nextDouble())
            val dur = min(total - start, RATE * 7)
            var idx = 0
            var last = 0.0
            val damp = 0.5 + 0.49 * (1.0 - min(1.0, (note - 55) / 40.0))    // higher notes are brighter
            for (i in 0 until dur) {
                val cur = line[idx]
                val nxt = line[(idx + 1) % p]
                val v = (damp * cur + (1.0 - damp) * nxt) * 0.9985
                line[idx] = v
                idx = (idx + 1) % p
                last = cur
                val e = amp * last
                l[start + i] += (e * gl).toFloat()
                r[start + i] += (e * gr).toFloat()
            }
        }
        return l to r
    }
}
