package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import com.grainbrick.android.ParamDef
import com.grainbrick.android.Session

/**
 * Rotary control drawn like a hardware knob: label on top, a ticked ring with the value in amber,
 * the readout underneath. Drag vertically to change the value (one full range per ~220 dp, two
 * fingers = fine), double-tap resets to the default, long-press shows the help text.
 */
class KnobView(context: Context, val def: ParamDef, private val onHelp: (ParamDef) -> Unit) : View(context), ParamControl {
    private val ring = RectF()
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Ui.STROKE }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT; color = Ui.ACCENT }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Ui.SURFACE2 }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Ui.DIM }
    private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Ui.TEXT }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; textAlign = Paint.Align.CENTER; typeface = Ui.MONO_BOLD
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.TEXT; textAlign = Paint.Align.CENTER; typeface = Ui.MONO_BOLD; letterSpacing = 0.06f
    }
    private val density = resources.displayMetrics.density
    private var value = def.def
    private var dragStartNorm = 0f
    private var dragStartY = 0f
    private var dragging = false
    private var knobBottom = 0f
    private var active = false

    private val gestures = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                commit(def.def)
                Session.onParamGestureEnd(def)
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                onHelp(def)
            }
        },
    )

    init {
        minimumHeight = (100 * density).toInt()
        contentDescription = def.label
    }

    override fun sync() {
        val v = Session.getParam(def)
        if (v != value) {
            value = v
            invalidate()
        }
    }

    private fun commit(v: Float) {
        value = v.coerceIn(def.min, def.max)
        Session.setParam(def, value)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, resolveSize((100 * density).toInt(), heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        labelPaint.textSize = 11f * density
        valuePaint.textSize = 10f * density
        labelPaint.color = if (active) Ui.ACCENT else Ui.TEXT
        canvas.drawText(def.label.uppercase(), w / 2f, 12f * density, labelPaint)

        val top = 20f * density
        val d = minOf(w * 0.78f, h - top - 18f * density)
        val cx = w / 2f
        val stroke = 2.2f * density
        tick.strokeWidth = stroke
        arc.strokeWidth = stroke
        ring.set(cx - d / 2f, top, cx + d / 2f, top + d)
        knobBottom = top + d
        val norm = def.toNorm(value)
        // dotted ring: 270 degrees of tick marks
        val inset = stroke * 0.5f
        ring.inset(inset, inset)
        canvas.drawArc(ring, 135f, 270f, false, tick)
        if (def.min < 0f && def.max > 0f) {
            val zero = def.toNorm(0f)
            val a0 = 135f + 270f * minOf(zero, norm)
            val sweep = 270f * kotlin.math.abs(norm - zero)
            if (sweep > 0.5f) canvas.drawArc(ring, a0, sweep, false, arc)
        } else if (norm > 0.002f) {
            canvas.drawArc(ring, 135f, 270f * norm, false, arc)
        }
        // the cap
        val r = d * 0.30f
        val cy = top + d / 2f
        canvas.drawCircle(cx, cy, r, body)
        rim.strokeWidth = 1.2f * density
        rim.color = if (active) Ui.ACCENT else Ui.DIM
        canvas.drawCircle(cx, cy, r, rim)
        val ang = Math.toRadians((135f + 270f * norm).toDouble())
        needle.strokeWidth = 2f * density
        canvas.drawLine(
            cx + (r * 0.25f * Math.cos(ang)).toFloat(), cy + (r * 0.25f * Math.sin(ang)).toFloat(),
            cx + (r * 0.92f * Math.cos(ang)).toFloat(), cy + (r * 0.92f * Math.sin(ang)).toFloat(), needle,
        )
        valuePaint.color = if (active) Ui.ACCENT else Ui.DIM
        canvas.drawText(def.format(value), w / 2f, h - 3f * density, valuePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && e.y > knobBottom + 10 * density) return false // let the page scroll
        gestures.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartY = e.y
                dragStartNorm = def.toNorm(value)
                dragging = false
                active = true
                invalidate()
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = dragStartY - e.y
                if (dragging || kotlin.math.abs(dy) > 6 * density) {
                    if (!dragging) onHelp(def)
                    dragging = true
                    val fine = if (e.pointerCount > 1) 0.25f else 1f
                    val n = dragStartNorm + fine * dy / (220f * density)
                    commit(def.fromNorm(n.coerceIn(0f, 1f)))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) Session.onParamGestureEnd(def)
                dragging = false
                active = false
                invalidate()
            }
        }
        return true
    }
}
