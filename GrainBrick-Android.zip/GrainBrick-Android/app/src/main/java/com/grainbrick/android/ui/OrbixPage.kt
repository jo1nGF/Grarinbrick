package com.grainbrick.android.ui

import android.view.View
import com.grainbrick.android.Params
import com.grainbrick.android.Session

/** ORBIX: bouncing balls in a rotating arena play notes of the chosen scale. */
class OrbixPage(private val host: Host) : Page() {
    override val title = "ORBIX"

    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private lateinit var arena: OrbixView
    private val enabledDef = Params.byId("orbix.enabled")

    override fun build(): View {
        val col = Ui.pageColumn(ctx)
        arena = OrbixView(ctx)
        val panel = ParamViews.lcdPanel(ctx, "ORBIX", controls, host::showHelp)
        col.addView(ParamViews.columns(ctx, listOf(arena, panel)), Ui.lp(Ui.MATCH, Ui.WRAP))
        return Ui.scrollPage(ctx, col)
    }

    override fun sync() {
        for (c in controls) c.sync()
    }

    override fun onShown() = sync()

    override fun onTick(state: FloatArray) {
        arena.setEnabledState(enabledDef != null && Session.getParam(enabledDef) > 0.5f)
        arena.setState(state)
    }
}
