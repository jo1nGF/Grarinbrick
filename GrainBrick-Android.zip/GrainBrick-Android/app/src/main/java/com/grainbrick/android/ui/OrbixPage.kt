package com.grainbrick.android.ui

import android.view.View
import android.widget.LinearLayout
import com.grainbrick.android.EngineState
import com.grainbrick.android.Params
import com.grainbrick.android.Session

/**
 * ORBIX: bouncing balls in a rotating arena play notes of the chosen scale. Below the arena sit the
 * voice recipes (one tap dials in an e-piano, strings, a marimba, an FM bell, a mini-synth lead...)
 * and the list that tunes the voice that is currently selected: FM, MINI SYNTH or MODAL.
 */
open class OrbixPage(
    private val host: Host,
    override val title: String = "ORBIX",
    private val mainGroup: String = "ORBIX",
    private val enabledId: String = "orbix.enabled",
    private val voiceId: String? = "orbix.instrument",
    private val stateBase: Int = EngineState.ORBIX_BASE,
    private val recipeDir: String = "voices",
    private val extraGroups: List<Pair<Int, String>> = listOf(6 to "FM SYNTH", 7 to "MINI SYNTH", 8 to "MODAL"),
    private val recipeTitle: String = "VOICE RECIPES",
    /** Groups shown below the recipes in every state (the voice-specific ones in [extraGroups] come after). */
    private val alwaysGroups: List<String> = emptyList(),
) : Page() {
    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private lateinit var arena: OrbixView
    private val enabledDef = Params.byId(enabledId)
    private val voiceDef = voiceId?.let { Params.byId(it) }

    /** orbix.instrument value -> panel of that voice's own controls. */
    private val voicePanels = LinkedHashMap<Int, LinearLayout>()
    private var shownVoice = -1

    override fun build(): View {
        val col = Ui.pageColumn(ctx)
        arena = OrbixView(ctx, stateBase)
        val panel = ParamViews.lcdPanel(ctx, mainGroup, controls, host::showHelp)
        col.addView(ParamViews.columns(ctx, listOf(arena, panel)), Ui.lp(Ui.MATCH, Ui.WRAP))

        val recipes = Session.voiceRecipes(recipeDir)
        if (recipes.isNotEmpty()) {
            col.addView(Ui.heading(ctx, recipeTitle))
            col.addView(Ui.text(ctx, "One tap sets the voice and its controls. Tweak them in the list below.", 11f, Ui.DIM))
            val buttons = recipes.map { r ->
                Ui.button(ctx, r.name.uppercase()) {
                    Session.applyRecipe(r)
                    sync()
                }
            }
            col.addView(ParamViews.rows(ctx, buttons, 3, 8), Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 8) })
        }

        val holder = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        for (group in alwaysGroups) {
            if (Params.inGroup(group).isEmpty()) continue
            val p = ParamViews.knobPanel(ctx, group, controls, host::showHelp)
            holder.addView(p, Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 12) })
        }
        for ((voice, group) in extraGroups) {
            if (Params.inGroup(group).isEmpty()) continue
            val p = ParamViews.knobPanel(ctx, group, controls, host::showHelp)
            if (voice >= 0) p.visibility = View.GONE
            voicePanels[voice] = p
            holder.addView(p, Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 12) })
        }
        col.addView(holder, Ui.lp(Ui.MATCH, Ui.WRAP))
        showVoicePanel()
        return Ui.scrollPage(ctx, col)
    }

    private fun showVoicePanel() {
        val v = voiceDef?.let { Math.round(Session.getParam(it)) } ?: -1
        if (v == shownVoice) return
        shownVoice = v
        for ((voice, p) in voicePanels) p.visibility = if (voice < 0 || voice == v) View.VISIBLE else View.GONE
    }

    override fun sync() {
        for (c in controls) c.sync()
        showVoicePanel()
    }

    override fun onShown() = sync()

    override fun onTick(state: FloatArray) {
        arena.setEnabledState(enabledDef != null && Session.getParam(enabledDef) > 0.5f)
        arena.setState(state)
        showVoicePanel()
    }
}
