package com.grainbrick.android

import kotlin.math.abs

/** Decoded audio held in memory (always two channels; [mono] marks identical channels). */
class SampleBuffer(
    var name: String,
    val left: FloatArray,
    val right: FloatArray,
    val sampleRate: Int,
    var relPath: String? = null,
    val mono: Boolean = false,
) {
    val frames: Int get() = left.size
    val seconds: Float get() = if (sampleRate > 0) frames.toFloat() / sampleRate else 0f

    /** Min/max pairs for [columns] display columns: [min0, max0, min1, max1, ...]. */
    fun peaks(columns: Int): FloatArray {
        val out = FloatArray(columns * 2)
        if (frames == 0 || columns <= 0) return out
        val per = frames.toDouble() / columns
        for (c in 0 until columns) {
            val s = (c * per).toInt()
            val e = ((c + 1) * per).toInt().coerceIn(s + 1, frames)
            var mn = 0f
            var mx = 0f
            for (i in s until e) {
                val v = 0.5f * (left[i] + right[i])
                if (v < mn) mn = v
                if (v > mx) mx = v
            }
            out[2 * c] = mn
            out[2 * c + 1] = mx
        }
        return out
    }

    /** Returns a cropped copy with short fades at the edges to avoid clicks. */
    fun crop(startFrac: Float, endFrac: Float, newName: String): SampleBuffer {
        val s = (startFrac.coerceIn(0f, 1f) * frames).toInt().coerceIn(0, frames - 1)
        val e = (endFrac.coerceIn(0f, 1f) * frames).toInt().coerceIn(s + 1, frames)
        val n = e - s
        val l = left.copyOfRange(s, e)
        val r = right.copyOfRange(s, e)
        val fade = minOf(n / 2, (sampleRate * 0.005f).toInt())
        for (i in 0 until fade) {
            val g = i.toFloat() / fade
            l[i] *= g; r[i] *= g
            l[n - 1 - i] *= g; r[n - 1 - i] *= g
        }
        return SampleBuffer(newName, l, r, sampleRate, null, mono)
    }

    fun peakLevel(): Float {
        var p = 0f
        for (i in 0 until frames) p = maxOf(p, abs(left[i]), abs(right[i]))
        return p
    }
}
