package com.grainbrick.android

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputFilter
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.grainbrick.android.ui.FxPage
import com.grainbrick.android.ui.GrainPage
import com.grainbrick.android.ui.Host
import com.grainbrick.android.ui.LcdSelection
import com.grainbrick.android.ui.MeterView
import com.grainbrick.android.ui.OrbixPage
import com.grainbrick.android.ui.Page
import com.grainbrick.android.ui.ProjectsPage
import com.grainbrick.android.ui.SamplePage
import com.grainbrick.android.ui.SettingsPage
import com.grainbrick.android.ui.TapePage
import com.grainbrick.android.ui.Ui
import java.io.IOException
import java.io.InputStream

class MainActivity : Activity(), Host {
    companion object {
        private const val REQ_PICK_SAMPLE = 1
        private const val REQ_PICK_PROJECT = 2
        private const val REQ_EXPORT = 3
        private const val REQ_MIC = 10
        private const val REQ_NOTIFICATIONS = 11
        private const val DEFAULT_HELP = "TAP A ROW TO SELECT  |  DRAG SIDEWAYS TO CHANGE  |  DOUBLE-TAP RESETS  |  HOLD FOR HELP"
        private const val FIRST_PAGE = 1 // GRAIN
        private const val PREFS = "grainbrick_ui"
    }

    override val context: Context get() = this

    private val handler = Handler(Looper.getMainLooper())
    private var pages: List<Page> = emptyList()
    private var pageViews: List<View> = emptyList()
    private var tabLabels: List<TextView> = emptyList()
    private var tabLines: List<View> = emptyList()
    private var current = FIRST_PAGE

    private lateinit var content: FrameLayout
    private lateinit var helpBar: TextView
    private lateinit var projectLabel: TextView
    private lateinit var playButton: TextView
    private lateinit var meter: MeterView
    private lateinit var dspLabel: TextView
    private var shownDsp = -1

    private var state = FloatArray(0)
    private var seenParams = -1
    private var seenSample = -1
    private var seenLibrary = -1
    private var shownPlaying: Boolean? = null
    private var shownProject = ""
    private var micCallback: (() -> Unit)? = null
    private var pendingExport: String? = null
    private var ticking = false

    private val ticker = object : Runnable {
        override fun run() {
            if (!ticking) return
            tick()
            handler.postDelayed(this, 33L)
        }
    }

    // ------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val native = NativeEngine.nStateSize()
        if (native != EngineState.SIZE) {
            Log.w("GrainBrick", "engine state has $native floats, the UI expects ${EngineState.SIZE}")
        }
        state = FloatArray(maxOf(native, EngineState.SIZE))
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        Session.messageListener = { msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        Session.micRequest = { cb -> requestMicrophone(cb) }
        for (m in Session.drainMessages()) Toast.makeText(this, m, Toast.LENGTH_LONG).show()
        Session.activityVisible = true
        ticking = true
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        Session.saveAutosave()
    }

    override fun onStop() {
        super.onStop()
        ticking = false
        handler.removeCallbacks(ticker)
        Session.activityVisible = false
        Session.messageListener = null
        Session.micRequest = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        buildUi() // layouts depend on the width (knob columns)
    }

    // ------------------------------------------------------------------------------------
    // UI construction
    // ------------------------------------------------------------------------------------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }

        val c = this
        val hair = { View(c).apply { setBackgroundColor(Ui.STROKE) } }

        // ---- status strip: brand, project, DSP, level, PLAY ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.SURFACE)
            setPadding(Ui.dp(c, 14), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8))
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(Ui.text(this, "GRAINBRICK", 14f, Ui.ACCENT, true).apply { letterSpacing = 0.22f })
        projectLabel = Ui.text(this, "", 11f, Ui.DIM, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, Ui.dp(c, 3), 0, 0)
            isClickable = true
            setOnClickListener { selectByTitle("SAVE") }
        }
        titleCol.addView(projectLabel)
        header.addView(titleCol, Ui.lp(0, Ui.WRAP, 1f))
        val gauges = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        dspLabel = Ui.text(this, "DSP --%", 10f, Ui.DIM, true).apply { letterSpacing = 0.1f; gravity = Gravity.END }
        gauges.addView(dspLabel, Ui.lp(Ui.WRAP, Ui.WRAP))
        meter = MeterView(this)
        gauges.addView(meter, Ui.lp(Ui.dp(c, 76), Ui.dp(c, 7)).apply { topMargin = Ui.dp(c, 5) })
        header.addView(gauges, Ui.lp(Ui.WRAP, Ui.WRAP).apply { leftMargin = Ui.dp(c, 8); rightMargin = Ui.dp(c, 12) })
        playButton = Ui.button(this, "PLAY", true) { onPlayClicked() }
        header.addView(playButton, Ui.lp(Ui.dp(c, 84), Ui.WRAP))
        root.addView(header, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(hair(), Ui.lp(Ui.MATCH, Ui.dp(c, 1)))

        pages = listOf(SamplePage(this), GrainPage(this), FxPage(this), TapePage(this), OrbixPage(this), SettingsPage(this), ProjectsPage(this))
        pageViews = pages.map { it.build() }

        // ---- tab strip: SAMPLE GRAIN FX TAPE ORBIX SETUP SAVE ----
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val labels = ArrayList<TextView>()
        val lines = ArrayList<View>()
        for ((i, p) in pages.withIndex()) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                isClickable = true
                setOnClickListener { select(i) }
            }
            val t = Ui.text(this, p.title, 12f, Ui.DIM, true).apply {
                letterSpacing = 0.12f
                gravity = Gravity.CENTER
                setPadding(Ui.dp(c, 14), Ui.dp(c, 11), Ui.dp(c, 14), Ui.dp(c, 9))
            }
            val line = View(this).apply { setBackgroundColor(Ui.ACCENT) }
            cell.addView(t, Ui.lp(Ui.WRAP, Ui.WRAP))
            cell.addView(line, Ui.lp(Ui.MATCH, Ui.dp(c, 2)))
            labels.add(t)
            lines.add(line)
            tabRow.addView(cell, Ui.lp(Ui.WRAP, Ui.WRAP))
        }
        tabLabels = labels
        tabLines = lines
        val strip = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Ui.BG)
            addView(tabRow)
        }
        root.addView(strip, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(hair(), Ui.lp(Ui.MATCH, Ui.dp(c, 1)))

        // ---- page ----
        content = FrameLayout(this)
        root.addView(content, Ui.lp(Ui.MATCH, 0, 1f))

        // ---- hint bar ----
        root.addView(hair(), Ui.lp(Ui.MATCH, Ui.dp(c, 1)))
        helpBar = Ui.text(this, DEFAULT_HELP, 11f, Ui.DIM, true).apply {
            setPadding(Ui.dp(c, 14), Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 8))
            setBackgroundColor(Ui.SURFACE)
            minLines = 2
            maxLines = 3
            setLineSpacing(0f, 1.1f)
        }
        root.addView(helpBar, Ui.lp(Ui.MATCH, Ui.WRAP))

        setContentView(root)
        select(current.coerceIn(0, pages.size - 1))
        seenParams = -1
        seenSample = -1
        seenLibrary = -1
        shownPlaying = null
        shownProject = ""
        shownDsp = -1
    }

    private fun selectByTitle(title: String) {
        val i = pages.indexOfFirst { it.title == title }
        if (i >= 0) select(i)
    }

    private fun select(i: Int) {
        current = i
        content.removeAllViews()
        content.addView(pageViews[i], FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        LcdSelection.clear()
        for ((k, t) in tabLabels.withIndex()) {
            val on = k == i
            t.setTextColor(if (on) Ui.ACCENT else Ui.DIM)
            tabLines[k].visibility = if (on) View.VISIBLE else View.INVISIBLE
        }
        helpBar.text = DEFAULT_HELP
        pages[i].onShown()
    }

    private fun onPlayClicked() {
        val start = !Session.isPlaying
        if (start && Build.VERSION.SDK_INT >= 33) askNotificationPermissionOnce()
        Session.setPlaying(start)
    }

    private fun askNotificationPermissionOnce() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
    }

    // ------------------------------------------------------------------------------------
    // 30 fps UI refresh
    // ------------------------------------------------------------------------------------
    private fun tick() {
        NativeEngine.nGetState(state)
        meter.setLevel(state[EngineState.OUT_PEAK])
        updateDsp(state[EngineState.DSP_LOAD])

        val playing = Session.isPlaying
        if (shownPlaying != playing) {
            shownPlaying = playing
            playButton.text = if (playing) "STOP" else "PLAY"
            Ui.styleButton(playButton, filled = !playing, danger = playing)
        }
        if (shownProject != Session.projectName) {
            shownProject = Session.projectName
            projectLabel.text = shownProject
        }
        if (Session.paramRevision != seenParams) {
            seenParams = Session.paramRevision
            for (p in pages) p.sync()
        }
        if (Session.sampleRevision != seenSample) {
            seenSample = Session.sampleRevision
            for (p in pages) p.onSampleChanged()
        }
        if (Session.libraryRevision != seenLibrary) {
            seenLibrary = Session.libraryRevision
            for (p in pages) p.onLibraryChanged()
        }
        // The engine stops recording by itself when its buffer is full.
        if (Session.recording && state[EngineState.RECORDING] < 0.5f) Session.stopRecording()
        pages[current].onTick(state)
    }

    private fun updateDsp(load: Float) {
        val pct = Math.round(load.coerceIn(0f, 9.99f) * 100f)
        if (pct == shownDsp) return
        shownDsp = pct
        dspLabel.text = "DSP $pct%"
        dspLabel.setTextColor(
            when {
                pct > 85 -> Ui.DANGER
                pct >= 60 -> Ui.ACCENT
                else -> Ui.TEXT
            },
        )
    }

    // ------------------------------------------------------------------------------------
    // Host
    // ------------------------------------------------------------------------------------
    override fun showHelp(def: ParamDef) {
        val range = if (def.isToggle || def.isChoice) "" else "   [${def.format(def.min)} .. ${def.format(def.max)}]"
        helpBar.text = "${def.label.uppercase()}$range\n${def.help}"
    }

    override fun pickSampleFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "application/ogg"))
        }
        try {
            startActivityForResult(i, REQ_PICK_SAMPLE)
        } catch (e: Exception) {
            Toast.makeText(this, "No file picker available", Toast.LENGTH_LONG).show()
        }
    }

    override fun pickProjectFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(i, REQ_PICK_PROJECT)
        } catch (e: Exception) {
            Toast.makeText(this, "No file picker available", Toast.LENGTH_LONG).show()
        }
    }

    override fun exportProject(name: String) {
        pendingExport = name
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "$name.json")
        }
        try {
            startActivityForResult(i, REQ_EXPORT)
        } catch (e: Exception) {
            Toast.makeText(this, "No file picker available", Toast.LENGTH_LONG).show()
        }
    }

    override fun requestMicrophone(onGranted: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
            return
        }
        micCallback = onGranted
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
    }

    override fun confirm(title: String, message: String, positive: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(positive) { _, _ -> onYes() }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    override fun prompt(title: String, initial: String, positive: String, onText: (String) -> Unit) {
        val et = EditText(this).apply {
            setText(initial)
            setSelectAllOnFocus(true)
            setSingleLine()
            filters = arrayOf(InputFilter.LengthFilter(40))
        }
        val frame = FrameLayout(this).apply {
            val m = Ui.dp(this@MainActivity, 20)
            setPadding(m, Ui.dp(this@MainActivity, 8), m, 0)
            addView(et, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(frame)
            .setPositiveButton(positive) { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) onText(t)
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    // ------------------------------------------------------------------------------------
    // results
    // ------------------------------------------------------------------------------------
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val cb = micCallback
            micCallback = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) cb?.invoke()
            else Toast.makeText(this, "Microphone permission denied", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_PICK_SAMPLE -> Session.importSampleAsync(uri, displayName(uri, "SAMPLE"))
            REQ_PICK_PROJECT -> importProject(uri)
            REQ_EXPORT -> {
                val name = pendingExport ?: return
                pendingExport = null
                val text = Session.exportProjectText(name)
                if (text == null) {
                    Toast.makeText(this, "Could not export $name", Toast.LENGTH_LONG).show()
                    return
                }
                Thread {
                    val msg = try {
                        contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                            ?: throw IOException("Cannot open the destination")
                        "Exported $name"
                    } catch (e: Exception) {
                        "Export failed: ${e.message}"
                    }
                    runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
                }.start()
            }
        }
    }

    private fun importProject(uri: Uri) {
        val fallback = displayName(uri, "IMPORTED").removeSuffix(".json").removeSuffix(".JSON")
        Thread {
            try {
                val text = contentResolver.openInputStream(uri)?.use { readLimited(it, 1_000_000) }
                    ?: throw IOException("Cannot open the file")
                runOnUiThread {
                    val msg = try {
                        "Imported ${Session.importProjectText(text, fallback)}"
                    } catch (e: Exception) {
                        "Not a valid GrainBrick project: ${e.message}"
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun readLimited(input: InputStream, limit: Int): String {
        val buf = java.io.ByteArrayOutputStream()
        val chunk = ByteArray(8192)
        while (true) {
            val n = input.read(chunk)
            if (n < 0) break
            buf.write(chunk, 0, n)
            if (buf.size() > limit) throw IOException("File is too large for a project")
        }
        return buf.toString("UTF-8")
    }

    private fun displayName(uri: Uri, fallback: String): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return c.getString(i) ?: fallback
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: fallback
    }
}
