package com.grainbrick.android.ui

import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.grainbrick.android.EngineState
import com.grainbrick.android.ParamDef
import com.grainbrick.android.Params
import com.grainbrick.android.Session

/**
 * The playing surface: waveform with the grain window, XY pad, and the three parameter displays
 * (GRAIN, ROAM, MOTION) as LCD lists.
 */
class GrainPage(private val host: Host) : Page() {
    override val title = "GRAIN"

    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private val posDef: ParamDef = Params.byId("grain.position")!!
    private val sizeDef: ParamDef = Params.byId("grain.size")!!
    private var yDef: ParamDef = sizeDef
    private lateinit var wave: WaveformView
    private lateinit var pad: XyPadView
    private lateinit var grainsText: TextView
    private lateinit var sampleText: TextView
    private val yChips = ArrayList<Pair<TextView, ParamDef>>()
    private var shownGrains = -1
    private var shownSample = ""
    private val grains = FloatArray(EngineState.MAX_GRAINS)
    private var windowTick = 0

    override fun build(): View {
        val col = Ui.pageColumn(ctx)

        val info = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        grainsText = Ui.text(ctx, "ACTIVE GRAINS 0", 11f, Ui.ACCENT, true).apply { letterSpacing = 0.1f }
        sampleText = Ui.text(ctx, "", 11f, Ui.DIM, true).apply { gravity = Gravity.END; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        info.addView(grainsText, Ui.lp(Ui.WRAP, Ui.WRAP))
        info.addView(sampleText, Ui.lp(0, Ui.WRAP, 1f).apply { leftMargin = Ui.dp(ctx, 12) })
        col.addView(info, Ui.lp(Ui.MATCH, Ui.WRAP).apply { bottomMargin = Ui.dp(ctx, 8) })

        wave = WaveformView(ctx, WaveformView.MODE_POSITION)
        wave.onPosition = { f ->
            Session.setParam(posDef, f)
            syncAll()
        }
        col.addView(wave, Ui.lp(Ui.MATCH, Ui.dp(ctx, 112)))

        val chips = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        chips.addView(Ui.caption(ctx, "PAD Y").apply { setPadding(0, 0, Ui.dp(ctx, 10), 0) })
        for (id in listOf("grain.size", "grain.pitch", "grain.density", "grain.spray")) {
            val d = Params.byId(id) ?: continue
            val chip = Ui.text(ctx, d.label.uppercase(), 11f, Ui.DIM, true).apply {
                letterSpacing = 0.06f
                gravity = Gravity.CENTER
                setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10), Ui.dp(ctx, 8))
                isClickable = true
                setOnClickListener {
                    yDef = d
                    pad.yLabel = d.label.uppercase()
                    styleYChips()
                    syncPad()
                    host.showHelp(d)
                }
            }
            yChips.add(chip to d)
            chips.addView(chip, Ui.lp(Ui.WRAP, Ui.WRAP).apply { rightMargin = Ui.dp(ctx, 6) })
        }
        col.addView(chips, Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 10); bottomMargin = Ui.dp(ctx, 8) })

        pad = XyPadView(ctx)
        pad.xLabel = "POSITION"
        pad.yLabel = yDef.label.uppercase()
        pad.onChange = { x, y ->
            Session.setParam(posDef, x)
            Session.setParam(yDef, yDef.fromNorm(y))
            syncControlsOnly()
            updateWindow()
        }
        col.addView(pad, Ui.lp(Ui.MATCH, Ui.dp(ctx, if (Ui.isWide(ctx)) 240 else 200)))

        val panels = listOf("GRAIN", "ROAM", "MOTION").map { ParamViews.lcdPanel(ctx, it, controls, host::showHelp) }
        col.addView(ParamViews.columns(ctx, panels), Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 12) })

        styleYChips()
        syncAll()
        onSampleChanged()
        return Ui.scrollPage(ctx, col)
    }

    private fun styleYChips() {
        for ((chip, d) in yChips) {
            val on = d === yDef
            chip.setTextColor(if (on) Ui.ON_ACCENT else Ui.DIM)
            chip.background = Ui.round(if (on) Ui.ACCENT else Ui.SURFACE2, Ui.dp(ctx, 3).toFloat(), if (on) Ui.ACCENT else Ui.STROKE, Ui.dp(ctx, 1))
        }
    }

    private fun updateWindow() {
        val s = Session.sample
        wave.setGrainWindow(if (s == null || s.seconds <= 0f) 0f else Session.getParam(sizeDef) / s.seconds)
    }

    private fun syncControlsOnly() {
        for (c in controls) c.sync()
    }

    private fun syncPad() {
        pad.setValues(posDef.toNorm(Session.getParam(posDef)), yDef.toNorm(Session.getParam(yDef)))
    }

    private fun syncAll() {
        syncControlsOnly()
        syncPad()
        updateWindow()
    }

    override fun sync() = syncAll()

    override fun onShown() = syncAll()

    override fun onSampleChanged() {
        wave.setSample(Session.sample)
        shownSample = ""
        updateWindow()
    }

    override fun onTick(state: FloatArray) {
        val s = Session.sample
        if (s != null && state.size >= EngineState.GRAIN_BASE + EngineState.MAX_GRAINS) {
            wave.setPlayhead(state[EngineState.PLAYHEAD])
            System.arraycopy(state, EngineState.GRAIN_BASE, grains, 0, EngineState.MAX_GRAINS)
            wave.setGrains(grains)
        } else {
            wave.setPlayhead(-1f)
        }
        // the size knob can also move through MOTION / ROAM, so keep the bracket honest
        if (++windowTick % 6 == 0) updateWindow()
        val n = if (state.size > EngineState.GRAINS) state[EngineState.GRAINS].toInt() else 0
        if (n != shownGrains) {
            shownGrains = n
            grainsText.text = "ACTIVE GRAINS $n"
        }
        val text = if (s == null) "NO SAMPLE - OPEN THE SAMPLE TAB" else "${s.name.uppercase()}  ${Ui.formatTime(s.seconds)}"
        if (text != shownSample) {
            shownSample = text
            sampleText.text = text
        }
    }
}
