package com.grainbrick.android

/**
 * Layout of the float array the engine publishes for the UI (Engine::getState in engine.cpp).
 * Header, then the positions of the 64 grain slots, then the ORBIX block. The host test
 * checks the sizes on the C++ side; [MainActivity] checks them again at start-up.
 */
object EngineState {
    // header
    const val PLAYHEAD = 0      // 0..1, current grain start position
    const val GRAINS = 1        // number of active grains
    const val OUT_PEAK = 2      // linear
    const val COMP_GR = 3       // compressor gain reduction, dB
    const val REC_SECONDS = 4
    const val IN_PEAK = 5       // linear
    const val ORBIX_VOICES = 6
    const val RECORDING = 7     // 1 while the engine is recording
    const val DSP_LOAD = 8      // fraction of the real-time budget (1.0 = all of it)

    const val HEADER = 12
    const val MAX_GRAINS = 64
    const val GRAIN_BASE = HEADER                 // normalised sample positions, < 0 = free slot
    const val ORBIX_BASE = HEADER + MAX_GRAINS    // angle, sides, balls, 16 x {x, y, secondsSinceHit}
    const val ORBIX_SIZE = 3 + 16 * 3
    const val SIZE = ORBIX_BASE + ORBIX_SIZE
}
