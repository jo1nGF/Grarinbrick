package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import com.grainbrick.android.EngineState
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the ORBIX arena from the engine state. State layout (offset [base]):
 * angle, sides, ballCount, then 16 x { x, y, secondsSinceHit } in arena units (circumradius = 1).
 */
class OrbixView(context: Context) : View(context) {
    companion object {
        const val STATE_BASE = EngineState.ORBIX_BASE
        const val MAX_BALLS = 16
        private const val TWO_PI = 6.2831855f
    }

    private var angle = 0f
    private var sides = 4
    private var balls = 0
    private val bx = FloatArray(MAX_BALLS)
    private val by = FloatArray(MAX_BALLS)
    private val hit = FloatArray(MAX_BALLS) { 99f }
    private var enabled = false

    private val density = resources.displayMetrics.density
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Ui.ACCENT; strokeWidth = 2f * density; strokeJoin = Paint.Join.MITER
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x14FF9F43 }
    private val gridLine = Paint().apply { color = 0xFF141A22.toInt(); strokeWidth = 1f }
    private val marks = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.DIM; strokeWidth = 1.5f * density }
    private val ball = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.TEXT }
    private val flash = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Ui.TEAL; strokeWidth = 2f * density }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; textAlign = Paint.Align.CENTER; textSize = 12f * density; typeface = Ui.MONO_BOLD; letterSpacing = 0.1f
    }
    private val path = Path()

    init {
        background = Ui.glass(context)
    }

    fun setEnabledState(on: Boolean) {
        if (on != enabled) {
            enabled = on
            invalidate()
        }
    }

    fun setState(state: FloatArray) {
        if (state.size < STATE_BASE + EngineState.ORBIX_SIZE) return
        angle = state[STATE_BASE]
        sides = state[STATE_BASE + 1].toInt().coerceIn(3, 8)
        balls = state[STATE_BASE + 2].toInt().coerceIn(0, MAX_BALLS)
        for (i in 0 until MAX_BALLS) {
            bx[i] = state[STATE_BASE + 3 + i * 3]
            by[i] = state[STATE_BASE + 4 + i * 3]
            hit[i] = state[STATE_BASE + 5 + i * 3]
        }
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val cap = (360 * density).toInt()
        val side = min(w, cap)
        setMeasuredDimension(w, side)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val scale = min(w, h) * 0.44f
        for (i in 1 until 8) {
            canvas.drawLine(w * i / 8f, 0f, w * i / 8f, h, gridLine)
            canvas.drawLine(0f, h * i / 8f, w, h * i / 8f, gridLine)
        }
        Ui.cornerMarks(canvas, w, h, 10f * density, marks)
        path.reset()
        for (k in 0 until sides) {
            val a = angle + TWO_PI * k / sides + Math.PI.toFloat() / sides
            val x = cx + cos(a) * scale
            val y = cy - sin(a) * scale
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, fill)
        canvas.drawPath(path, edge)
        if (!enabled || balls == 0) {
            canvas.drawText(if (enabled) "PRESS PLAY" else "ORBIX OFF", cx, cy + hint.textSize / 3f, hint)
            return
        }
        val rb = 0.05f * scale
        for (i in 0 until balls) {
            val x = cx + bx[i] * scale
            val y = cy - by[i] * scale
            canvas.drawCircle(x, y, maxOf(rb, 4f * density), ball)
            if (hit[i] < 0.3f) {
                val t = hit[i] / 0.3f
                flash.alpha = (255 * (1f - t)).toInt().coerceIn(0, 255)
                canvas.drawCircle(x, y, maxOf(rb, 4f * density) * (1.5f + 3f * t), flash)
            }
        }
    }
}
