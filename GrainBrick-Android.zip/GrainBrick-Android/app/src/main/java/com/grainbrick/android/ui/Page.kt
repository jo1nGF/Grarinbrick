package com.grainbrick.android.ui

import android.content.Context
import android.view.View
import com.grainbrick.android.ParamDef

/** Services the activity offers to the pages. */
interface Host {
    val context: Context
    fun showHelp(def: ParamDef)
    fun pickSampleFile()
    fun pickProjectFile()
    fun exportProject(name: String)
    fun requestMicrophone(onGranted: () -> Unit)
    fun confirm(title: String, message: String, positive: String, onYes: () -> Unit)
    fun prompt(title: String, initial: String, positive: String, onText: (String) -> Unit)
}

/** One tab of the main screen. Pages are built once and re-attached when the tab is selected. */
abstract class Page {
    abstract val title: String
    abstract fun build(): View

    /** Parameters were changed from outside the controls (project / preset load). */
    open fun sync() {}

    /** The loaded sample changed. */
    open fun onSampleChanged() {}

    /** Saved projects or the sample library changed. */
    open fun onLibraryChanged() {}

    /** The tab became visible. */
    open fun onShown() {}

    /** About 30 times per second while the tab is visible; [state] is Engine::getState(). */
    open fun onTick(state: FloatArray) {}
}
