package com.grainbrick.android.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.grainbrick.android.SampleBuffer
import java.io.BufferedInputStream
import java.io.IOException
import java.nio.ByteOrder

/** Turns any user-chosen audio file into a [SampleBuffer]. WAV is parsed directly, the rest uses MediaCodec. */
object AudioDecoder {
    /** Longest sample kept in memory. Longer files are cut (the user is told). */
    const val MAX_SECONDS = 90

    class Result(val sample: SampleBuffer, val truncated: Boolean)

    @Throws(IOException::class)
    fun decode(context: Context, uri: Uri, displayName: String): Result {
        val name = displayName.substringBeforeLast('.').ifBlank { "SAMPLE" }
        var decoded: WavIO.Decoded? = null
        context.contentResolver.openInputStream(uri)?.use { raw ->
            val bin = BufferedInputStream(raw, 1 shl 16)
            bin.mark(16)
            val head = ByteArray(12)
            var got = 0
            while (got < head.size) {
                val r = bin.read(head, got, head.size - got)
                if (r < 0) break
                got += r
            }
            bin.reset()
            if (got == head.size && WavIO.looksLikeWav(head)) {
                try {
                    decoded = WavIO.read(bin, maxSeconds = MAX_SECONDS)
                } catch (e: WavIO.WavException) {
                    decoded = null // e.g. ADPCM inside a WAV container: let MediaCodec try
                }
            }
        } ?: throw IOException("Cannot open the selected file")

        val d = decoded ?: decodeWithCodec(context, uri)
        val limit = maxFramesFor(d.sampleRate)
        var l = d.left
        var r = d.right
        var truncated = d.truncated
        if (l.size > limit) {
            l = l.copyOf(limit)
            r = if (d.mono) l else r.copyOf(limit)
            truncated = true
        }
        return Result(SampleBuffer(name, l, r, d.sampleRate, null, d.mono), truncated)
    }

    private fun maxFramesFor(rate: Int): Int = (MAX_SECONDS.toLong() * rate).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

    private class Grow {
        var a = FloatArray(1 shl 16)
        var n = 0
        fun add(v: Float) {
            if (n == a.size) a = a.copyOf(a.size * 2)
            a[n++] = v
        }
    }

    @Throws(IOException::class)
    private fun decodeWithCodec(context: Context, uri: Uri): WavIO.Decoded {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            try {
                extractor.setDataSource(context, uri, null)
            } catch (e: Exception) {
                throw IOException("Unsupported or unreadable audio file")
            }
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("audio/")) {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) throw IOException("The file has no audio track")
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: throw IOException("Unknown audio format")

            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var rate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var encoding = AudioFormat.ENCODING_PCM_16BIT

            val c = try {
                MediaCodec.createDecoderByType(mime)
            } catch (e: Exception) {
                throw IOException("This device cannot decode $mime")
            }
            codec = c
            c.configure(format, null, null, 0)
            c.start()

            val gl = Grow()
            val gr = Grow()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var truncated = false
            val deadline = System.nanoTime() + 90_000_000_000L
            var idleLoops = 0

            while (!outputDone) {
                if (System.nanoTime() > deadline) throw IOException("Decoding timed out")
                if (!inputDone) {
                    val idx = c.dequeueInputBuffer(10_000)
                    if (idx >= 0) {
                        val buf = c.getInputBuffer(idx)
                        val size = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (size < 0) {
                            c.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(idx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val out = c.dequeueOutputBuffer(info, 10_000)
                when {
                    out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = c.outputFormat
                        if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) encoding = f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    out >= 0 -> {
                        idleLoops = 0
                        val buf = c.getOutputBuffer(out)
                        if (buf != null && info.size > 0 && channels > 0) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            buf.order(ByteOrder.nativeOrder())
                            val limit = maxFramesFor(rate)
                            if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                val fb = buf.asFloatBuffer()
                                val frames = fb.remaining() / channels
                                for (i in 0 until frames) {
                                    if (gl.n >= limit) { truncated = true; break }
                                    val l = fb.get()
                                    var r = l
                                    if (channels > 1) {
                                        r = fb.get()
                                        for (k in 2 until channels) fb.get()
                                    }
                                    gl.add(clean(l)); gr.add(clean(r))
                                }
                            } else {
                                val sb = buf.asShortBuffer()
                                val frames = sb.remaining() / channels
                                for (i in 0 until frames) {
                                    if (gl.n >= limit) { truncated = true; break }
                                    val l = sb.get() / 32768f
                                    var r = l
                                    if (channels > 1) {
                                        r = sb.get() / 32768f
                                        for (k in 2 until channels) sb.get()
                                    }
                                    gl.add(l); gr.add(r)
                                }
                            }
                        }
                        c.releaseOutputBuffer(out, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        if (truncated) outputDone = true
                    }
                    out == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (inputDone && ++idleLoops > 300) throw IOException("Decoder stalled")
                    }
                }
            }
            if (gl.n == 0) throw IOException("The file contains no decodable audio")
            val mono = channels == 1
            val l = gl.a.copyOf(gl.n)
            val r = if (mono) l else gr.a.copyOf(gr.n)
            return WavIO.Decoded(l, r, rate, mono, truncated)
        } finally {
            try { codec?.stop() } catch (_: Exception) { }
            try { codec?.release() } catch (_: Exception) { }
            try { extractor.release() } catch (_: Exception) { }
        }
    }

    private fun clean(v: Float): Float = if (v.isNaN() || v.isInfinite()) 0f else v
}
