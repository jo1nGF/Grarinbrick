package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.log10

/**
 * Segmented level meter (LED ladder), input is a linear peak (0..1+), shown over -60..0 dB.
 * Cream below -12 dB, amber up to -3 dB, red above.
 */
class MeterView(context: Context) : View(context) {
    private var level = 0f
    private val cell = Paint()
    private val segments = 20
    private val density = resources.displayMetrics.density

    fun setLevel(linear: Float) {
        val db = if (linear <= 1e-4f) -60f else (20f * log10(linear)).coerceIn(-60f, 3f)
        val n = ((db + 60f) / 60f).coerceIn(0f, 1.05f)
        if (kotlin.math.abs(n - level) > 0.004f) {
            level = n
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = 1.5f * density
        val cw = (w - gap * (segments - 1)) / segments
        val lit = (level.coerceAtMost(1f) * segments + 0.5f).toInt()
        for (i in 0 until segments) {
            val f = (i + 1f) / segments
            cell.color = when {
                i >= lit -> Ui.SURFACE2
                f > 0.95f -> Ui.DANGER
                f > 0.80f -> Ui.ACCENT
                else -> Ui.TEXT
            }
            val x = i * (cw + gap)
            canvas.drawRect(x, 0f, x + cw, h, cell)
        }
    }
}
