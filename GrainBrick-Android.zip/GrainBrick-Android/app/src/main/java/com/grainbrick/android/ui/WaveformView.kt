package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.grainbrick.android.SampleBuffer

/**
 * Oscilloscope-style waveform: cyan trace on dark glass, an amber playhead with a bracket that
 * shows how much of the sample one grain covers, and a tick for every live grain.
 * MODE_POSITION: touch/drag sets the start position. MODE_TRIM: drag the two handles.
 */
class WaveformView(context: Context, private val mode: Int) : View(context) {
    companion object {
        const val MODE_POSITION = 0
        const val MODE_TRIM = 1
    }

    var onPosition: ((Float) -> Unit)? = null
    var onTrimChanged: ((Float, Float) -> Unit)? = null

    private var sample: SampleBuffer? = null
    private var peaks = FloatArray(0)
    private var peakColumns = 0
    private var playhead = -1f
    private var grains = FloatArray(0)
    var trimStart = 0f
        private set
    var trimEnd = 1f
        private set
    private var activeHandle = 0 // 0 none, 1 start, 2 end

    private val density = resources.displayMetrics.density
    private val wave = Paint().apply { color = Ui.TEAL; strokeWidth = 1.2f * density; alpha = 215 }
    private val center = Paint().apply { color = Ui.STROKE; strokeWidth = 1f }
    private val ruler = Paint().apply { color = Ui.STROKE; strokeWidth = 1f }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT; strokeWidth = 1.6f * density }
    private val windowFill = Paint().apply { color = 0x26FF9F43 }
    private val windowEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT; strokeWidth = 2f * density; style = Paint.Style.STROKE }
    private val grain = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.TEXT; strokeWidth = 1.5f * density }
    private val shade = Paint().apply { color = 0xB007090C.toInt() }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT; strokeWidth = 2f * density }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; textAlign = Paint.Align.CENTER; textSize = 12f * density; typeface = Ui.MONO_BOLD; letterSpacing = 0.1f
    }
    private var windowFrac = 0f

    init {
        background = Ui.glass(context)
    }

    /** Fraction of the sample one grain spans (grain size / sample length); 0 hides the bracket. */
    fun setGrainWindow(frac: Float) {
        val f = if (frac.isNaN()) 0f else frac.coerceIn(0f, 1f)
        if (kotlin.math.abs(f - windowFrac) > 0.0005f) {
            windowFrac = f
            invalidate()
        }
    }

    fun setSample(s: SampleBuffer?) {
        sample = s
        peakColumns = 0
        trimStart = 0f
        trimEnd = 1f
        rebuildPeaks()
        invalidate()
    }

    fun setPlayhead(p: Float) {
        if (p != playhead) {
            playhead = p
            invalidate()
        }
    }

    fun setGrains(g: FloatArray) {
        grains = g
        invalidate()
    }

    fun resetTrim() {
        trimStart = 0f
        trimEnd = 1f
        invalidate()
    }

    private fun rebuildPeaks() {
        val s = sample
        val cols = (width / 2).coerceAtLeast(1)
        if (s == null || width <= 0) {
            peaks = FloatArray(0)
            peakColumns = 0
            return
        }
        if (cols == peakColumns) return
        peaks = s.peaks(cols)
        peakColumns = cols
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildPeaks()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val mid = h / 2f
        // time ruler: 8 divisions along the bottom edge
        for (i in 1 until 8) {
            val x = w * i / 8f
            canvas.drawLine(x, h - 5f * density, x, h, ruler)
        }
        canvas.drawLine(0f, mid, w, mid, center)
        if (sample == null || peakColumns == 0) {
            canvas.drawText("NO SAMPLE", w / 2f, mid + hint.textSize / 3f, hint)
            return
        }
        val amp = h * 0.44f
        val colW = w / peakColumns
        for (i in 0 until peakColumns) {
            val x = (i + 0.5f) * colW
            val mn = peaks[2 * i]
            val mx = peaks[2 * i + 1]
            canvas.drawLine(x, mid - mx * amp, x, mid - mn * amp + 1f, wave)
        }
        if (mode == MODE_POSITION && playhead >= 0f && windowFrac > 0f) {
            val x0 = playhead * w
            val x1 = (playhead + windowFrac).coerceAtMost(1f) * w
            canvas.drawRect(x0, 0f, maxOf(x1, x0 + 2f * density), h, windowFill)
            val k = 7f * density
            // [ and ] brackets
            canvas.drawLine(x0, 0f, x0, h, windowEdge)
            canvas.drawLine(x0, 1f, x0 + k, 1f, windowEdge)
            canvas.drawLine(x0, h - 1f, x0 + k, h - 1f, windowEdge)
            if (x1 - x0 > 3f * k) {
                canvas.drawLine(x1, 0f, x1, h, windowEdge)
                canvas.drawLine(x1, 1f, x1 - k, 1f, windowEdge)
                canvas.drawLine(x1, h - 1f, x1 - k, h - 1f, windowEdge)
            }
        } else if (playhead >= 0f) {
            canvas.drawLine(playhead * w, 0f, playhead * w, h, head)
        }
        for (g in grains) {
            if (g < 0f) continue
            val x = g * w
            canvas.drawLine(x, h - 11f * density, x, h - 2f * density, grain)
        }
        if (mode == MODE_TRIM) {
            canvas.drawRect(0f, 0f, trimStart * w, h, shade)
            canvas.drawRect(trimEnd * w, 0f, w, h, shade)
            canvas.drawLine(trimStart * w, 0f, trimStart * w, h, handle)
            canvas.drawLine(trimEnd * w, 0f, trimEnd * w, h, handle)
            val r = 6f * density
            canvas.drawRect(trimStart * w - r, mid - r, trimStart * w + r, mid + r, handle)
            canvas.drawRect(trimEnd * w - r, mid - r, trimEnd * w + r, mid + r, handle)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (sample == null || width <= 0) return false
        val f = (e.x / width).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (mode == MODE_TRIM) {
                    val ds = kotlin.math.abs(e.x - trimStart * width)
                    val de = kotlin.math.abs(e.x - trimEnd * width)
                    val reach = 36f * density
                    activeHandle = when {
                        ds <= de && ds < reach -> 1
                        de < ds && de < reach -> 2
                        else -> 0
                    }
                } else {
                    onPosition?.invoke(f)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == MODE_TRIM) {
                    val minGap = 0.005f
                    if (activeHandle == 1) trimStart = f.coerceAtMost(trimEnd - minGap).coerceAtLeast(0f)
                    if (activeHandle == 2) trimEnd = f.coerceAtLeast(trimStart + minGap).coerceAtMost(1f)
                    if (activeHandle != 0) {
                        onTrimChanged?.invoke(trimStart, trimEnd)
                        invalidate()
                    }
                } else {
                    onPosition?.invoke(f)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                activeHandle = 0
            }
        }
        return true
    }
}
