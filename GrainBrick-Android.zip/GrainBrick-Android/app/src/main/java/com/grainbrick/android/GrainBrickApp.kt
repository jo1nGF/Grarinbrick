package com.grainbrick.android

import android.app.Application

class GrainBrickApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Session.init(this)
    }
}
