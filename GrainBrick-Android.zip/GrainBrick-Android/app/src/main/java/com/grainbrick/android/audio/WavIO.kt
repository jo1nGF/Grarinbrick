package com.grainbrick.android.audio

import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import kotlin.math.roundToInt

/** Streaming WAV reader (8/16/24/32-bit PCM, 32/64-bit float, EXTENSIBLE) and 16-bit / float writer. */
object WavIO {
    class WavException(message: String) : Exception(message)

    class Decoded(
        val left: FloatArray,
        val right: FloatArray,
        val sampleRate: Int,
        val mono: Boolean,
        /** True if the file had more audio than maxFrames and was cut. */
        val truncated: Boolean,
    )

    private const val FMT_PCM = 1
    private const val FMT_FLOAT = 3
    private const val FMT_EXTENSIBLE = 0xFFFE

    fun looksLikeWav(head: ByteArray): Boolean =
        head.size >= 12 && head[0] == 'R'.code.toByte() && head[1] == 'I'.code.toByte() &&
            head[2] == 'F'.code.toByte() && head[3] == 'F'.code.toByte() &&
            head[8] == 'W'.code.toByte() && head[9] == 'A'.code.toByte() &&
            head[10] == 'V'.code.toByte() && head[11] == 'E'.code.toByte()

    fun read(bytes: ByteArray, maxFrames: Int = Int.MAX_VALUE, maxSeconds: Int = Int.MAX_VALUE): Decoded =
        read(ByteArrayInputStream(bytes), maxFrames, maxSeconds)

    /** Reads at most [maxFrames] frames and at most [maxSeconds] seconds (whichever is smaller). */
    fun read(input: InputStream, maxFrames: Int = Int.MAX_VALUE, maxSeconds: Int = Int.MAX_VALUE): Decoded {
        val inp = if (input is BufferedInputStream) input else BufferedInputStream(input, 1 shl 16)
        val head = ByteArray(12)
        if (!tryReadFully(inp, head) || !looksLikeWav(head)) throw WavException("Not a RIFF/WAVE file")

        var tag = 0
        var channels = 0
        var rate = 0
        var bits = 0
        var haveFmt = false
        val chunk = ByteArray(8)
        while (true) {
            if (!tryReadFully(inp, chunk)) throw WavException("No audio data found")
            val id = String(chunk, 0, 4, Charsets.ISO_8859_1)
            val size = u32(chunk, 4)
            val padded = size + (size and 1L)
            if (id == "fmt ") {
                if (size < 16) throw WavException("Bad fmt chunk")
                val n = minOf(size, 64L).toInt()
                val f = ByteArray(n)
                readFully(inp, f)
                skipFully(inp, padded - n)
                tag = u16(f, 0)
                channels = u16(f, 2)
                rate = u32(f, 4).toInt()
                bits = u16(f, 14)
                if (tag == FMT_EXTENSIBLE && n >= 26) tag = u16(f, 24)
                haveFmt = true
            } else if (id == "data") {
                if (!haveFmt) throw WavException("data chunk before fmt chunk")
                if (tag != FMT_PCM && tag != FMT_FLOAT) throw WavException("Unsupported WAV encoding ($tag)")
                if (channels < 1 || channels > 32) throw WavException("Unsupported channel count $channels")
                if (rate < 1000 || rate > 384000) throw WavException("Unsupported sample rate $rate")
                val ok = if (tag == FMT_FLOAT) bits == 32 || bits == 64 else bits == 8 || bits == 16 || bits == 24 || bits == 32
                if (!ok) throw WavException("Unsupported bit depth $bits")
                val cap = minOf(maxFrames.toLong(), maxSeconds.toLong() * rate).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                return decodeData(inp, size, tag == FMT_FLOAT, channels, rate, bits, cap)
            } else {
                skipFully(inp, padded)
            }
        }
    }

    private fun decodeData(
        inp: InputStream, size: Long, isFloat: Boolean, channels: Int, rate: Int, bits: Int, maxFrames: Int,
    ): Decoded {
        val bps = bits / 8
        val frameBytes = bps * channels
        // size 0 / 0xFFFFFFFF means "streamed, read to the end".
        val unknown = size == 0L || size >= 0xFFFFFFF0L
        val declaredFrames = if (unknown) Long.MAX_VALUE else size / frameBytes
        val wanted = minOf(declaredFrames, maxFrames.toLong())
        var cap = if (unknown) (1 shl 16) else minOf(wanted, 1L shl 26).toInt().coerceAtLeast(16)
        var l = FloatArray(cap)
        var r = if (channels > 1) FloatArray(cap) else l
        var n = 0

        val block = ByteArray(frameBytes * 4096)
        var truncated = false
        while (n < wanted) {
            val framesNow = minOf(4096L, wanted - n).toInt()
            val got = readUpTo(inp, block, framesNow * frameBytes)
            val frames = got / frameBytes
            if (frames == 0) break
            if (n + frames > cap) {
                cap = maxOf(cap * 2, n + frames)
                l = l.copyOf(cap)
                r = if (channels > 1) r.copyOf(cap) else l
            }
            var o = 0
            for (i in 0 until frames) {
                l[n + i] = sampleAt(block, o, bits, isFloat)
                if (channels > 1) r[n + i] = sampleAt(block, o + bps, bits, isFloat)
                o += frameBytes
            }
            n += frames
            if (got < framesNow * frameBytes) break // EOF
        }
        if (n >= maxFrames && wanted == maxFrames.toLong() && (unknown || declaredFrames > maxFrames)) truncated = true
        if (n == 0) throw WavException("The file contains no audio")
        val mono = channels == 1
        val outL = if (l.size == n) l else l.copyOf(n)
        val outR = if (mono) outL else if (r.size == n) r else r.copyOf(n)
        return Decoded(outL, outR, rate, mono, truncated)
    }

    private fun sampleAt(b: ByteArray, o: Int, bits: Int, isFloat: Boolean): Float {
        return when (bits) {
            8 -> ((b[o].toInt() and 0xFF) - 128) / 128f
            16 -> ((b[o].toInt() and 0xFF) or (b[o + 1].toInt() shl 8)).toShort() / 32768f
            24 -> {
                val v = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or (b[o + 2].toInt() shl 16)
                v / 8388608f
            }
            32 -> {
                val v = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
                    ((b[o + 2].toInt() and 0xFF) shl 16) or (b[o + 3].toInt() shl 24)
                if (isFloat) Float.fromBits(v).let { if (it.isNaN() || it.isInfinite()) 0f else it } else v / 2147483648f
            }
            else -> { // 64-bit float
                var v = 0L
                for (k in 7 downTo 0) v = (v shl 8) or (b[o + k].toLong() and 0xFF)
                val d = Double.fromBits(v)
                if (d.isNaN() || d.isInfinite()) 0f else d.toFloat()
            }
        }
    }

    // ------------------------------------------------------------------------------------
    // writer
    // ------------------------------------------------------------------------------------
    fun encode(left: FloatArray, right: FloatArray, sampleRate: Int, mono: Boolean, float32: Boolean = false): ByteArray {
        val bos = ByteArrayOutputStream(left.size * (if (mono) 1 else 2) * (if (float32) 4 else 2) + 64)
        write(bos, left, right, sampleRate, mono, float32)
        return bos.toByteArray()
    }

    fun write(out: OutputStream, left: FloatArray, right: FloatArray, sampleRate: Int, mono: Boolean, float32: Boolean = false) {
        val ch = if (mono) 1 else 2
        val bps = if (float32) 4 else 2
        val frames = left.size
        val dataBytes = frames.toLong() * ch * bps
        if (dataBytes + 36 > 0xFFFFFFFFL) throw WavException("Audio too long for a WAV file")
        val h = ByteArray(44)
        fun put4(o: Int, s: String) { for (i in 0 until 4) h[o + i] = s[i].code.toByte() }
        fun put32(o: Int, v: Long) { for (i in 0 until 4) h[o + i] = ((v shr (8 * i)) and 0xFF).toByte() }
        fun put16(o: Int, v: Int) { h[o] = (v and 0xFF).toByte(); h[o + 1] = ((v shr 8) and 0xFF).toByte() }
        put4(0, "RIFF"); put32(4, 36 + dataBytes); put4(8, "WAVE")
        put4(12, "fmt "); put32(16, 16)
        put16(20, if (float32) FMT_FLOAT else FMT_PCM); put16(22, ch)
        put32(24, sampleRate.toLong()); put32(28, sampleRate.toLong() * ch * bps)
        put16(32, ch * bps); put16(34, bps * 8)
        put4(36, "data"); put32(40, dataBytes)
        out.write(h)

        val buf = ByteArray(4096 * ch * bps)
        var i = 0
        while (i < frames) {
            val n = minOf(4096, frames - i)
            var o = 0
            for (k in 0 until n) {
                for (c in 0 until ch) {
                    val x = if (c == 0) left[i + k] else right[i + k]
                    if (float32) {
                        val bitsV = x.toRawBits()
                        buf[o++] = bitsV.toByte(); buf[o++] = (bitsV shr 8).toByte()
                        buf[o++] = (bitsV shr 16).toByte(); buf[o++] = (bitsV shr 24).toByte()
                    } else {
                        val s = (x.coerceIn(-1f, 1f) * 32767f).roundToInt()
                        buf[o++] = s.toByte(); buf[o++] = (s shr 8).toByte()
                    }
                }
            }
            out.write(buf, 0, o)
            i += n
        }
        out.flush()
    }

    // ------------------------------------------------------------------------------------
    // small stream helpers
    // ------------------------------------------------------------------------------------
    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun u32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    private fun tryReadFully(inp: InputStream, b: ByteArray): Boolean = readUpTo(inp, b, b.size) == b.size

    private fun readFully(inp: InputStream, b: ByteArray) {
        if (!tryReadFully(inp, b)) throw EOFException("Unexpected end of WAV file")
    }

    private fun readUpTo(inp: InputStream, b: ByteArray, len: Int): Int {
        var total = 0
        while (total < len) {
            val r = inp.read(b, total, len - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    private fun skipFully(inp: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val s = inp.skip(left)
            if (s > 0) { left -= s; continue }
            if (inp.read() < 0) throw EOFException("Unexpected end of WAV file")
            left--
        }
    }
}
