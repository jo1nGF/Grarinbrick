package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * The look of the app: a dark "hardware instrument" display. Monospaced capitals, thin bezels,
 * square corners, an amber cursor on near-black glass and a cyan trace for audio. No XML layouts.
 */
object Ui {
    // glass and bezels
    val BG = 0xFF07090C.toInt()
    val SURFACE = 0xFF0D1117.toInt()        // LCD glass
    val SURFACE2 = 0xFF161C25.toInt()       // keys, inactive chips
    val STROKE = 0xFF27303C.toInt()         // bezel lines
    // ink
    val TEXT = 0xFFEDE6D3.toInt()           // warm paper white
    val DIM = 0xFF7F8A98.toInt()
    val ACCENT = 0xFFFF9F43.toInt()         // amber: cursor, active, playhead
    val ACCENT_DIM = 0xFF8A5521.toInt()
    val TEAL = 0xFF7ED7F0.toInt()           // cyan trace: waveform, grains, signal
    val DANGER = 0xFFFF5D5D.toInt()
    val OK = 0xFF6FD08C.toInt()
    /** Text on an amber background. */
    val ON_ACCENT = 0xFF1B1004.toInt()

    val MONO: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    val MONO_BOLD: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun dp(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun dp(c: Context, v: Int): Int = dp(c, v.toFloat())

    /** True on screens wide enough to put parameter panels side by side (tablets, landscape). */
    fun isWide(c: Context): Boolean {
        val dm = c.resources.displayMetrics
        return dm.widthPixels / dm.density >= 600f
    }

    fun round(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    /** Glass panel with a thin bezel; the corner radius is deliberately tiny. */
    fun glass(c: Context, fill: Int = SURFACE, stroke: Int = STROKE): GradientDrawable =
        round(fill, dp(c, 3).toFloat(), stroke, dp(c, 1))

    fun text(c: Context, s: CharSequence, sp: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            typeface = if (bold) MONO_BOLD else MONO
            includeFontPadding = false
        }

    /** Section caption: amber, spaced capitals, hairline underneath. */
    fun heading(c: Context, s: String): View {
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(c, s, 11f, ACCENT, true).apply {
            letterSpacing = 0.2f
            setPadding(0, dp(c, 18), 0, dp(c, 6))
        })
        col.addView(View(c).apply { setBackgroundColor(STROKE) }, lp(MATCH, dp(c, 1)))
        col.layoutParams = lp(MATCH, WRAP)
        return col
    }

    /** Rectangular key with mono caps. [filled] = the amber, primary key. */
    fun button(c: Context, label: String, filled: Boolean = false, onClick: (View) -> Unit): TextView =
        TextView(c).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = MONO_BOLD
            letterSpacing = 0.1f
            gravity = Gravity.CENTER
            includeFontPadding = false
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
            isClickable = true
            setOnClickListener(onClick)
            styleButton(this, filled)
        }

    fun styleButton(b: TextView, filled: Boolean, danger: Boolean = false) {
        val c = b.context
        val fill = if (danger) DANGER else if (filled) ACCENT else SURFACE2
        val stroke = if (danger) DANGER else if (filled) ACCENT else STROKE
        b.setTextColor(if (filled || danger) ON_ACCENT else TEXT)
        b.background = round(fill, dp(c, 3).toFloat(), stroke, dp(c, 1))
    }

    /** Standard page body: a vertical column with the page margins. */
    fun pageColumn(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 28))
        }

    /** Wraps a page column in a scroller on the instrument background. */
    fun scrollPage(c: Context, col: View): ScrollView =
        ScrollView(c).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(col, lp(MATCH, WRAP))
        }

    /** Small spaced-out caption (labels above a field). */
    fun caption(c: Context, s: String, color: Int = DIM): TextView =
        text(c, s, 10f, color, true).apply { letterSpacing = 0.15f }

    fun card(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(c)
            setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12))
        }

    fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun formatTime(seconds: Float): String {
        val s = if (seconds.isNaN() || seconds < 0f) 0f else seconds
        val m = (s / 60f).toInt()
        val r = s - m * 60f
        return if (m > 0) String.format(java.util.Locale.US, "%d:%04.1f", m, r) else String.format(java.util.Locale.US, "%.1f s", r)
    }

    /** Draws small corner brackets, the "display window" mark of the panels. */
    fun cornerMarks(canvas: Canvas, w: Float, h: Float, len: Float, paint: Paint) {
        canvas.drawLine(0f, 0f, len, 0f, paint); canvas.drawLine(0f, 0f, 0f, len, paint)
        canvas.drawLine(w, 0f, w - len, 0f, paint); canvas.drawLine(w, 0f, w, len, paint)
        canvas.drawLine(0f, h, len, h, paint); canvas.drawLine(0f, h, 0f, h - len, paint)
        canvas.drawLine(w, h, w - len, h, paint); canvas.drawLine(w, h, w, h - len, paint)
    }
}
