package com.grainbrick.android.ui

import android.view.View
import com.grainbrick.android.Params
import com.grainbrick.android.Session

/** The tape section: two animated reels and its parameters as a grid of knobs and switches. */
class TapePage(private val host: Host) : Page() {
    override val title = "TAPE"

    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private lateinit var reels: TapeView
    private val enabledDef = Params.byId("tape.enabled")
    private val wowDef = Params.byId("tape.wow")
    private val flutterDef = Params.byId("tape.flutter")

    override fun build(): View {
        val col = Ui.pageColumn(ctx)
        reels = TapeView(ctx)
        col.addView(reels, Ui.lp(Ui.MATCH, Ui.WRAP))

        val defs = Params.inGroup("TAPE")
        val ordered = defs.filter { it.isToggle && it.id.endsWith(".enabled") } +
            defs.filter { !it.isToggle } +
            defs.filter { it.isToggle && !it.id.endsWith(".enabled") }
        val cells = ordered.mapNotNull { d ->
            if (d.isToggle) ParamViews.toggle(ctx, d.id, controls, host::showHelp)
            else ParamViews.knob(ctx, d.id, controls, host::showHelp)
        }
        val columns = if (Ui.isWide(ctx)) 8 else 4
        col.addView(
            Ui.heading(ctx, "TAPE"),
            Ui.lp(Ui.MATCH, Ui.WRAP),
        )
        col.addView(ParamViews.rows(ctx, cells, columns, 6), Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 4) })
        sync()
        return Ui.scrollPage(ctx, col)
    }

    override fun sync() {
        for (c in controls) c.sync()
    }

    override fun onShown() = sync()

    override fun onTick(state: FloatArray) {
        reels.setState(
            Session.isPlaying,
            enabledDef == null || Session.getParam(enabledDef) > 0.5f,
            wowDef?.let { Session.getParam(it) } ?: 0f,
            flutterDef?.let { Session.getParam(it) } ?: 0f,
        )
    }
}
