package com.grainbrick.android.ui

import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.grainbrick.android.Params

/** EQ, compressor, delay, reverb, shimmer: one LCD panel at a time behind small tabs. */
class FxPage(private val host: Host) : Page() {
    override val title = "FX"

    private val ctx = host.context
    private val controls = ArrayList<ParamControl>()
    private val tabs = ArrayList<Pair<TextView, String>>()
    private lateinit var holder: LinearLayout
    private var group = "REVERB"
    private val groups = listOf("EQ", "COMP", "DELAY", "REVERB", "SHIMMER")

    override fun build(): View {
        val col = Ui.pageColumn(ctx)
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        for (g in groups.filter { Params.inGroup(it).isNotEmpty() }) {
            val t = Ui.text(ctx, g, 12f, Ui.DIM, true).apply {
                letterSpacing = 0.1f
                setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 10), Ui.dp(ctx, 14), Ui.dp(ctx, 10))
                isClickable = true
                setOnClickListener { select(g) }
            }
            tabs.add(t to g)
            row.addView(t, Ui.lp(Ui.WRAP, Ui.WRAP).apply { rightMargin = Ui.dp(ctx, 4) })
        }
        col.addView(
            HorizontalScrollView(ctx).apply {
                isHorizontalScrollBarEnabled = false
                addView(row)
            },
            Ui.lp(Ui.MATCH, Ui.WRAP).apply { bottomMargin = Ui.dp(ctx, 10) },
        )
        holder = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(holder, Ui.lp(Ui.MATCH, Ui.WRAP))
        select(group)
        return Ui.scrollPage(ctx, col)
    }

    private fun select(g: String) {
        group = g
        for ((t, name) in tabs) {
            val on = name == g
            t.setTextColor(if (on) Ui.ON_ACCENT else Ui.DIM)
            t.background = Ui.round(if (on) Ui.ACCENT else Ui.SURFACE2, Ui.dp(ctx, 3).toFloat(), if (on) Ui.ACCENT else Ui.STROKE, Ui.dp(ctx, 1))
        }
        holder.removeAllViews()
        controls.clear()
        LcdSelection.clear()
        holder.addView(ParamViews.lcdPanel(ctx, g, controls, host::showHelp), Ui.lp(Ui.MATCH, Ui.WRAP))
    }

    override fun sync() {
        for (c in controls) c.sync()
    }

    override fun onShown() = sync()
}
