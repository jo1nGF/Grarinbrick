package com.grainbrick.android.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

/** One selectable audio device. id 0 means "system default". */
class DeviceItem(val id: Int, val label: String) {
    override fun toString() = label
}

object AudioDevices {
    // Numeric AudioDeviceInfo.TYPE_* values (kept as literals so newer types are safe on old OS versions).
    private val OUTPUT_TYPES = setOf(
        2,  // builtin speaker
        3,  // wired headset
        4,  // wired headphones
        5,  // line analog
        6,  // line digital
        8,  // bluetooth A2DP
        9,  // HDMI
        11, // USB device
        12, // USB accessory
        13, // dock
        22, // USB headset
        23, // hearing aid
        26, // BLE headset
        27, // BLE speaker
    )
    private val INPUT_TYPES = setOf(
        3,  // wired headset
        5,  // line analog
        6,  // line digital
        11, // USB device
        12, // USB accessory
        15, // builtin mic
        22, // USB headset
        26, // BLE headset
    )

    fun outputs(context: Context): List<DeviceItem> = list(context, AudioManager.GET_DEVICES_OUTPUTS, OUTPUT_TYPES)
    fun inputs(context: Context): List<DeviceItem> = list(context, AudioManager.GET_DEVICES_INPUTS, INPUT_TYPES)

    private fun list(context: Context, flag: Int, allowed: Set<Int>): List<DeviceItem> {
        val out = ArrayList<DeviceItem>()
        out.add(DeviceItem(0, "System default"))
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return out
        val seen = HashSet<Int>()
        for (d: AudioDeviceInfo in am.getDevices(flag)) {
            if (d.type !in allowed || !seen.add(d.id)) continue
            val product = d.productName?.toString()?.trim().orEmpty()
            val kind = typeName(d.type)
            val label = if (product.isEmpty() || product.equals(kind, true) || product == android.os.Build.MODEL) kind else "$kind - $product"
            out.add(DeviceItem(d.id, label))
        }
        return out
    }

    private fun typeName(type: Int): String = when (type) {
        2 -> "Speaker"
        3 -> "Wired headset"
        4 -> "Headphones"
        5, 6 -> "Line"
        8 -> "Bluetooth"
        9 -> "HDMI"
        11, 12 -> "USB audio"
        13 -> "Dock"
        15 -> "Built-in mic"
        22 -> "USB headset"
        23 -> "Hearing aid"
        26, 27 -> "Bluetooth LE"
        else -> "Device"
    }
}
