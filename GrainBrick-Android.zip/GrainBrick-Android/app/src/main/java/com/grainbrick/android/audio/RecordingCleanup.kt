package com.grainbrick.android.audio

import kotlin.math.abs
import kotlin.math.min

/**
 * What a fresh microphone take needs before it becomes a sample:
 *  - the DC offset removed (it makes every grain thump, because each grain is windowed),
 *  - a refusal when nothing was captured (denied permission, muted or wrong input),
 *  - quiet takes brought up to about -1 dBFS (unprocessed phone microphones are very quiet),
 *  - short fades at both ends, so the take does not click when it loops.
 */
object RecordingCleanup {
    const val SILENT_PEAK = 0.001f      // -60 dBFS: below this nothing useful was recorded
    const val TARGET_PEAK = 0.891f      // -1 dBFS
    const val QUIET_PEAK = 0.5f         // takes louder than this keep their level
    const val MAX_GAIN = 15.85f         // +24 dB: never turn the noise floor of a silent room up further

    class Result(val peakBefore: Float, val gain: Float, val silent: Boolean) {
        val gainDb: Float get() = if (gain <= 0f) 0f else (20.0 * Math.log10(gain.toDouble())).toFloat()
    }

    /** Works in place. For a mono take [r] is the same array as [l] and is processed once. */
    fun process(l: FloatArray, r: FloatArray, sampleRate: Int): Result {
        val n = l.size
        if (n == 0) return Result(0f, 1f, true)
        val stereo = r !== l
        removeDc(l)
        if (stereo) removeDc(r)
        var peak = 0f
        for (i in 0 until n) {
            peak = maxOf(peak, abs(l[i]))
            if (stereo) peak = maxOf(peak, abs(r[i]))
        }
        if (peak < SILENT_PEAK) return Result(peak, 1f, true)
        val gain = if (peak < QUIET_PEAK) min(TARGET_PEAK / peak, MAX_GAIN) else 1f
        val fade = min(n / 2, (sampleRate * 0.004f).toInt())
        for (i in 0 until n) {
            val edge = min(i, n - 1 - i)
            val g = if (edge < fade) gain * (edge.toFloat() / fade) else gain
            l[i] *= g
            if (stereo) r[i] *= g
        }
        return Result(peak, gain, false)
    }

    private fun removeDc(x: FloatArray) {
        var sum = 0.0
        for (v in x) sum += v
        val mean = (sum / x.size).toFloat()
        if (mean == 0f) return
        for (i in x.indices) x[i] -= mean
    }
}
