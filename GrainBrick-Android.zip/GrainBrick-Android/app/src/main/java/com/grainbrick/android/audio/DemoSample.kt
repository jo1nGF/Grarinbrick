package com.grainbrick.android.audio

import com.grainbrick.android.SampleBuffer
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Procedurally generated starter material (an evolving two-chord pad), so the app is playable
 * the first time it is opened without shipping any third-party audio. The two chords crossfade
 * over exactly the length of the sample, so it loops without a seam.
 */
object DemoSample {
    const val NAME = "DEMO PAD"
    const val FILE = "demo-pad.wav"
    const val RATE = 44100
    private const val SECONDS = 14

    fun generate(): SampleBuffer {
        val n = RATE * SECONDS
        val l = FloatArray(n)
        val r = FloatArray(n)
        val chords = arrayOf(
            doubleArrayOf(110.00, 164.81, 220.00, 261.63, 329.63, 392.00), // Am9-ish
            doubleArrayOf(87.31, 130.81, 174.61, 220.00, 261.63, 329.63),  // Fmaj9-ish
        )
        val detune = doubleArrayOf(-0.0035, 0.0, 0.0042)
        val twoPi = 2.0 * PI
        val len = SECONDS.toDouble()

        for ((ci, chord) in chords.withIndex()) {
            for ((vi, f0) in chord.withIndex()) {
                val lfoCycles = 2 + (vi + ci) % 4          // integer cycles per loop => seamless
                val lfoPhase = vi * 1.1 + ci * 0.7
                val basePan = (((vi * 5 + ci * 3) % 7) / 6.0 * 2.0 - 1.0) * 0.6
                val voiceAmp = 0.11 / sqrt(1.0 + vi * 0.35)
                for (k in 0 until 3) {
                    val f = f0 * (1.0 + detune[k])
                    val w = twoPi * f / RATE
                    val cw = cos(w)
                    val sw = sin(w)
                    var c = 1.0
                    var s = 0.0
                    val phase0 = (vi * 31 + k * 17 + ci * 7) * 0.37
                    // start phase
                    c = cos(phase0); s = sin(phase0)
                    val pan = (basePan + (k - 1) * 0.25).coerceIn(-1.0, 1.0)
                    val th = (pan + 1.0) * PI * 0.25
                    val gl = cos(th) * 1.4142135623730951
                    val gr = sin(th) * 1.4142135623730951
                    for (i in 0 until n) {
                        val t = i.toDouble() / RATE
                        val chordW = if (ci == 0) 0.5 + 0.5 * cos(twoPi * t / len) else 0.5 - 0.5 * cos(twoPi * t / len)
                        val lfo = 0.65 + 0.35 * sin(twoPi * lfoCycles * t / len + lfoPhase)
                        // soft waveform: fundamental + 2nd + 3rd harmonic
                        val s2 = 2.0 * s * c
                        val s3 = 3.0 * s - 4.0 * s * s * s
                        val v = (s + 0.22 * s2 + 0.10 * s3) * voiceAmp * chordW * chordW * lfo
                        l[i] += (v * gl).toFloat()
                        r[i] += (v * gr).toFloat()
                        val nc = c * cw - s * sw
                        s = s * cw + c * sw
                        c = nc
                    }
                }
            }
        }

        // Breath: slow lowpassed noise, different on each channel.
        val rnd = Random(20240607L)
        var bl = 0.0
        var br = 0.0
        for (i in 0 until n) {
            bl += 0.02 * (rnd.nextDouble() * 2.0 - 1.0 - bl)
            br += 0.02 * (rnd.nextDouble() * 2.0 - 1.0 - br)
            l[i] += (bl * 0.05).toFloat()
            r[i] += (br * 0.05).toFloat()
        }

        // 0.4 s fades at both ends (kept inside the loop crossfade) and normalise to -2 dBFS.
        val fade = (0.4 * RATE).toInt()
        for (i in 0 until fade) {
            val g = (i.toFloat() / fade).let { it * it * (3f - 2f * it) }
            l[i] *= g; r[i] *= g
            l[n - 1 - i] *= g; r[n - 1 - i] *= g
        }
        var peak = 1e-6f
        for (i in 0 until n) peak = maxOf(peak, abs(l[i]), abs(r[i]))
        val gain = 0.8f / peak
        for (i in 0 until n) { l[i] *= gain; r[i] *= gain }
        return SampleBuffer(NAME, l, r, RATE, "samples/$FILE", mono = false)
    }
}
