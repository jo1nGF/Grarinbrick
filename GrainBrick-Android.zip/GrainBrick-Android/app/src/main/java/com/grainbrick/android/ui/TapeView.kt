package com.grainbrick.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Two tape reels and the tape path over a head. The reels turn while the transport plays and
 * their speed wobbles with the WOW and FLUTTER settings, so those two knobs can be seen as well
 * as heard. Pure decoration: it reads nothing from the audio engine but the parameters.
 */
class TapeView(context: Context) : View(context) {
    private var playing = false
    private var tapeOn = true
    private var wow = 0f
    private var flutter = 0f

    private var angle = 0f          // radians
    private var speed = 0f          // 0..1 of the nominal reel speed
    private var phaseWow = 0f
    private var phaseFlutter = 0f
    private var lastNanos = 0L

    private val d = resources.displayMetrics.density
    private val pack = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Ui.SURFACE2 }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Ui.DIM }
    private val spoke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; strokeCap = Paint.Cap.BUTT; color = Ui.TEXT }
    private val hub = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Ui.BG }
    private val tape = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; strokeJoin = Paint.Join.ROUND }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Ui.MONO_BOLD; textSize = 10f * d; letterSpacing = 0.15f }
    private val marks = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.DIM; strokeWidth = 1.5f * d }
    private val path = Path()

    init {
        background = Ui.glass(context)
    }

    fun setState(playing: Boolean, tapeOn: Boolean, wow: Float, flutter: Float) {
        val w = wow.coerceIn(0f, 1f)
        val f = flutter.coerceIn(0f, 1f)
        val changed = playing != this.playing || tapeOn != this.tapeOn || w != this.wow || f != this.flutter
        this.playing = playing
        this.tapeOn = tapeOn
        this.wow = w
        this.flutter = f
        if (changed && isAttachedToWindow) postInvalidateOnAnimation()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNanos = 0L
        postInvalidateOnAnimation()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), resolveSize((124 * d).toInt(), heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1e9f).coerceIn(0f, 0.1f)
        lastNanos = now
        val target = if (playing && tapeOn) 1f else 0f
        speed += (target - speed) * (1f - exp(-dt / (if (target > speed) 0.25f else 0.6f)))
        phaseWow += dt * 2f * PI.toFloat() * 0.55f
        phaseFlutter += dt * 2f * PI.toFloat() * 7.3f
        val wobble = 1f + wow * 0.35f * sin(phaseWow) + flutter * 0.12f * sin(phaseFlutter)
        angle += dt * 2.2f * speed * wobble

        val w = width.toFloat()
        val h = height.toFloat()
        val r = min(h * 0.34f, w * 0.16f)
        val cy = h * 0.46f
        val lx = w * 0.27f
        val rx = w * 0.73f
        val lit = tapeOn
        // tape path: left reel bottom -> head -> right reel bottom
        tape.color = if (lit) (if (speed > 0.05f) Ui.ACCENT else Ui.ACCENT_DIM) else Ui.STROKE
        val hy = h * 0.88f
        path.reset()
        path.moveTo(lx - r * 0.9f, cy + r * 0.4f)
        path.lineTo(w * 0.40f, hy)
        path.lineTo(w * 0.60f, hy)
        path.lineTo(rx + r * 0.9f, cy + r * 0.4f)
        canvas.drawPath(path, tape)
        // head
        headPaint.color = if (lit) Ui.TEXT else Ui.STROKE
        canvas.drawRect(w * 0.46f, hy - 4f * d, w * 0.54f, hy + 2f * d, headPaint)

        reel(canvas, lx, cy, r * 1.0f, angle)
        reel(canvas, rx, cy, r * 0.84f, angle * 1.18f + 1f)

        label.color = if (lit) Ui.ACCENT else Ui.DIM
        label.textAlign = Paint.Align.LEFT
        canvas.drawText(if (lit) "TAPE" else "TAPE BYPASS", 12f * d, 18f * d, label)
        label.color = Ui.DIM
        label.textAlign = Paint.Align.RIGHT
        canvas.drawText(if (speed > 0.05f && lit) "PLAY" else "STOP", w - 12f * d, 18f * d, label)
        Ui.cornerMarks(canvas, w, h, 8f * d, marks)

        if (speed > 0.002f || target > 0f) postInvalidateOnAnimation()
    }

    private fun reel(canvas: Canvas, cx: Float, cy: Float, r: Float, a: Float) {
        canvas.drawCircle(cx, cy, r, pack)
        canvas.drawCircle(cx, cy, r, ring)
        canvas.drawCircle(cx, cy, r * 0.30f, hub)
        for (k in 0 until 3) {
            val t = a + k * (2f * PI.toFloat() / 3f)
            canvas.drawLine(cx + cos(t) * r * 0.30f, cy + sin(t) * r * 0.30f, cx + cos(t) * r * 0.82f, cy + sin(t) * r * 0.82f, spoke)
        }
        canvas.drawCircle(cx, cy, r * 0.30f, ring)
    }
}
