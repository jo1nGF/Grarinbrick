package com.grainbrick.android.audio

import java.io.File

/**
 * A saved instrument state. The JSON layout deliberately matches the project files written by the
 * original GrainBrick (format 1) so that those can be imported:
 *
 *   { "format": 1, "name": "AMBIENT", "parameters": { "grain.size": 1.4, ... },
 *     "sample": { "path": "samples/x.wav", "type": "relative" } }
 */
class ProjectData(
    var name: String,
    val params: LinkedHashMap<String, Float> = LinkedHashMap(),
    var samplePath: String? = null,
    /** "relative" (inside the app's samples folder), "builtin" (the demo pad) or "absolute" (foreign). */
    var sampleType: String? = null,
) {
    /** File name without any directory part, whatever separator the project used. */
    fun sampleFileName(): String? {
        val p = samplePath ?: return null
        val cut = maxOf(p.lastIndexOf('/'), p.lastIndexOf('\\'))
        val n = if (cut >= 0) p.substring(cut + 1) else p
        return n.ifBlank { null }
    }
}

object ProjectCodec {
    const val FORMAT = 1
    const val TYPE_RELATIVE = "relative"
    const val TYPE_BUILTIN = "builtin"
    private const val MAX_PARAMS = 4000

    /** Letters, digits, space and a few safe symbols; never empty; at most 40 chars. */
    fun sanitizeName(raw: String): String {
        val sb = StringBuilder()
        for (c in raw.trim()) {
            if (c.isLetterOrDigit() || c == ' ' || c == '_' || c == '-' || c == '(' || c == ')' || c == '.') sb.append(c)
            if (sb.length >= 40) break
        }
        val s = sb.toString().trim().trimStart('.').trim()
        return s.ifEmpty { "PROJECT" }
    }

    fun encode(p: ProjectData): String {
        val root = LinkedHashMap<String, Any?>()
        root["format"] = FORMAT
        root["name"] = p.name
        val params = LinkedHashMap<String, Any?>()
        for (k in p.params.keys.sorted()) params[k] = p.params.getValue(k)
        root["parameters"] = params
        val path = p.samplePath
        if (path != null) {
            val s = LinkedHashMap<String, Any?>()
            s["path"] = path
            s["type"] = p.sampleType ?: TYPE_RELATIVE
            root["sample"] = s
        }
        return MiniJson.stringify(root)
    }

    /** @throws MiniJson.JsonException when the text is not a usable project. */
    fun decode(text: String, fallbackName: String): ProjectData {
        val root = MiniJson.parse(text) as? Map<*, *> ?: throw MiniJson.JsonException("Project must be a JSON object")
        val rawParams = root["parameters"] as? Map<*, *> ?: throw MiniJson.JsonException("Project has no \"parameters\" section")
        val name = (root["name"] as? String)?.takeIf { it.isNotBlank() }?.let { sanitizeName(it) } ?: sanitizeName(fallbackName)
        val p = ProjectData(name)
        for ((k, v) in rawParams) {
            if (k !is String || p.params.size >= MAX_PARAMS) continue
            when (v) {
                is Double -> if (!v.isNaN() && !v.isInfinite()) p.params[k] = v.toFloat()
                is Boolean -> p.params[k] = if (v) 1f else 0f
                else -> Unit
            }
        }
        val sample = root["sample"] as? Map<*, *>
        if (sample != null) {
            p.samplePath = (sample["path"] as? String)?.takeIf { it.isNotBlank() }
            p.sampleType = sample["type"] as? String
        }
        return p
    }
}

/** Plain-file project library. */
class ProjectStore(private val dir: File) {
    init {
        dir.mkdirs()
    }

    fun fileFor(name: String) = File(dir, ProjectCodec.sanitizeName(name) + ".json")

    fun list(): List<String> =
        (dir.listFiles { f -> f.isFile && f.name.endsWith(".json", ignoreCase = true) } ?: emptyArray())
            .map { it.name.dropLast(5) }
            .sortedWith(String.CASE_INSENSITIVE_ORDER)

    fun exists(name: String) = fileFor(name).isFile

    fun save(p: ProjectData) {
        p.name = ProjectCodec.sanitizeName(p.name)
        val target = fileFor(p.name)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(ProjectCodec.encode(p), Charsets.UTF_8)
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) {
                tmp.delete()
                throw java.io.IOException("Could not write ${target.name}")
            }
        }
    }

    fun load(name: String): ProjectData = ProjectCodec.decode(fileFor(name).readText(Charsets.UTF_8), name)

    fun delete(name: String): Boolean = fileFor(name).delete()

    /** "NAME", then "NAME 2", "NAME 3", ... until unused. */
    fun uniqueName(base: String): String {
        val b = ProjectCodec.sanitizeName(base)
        if (!exists(b)) return b
        var i = 2
        while (exists("$b $i")) i++
        return "$b $i"
    }
}
