cmake_minimum_required(VERSION 3.22.1)
project(grainbrick LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Always optimise the native code, even for debug APKs: an unoptimised granular engine cannot
# run in real time on a phone.
set(CMAKE_BUILD_TYPE Release)

# Oboe is vendored (Apache-2.0) so the build needs no Maven/prefab package.
set(OBOE_DIR ${CMAKE_CURRENT_SOURCE_DIR}/../../../../third_party/oboe)
add_subdirectory(${OBOE_DIR} oboe-bin)
# Never let a newer compiler's extra warnings fail the build of the vendored library.
target_compile_options(oboe PRIVATE -Wno-error)

# SoundTouch (LGPL-2.1, third_party/soundtouch) pitch-shifts the shimmer. It is built as its own
# shared library, libSoundTouch.so, and only reached through the C functions of engine/st_bridge.h,
# so it can be swapped for a modified build as the LGPL requires.
set(ST_DIR ${CMAKE_CURRENT_SOURCE_DIR}/../../../../third_party/soundtouch)
add_library(SoundTouch SHARED
    ${ST_DIR}/source/AAFilter.cpp
    ${ST_DIR}/source/FIFOSampleBuffer.cpp
    ${ST_DIR}/source/FIRFilter.cpp
    ${ST_DIR}/source/InterpolateCubic.cpp
    ${ST_DIR}/source/InterpolateLinear.cpp
    ${ST_DIR}/source/InterpolateShannon.cpp
    ${ST_DIR}/source/PeakFinder.cpp
    ${ST_DIR}/source/RateTransposer.cpp
    ${ST_DIR}/source/SoundTouch.cpp
    ${ST_DIR}/source/TDStretch.cpp
    ${ST_DIR}/source/cpu_detect_x86.cpp
    ${ST_DIR}/source/mmx_optimized.cpp
    ${ST_DIR}/source/sse_optimized.cpp
    soundtouch/st_bridge.cpp)
target_include_directories(SoundTouch PRIVATE ${ST_DIR}/include ${ST_DIR}/source)
target_compile_definitions(SoundTouch PRIVATE SOUNDTOUCH_FLOAT_SAMPLES)
target_compile_options(SoundTouch PRIVATE -O3 -fexceptions -fno-math-errno -w)
set_target_properties(SoundTouch PROPERTIES CXX_VISIBILITY_PRESET hidden)
target_link_options(SoundTouch PRIVATE -Wl,-z,max-page-size=16384)

# Original Rings / Elements DSP by Emilie Gillet (MIT, third_party/mutable) plus our wrappers.
# TEST selects the portable C++ paths instead of the ARM-only assembly of the firmware.
set(MUTABLE_DIR ${CMAKE_CURRENT_SOURCE_DIR}/../../../../third_party/mutable)
file(GLOB MUTABLE_SOURCES
    ${MUTABLE_DIR}/rings/dsp/*.cc ${MUTABLE_DIR}/rings/resources.cc
    ${MUTABLE_DIR}/elements/dsp/*.cc ${MUTABLE_DIR}/elements/resources.cc
    ${MUTABLE_DIR}/stmlib/dsp/atan.cc ${MUTABLE_DIR}/stmlib/dsp/units.cc ${MUTABLE_DIR}/stmlib/utils/random.cc)
set_source_files_properties(${MUTABLE_SOURCES} engine/mutable_rings.cpp engine/mutable_elements.cpp
    PROPERTIES COMPILE_OPTIONS "-w" COMPILE_DEFINITIONS TEST)

add_library(grainbrick SHARED
    engine/engine.cpp
    engine/params.cpp
    engine/mutable_rings.cpp
    engine/mutable_elements.cpp
    ${MUTABLE_SOURCES}
    audio_io.cpp
    jni_bridge.cpp)

target_include_directories(grainbrick PRIVATE ${MUTABLE_DIR} engine)
target_compile_options(grainbrick PRIVATE -Wall -Wextra -O3 -fno-math-errno -fno-trapping-math)
# NOTE: do not add -ffast-math: the engine relies on std::isfinite() NaN guards.
target_link_libraries(grainbrick PRIVATE oboe SoundTouch log)
# 16 KB page size compatibility (required for Android 15+ devices / Google Play).
target_link_options(grainbrick PRIVATE -Wl,-z,max-page-size=16384)
