#include "audio_io.h"

#include <android/log.h>

#include <chrono>
#include <cstring>
#include <thread>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "GrainBrick", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "GrainBrick", __VA_ARGS__)

namespace gb {

namespace {
constexpr int kScratchFrames = 1024;
}

// ---------------------------------------------------------------------------------------------
// callbacks
// ---------------------------------------------------------------------------------------------
class AudioIO::OutCallback : public oboe::AudioStreamDataCallback {
 public:
  explicit OutCallback(AudioIO* io) : io_(io) {}
  oboe::DataCallbackResult onAudioReady(oboe::AudioStream* /*stream*/, void* audioData,
                                        int32_t numFrames) override {
    float* out = static_cast<float*>(audioData);
    AudioIO& io = *io_;
    const bool useIn = io.inputActive_.load(std::memory_order_relaxed) && io.monitorOk_.load(std::memory_order_relaxed);
    float* scratch = io.scratch_.data();
    int done = 0;
    while (done < numFrames) {
      const int chunk = std::min(numFrames - done, kScratchFrames);
      const float* inp = nullptr;
      if (useIn) {
        // Keep the monitoring latency bounded: if the input ran ahead, drop the oldest audio.
        const size_t avail = io.ring_.available();
        const size_t maxKeep = static_cast<size_t>(numFrames) * 3 + 512;
        if (avail > maxKeep) io.ring_.skip(avail - static_cast<size_t>(numFrames) - 256);
        const size_t got = io.ring_.read(scratch, static_cast<size_t>(chunk));
        if (got < static_cast<size_t>(chunk))
          std::memset(scratch + 2 * got, 0, sizeof(float) * 2 * (static_cast<size_t>(chunk) - got));
        inp = scratch;
      }
      io.engine_.render(out + 2 * done, chunk, inp);
      done += chunk;
    }
    return oboe::DataCallbackResult::Continue;
  }

 private:
  AudioIO* io_;
};

class AudioIO::InCallback : public oboe::AudioStreamDataCallback {
 public:
  InCallback(AudioIO* io, int channels) : io_(io), channels_(channels) {
    conv_.assign(static_cast<size_t>(kScratchFrames) * 2, 0.f);
  }
  oboe::DataCallbackResult onAudioReady(oboe::AudioStream* /*stream*/, void* audioData,
                                        int32_t numFrames) override {
    const float* in = static_cast<const float*>(audioData);
    int done = 0;
    while (done < numFrames) {
      const int chunk = std::min(numFrames - done, kScratchFrames);
      float* c = conv_.data();
      for (int i = 0; i < chunk; ++i) {
        const float* f = in + static_cast<size_t>(done + i) * static_cast<size_t>(channels_);
        const float l = f[0];
        const float r = channels_ > 1 ? f[1] : f[0];
        c[2 * i] = l;
        c[2 * i + 1] = r;
      }
      // Recording is taken here, straight from the input stream: the ring below only serves the
      // live monitor and is allowed to drop or pad audio to keep its latency low.
      io_->engine_.recordInput(c, chunk);
      if (io_->monitorOk_.load(std::memory_order_relaxed)) io_->ring_.write(c, static_cast<size_t>(chunk));
      done += chunk;
    }
    return oboe::DataCallbackResult::Continue;
  }

 private:
  AudioIO* io_;
  int channels_;
  std::vector<float> conv_;
};

class AudioIO::ErrCallback : public oboe::AudioStreamErrorCallback {
 public:
  explicit ErrCallback(AudioIO* io) : io_(io) {}
  void onErrorAfterClose(oboe::AudioStream* /*stream*/, oboe::Result error) override {
    LOGW("stream error: %s", oboe::convertToText(error));
    io_->scheduleRestart();
  }

 private:
  AudioIO* io_;
};

// ---------------------------------------------------------------------------------------------
// AudioIO
// ---------------------------------------------------------------------------------------------
AudioIO::AudioIO(Engine& engine) : engine_(engine) {
  scratch_.assign(static_cast<size_t>(kScratchFrames) * 2, 0.f);
  ring_.init(1 << 15);
}

std::string AudioIO::lastMessage() const {
  std::lock_guard<std::mutex> l(msgMutex_);
  return message_;
}
void AudioIO::setMessage(const std::string& m) {
  std::lock_guard<std::mutex> l(msgMutex_);
  message_ = m;
}

std::string AudioIO::start(int outputDeviceId, int inputDeviceId, bool useInput) {
  std::lock_guard<std::mutex> lock(mutex_);
  reqOut_ = outputDeviceId;
  reqIn_ = inputDeviceId;
  reqUseInput_ = useInput;
  wantRunning_.store(true);
  return startLocked(outputDeviceId, inputDeviceId, useInput);
}

void AudioIO::stop() {
  std::lock_guard<std::mutex> lock(mutex_);
  wantRunning_.store(false);
  stopLocked();
}

void AudioIO::stopLocked() {
  running_.store(false);
  inputActive_.store(false);
  if (in_) {
    in_->requestStop();
    in_->close();
    in_.reset();
  }
  if (out_) {
    out_->requestStop();
    out_->close();
    out_.reset();
  }
  inCb_.reset();
  outCb_.reset();
  errCb_.reset();
}

std::string AudioIO::startLocked(int outId, int inId, bool useInput) {
  stopLocked();
  setMessage("");

  errCb_ = std::make_shared<ErrCallback>(this);
  outCb_ = std::make_shared<OutCallback>(this);

  // ---- output ----
  oboe::AudioStreamBuilder ob;
  ob.setDirection(oboe::Direction::Output)
      ->setFormat(oboe::AudioFormat::Float)
      ->setChannelCount(oboe::ChannelCount::Stereo)
      ->setUsage(oboe::Usage::Media)
      ->setContentType(oboe::ContentType::Music)
      ->setPerformanceMode(useInput ? oboe::PerformanceMode::LowLatency : oboe::PerformanceMode::None)
      ->setSharingMode(oboe::SharingMode::Shared)
      ->setFormatConversionAllowed(true)
      ->setChannelConversionAllowed(true)
      ->setDataCallback(outCb_)
      ->setErrorCallback(errCb_);
  if (outId > 0) ob.setDeviceId(outId);
  oboe::Result r = ob.openStream(out_);
  if (r != oboe::Result::OK && outId > 0) {
    LOGW("output device %d failed (%s), using the default device", outId, oboe::convertToText(r));
    setMessage("Selected output unavailable, using the default output.");
    ob.setDeviceId(oboe::kUnspecified);
    r = ob.openStream(out_);
  }
  if (r != oboe::Result::OK) {
    std::string m = std::string("Could not open audio output: ") + oboe::convertToText(r);
    LOGW("%s", m.c_str());
    stopLocked();
    return m;
  }
  const int sr = out_->getSampleRate();
  const int burst = out_->getFramesPerBurst();
  // A couple of bursts of buffering keeps the heavy effects chain glitch-free.
  out_->setBufferSizeInFrames(std::max(burst * (useInput ? 2 : 4), burst));
  engine_.prepare(static_cast<double>(sr));
  sampleRate_.store(sr);
  burst_.store(burst);
  LOGI("output: %d Hz, burst %d, api %s, device %d", sr, burst,
       out_->getAudioApi() == oboe::AudioApi::AAudio ? "AAudio" : "OpenSL ES", out_->getDeviceId());

  // ---- input (optional) ----
  inputActive_.store(false);
  inputChannels_.store(0);
  monitorOk_.store(true);
  engine_.setInputSampleRate(0);
  if (useInput) {
    ring_.init(1 << 15);
    oboe::AudioStreamBuilder ib;
    // Callback is created after the stream reports its channel count, so open without one first.
    ib.setDirection(oboe::Direction::Input)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Unspecified)
        ->setSampleRate(sr)
        ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
        ->setInputPreset(oboe::InputPreset::Unprocessed)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Shared)
        ->setFormatConversionAllowed(true)
        ->setErrorCallback(errCb_);
    if (inId > 0) ib.setDeviceId(inId);
    // Probe channel count with a blocking open, then reopen with a callback for that count.
    std::shared_ptr<oboe::AudioStream> probe;
    oboe::Result ir = ib.openStream(probe);
    if (ir != oboe::Result::OK && inId > 0) {
      ib.setDeviceId(oboe::kUnspecified);
      ir = ib.openStream(probe);
      if (ir == oboe::Result::OK) setMessage("Selected input unavailable, using the default input.");
    }
    if (ir == oboe::Result::OK) {
      const int ch = std::max(1, probe->getChannelCount());
      const int devId = probe->getDeviceId();
      probe->close();
      probe.reset();
      inCb_ = std::make_shared<InCallback>(this, ch);
      ib.setChannelCount(ch)->setDataCallback(inCb_);
      if (devId > 0) ib.setDeviceId(devId);
      ir = ib.openStream(in_);
      if (ir == oboe::Result::OK) {
        inputChannels_.store(ch);
        const int inRate = in_->getSampleRate();
        LOGI("input: %d Hz, %d ch, device %d", inRate, ch, in_->getDeviceId());
        // Recordings are made at the input's real rate. If the system could not convert it to the
        // output rate, the live monitor is switched off (it would sound transposed).
        engine_.setInputSampleRate(inRate);
        if (inRate != sr) {
          monitorOk_.store(false);
          LOGW("input rate %d differs from output rate %d: recording at %d Hz, monitor off", inRate, sr, inRate);
          setMessage("Input runs at " + std::to_string(inRate) + " Hz; live monitoring is off.");
        }
      }
    }
    if (ir != oboe::Result::OK) {
      LOGW("input failed: %s", oboe::convertToText(ir));
      setMessage(std::string("Input unavailable: ") + oboe::convertToText(ir));
      in_.reset();
      inCb_.reset();
    }
  }

  // Start the input first so the ring is filling when the output callback begins.
  if (in_) {
    oboe::Result sr2 = in_->requestStart();
    if (sr2 == oboe::Result::OK) {
      inputActive_.store(true);
    } else {
      setMessage(std::string("Input could not start: ") + oboe::convertToText(sr2));
      in_->close();
      in_.reset();
      inCb_.reset();
    }
  }
  r = out_->requestStart();
  if (r != oboe::Result::OK) {
    std::string m = std::string("Could not start audio output: ") + oboe::convertToText(r);
    LOGW("%s", m.c_str());
    stopLocked();
    return m;
  }
  running_.store(true);
  return "";
}

void AudioIO::scheduleRestart() {
  if (!wantRunning_.load()) return;
  bool expected = false;
  if (!restarting_.compare_exchange_strong(expected, true)) return;
  std::thread([this] {
    std::this_thread::sleep_for(std::chrono::milliseconds(250));
    {
      std::lock_guard<std::mutex> lock(mutex_);
      if (wantRunning_.load()) {
        LOGI("restarting audio after stream error");
        std::string err = startLocked(reqOut_, reqIn_, reqUseInput_);
        if (!err.empty()) {
          // Last resort: default devices, no input.
          err = startLocked(0, 0, false);
          if (!err.empty()) setMessage(err);
        }
      }
    }
    restarting_.store(false);
  }).detach();
}

}  // namespace gb
