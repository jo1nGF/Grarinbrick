// JNI bridge: com.grainbrick.android.NativeEngine
#include <android/log.h>
#include <jni.h>

#include <cstdio>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "audio_io.h"
#include "engine/engine.h"
#include "engine/params.h"

namespace {

gb::Engine* g_engine = nullptr;  // process lifetime (never freed on purpose)
gb::AudioIO* g_io = nullptr;
std::mutex g_initMutex;

jstring toJString(JNIEnv* env, const std::string& s) {
  // All strings we pass are plain ASCII (checked by the host tests for parameter help text).
  return env->NewStringUTF(s.c_str());
}

}  // namespace

#define GB_JNI(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_grainbrick_android_NativeEngine_##name

GB_JNI(jboolean, nInit)(JNIEnv*, jobject) {
  std::lock_guard<std::mutex> lock(g_initMutex);
  if (!g_engine) {
    g_engine = new gb::Engine();
    g_engine->prepare(48000.0);  // re-prepared with the real stream rate when audio starts
    g_io = new gb::AudioIO(*g_engine);
  }
  return JNI_TRUE;
}

GB_JNI(jint, nParamCount)(JNIEnv*, jobject) { return gb::paramCount(); }

// Tab separated: id, group, label, unit, min, max, default, kind, curve, choices, help
GB_JNI(jstring, nParamInfo)(JNIEnv* env, jobject, jint index) {
  const gb::ParamInfo& p = gb::paramInfo(index);
  char nums[160];
  std::snprintf(nums, sizeof(nums), "%.6g\t%.6g\t%.6g\t%d\t%d", static_cast<double>(p.min),
                static_cast<double>(p.max), static_cast<double>(p.def), static_cast<int>(p.kind),
                static_cast<int>(p.curve));
  std::string s = std::string(p.id) + "\t" + p.group + "\t" + p.label + "\t" + p.unit + "\t" + nums + "\t" +
                  (p.choices ? p.choices : "") + "\t" + p.help;
  return toJString(env, s);
}

GB_JNI(void, nSetParam)(JNIEnv*, jobject, jint index, jfloat value) {
  if (g_engine) g_engine->setParam(index, value);
}
GB_JNI(jfloat, nGetParam)(JNIEnv*, jobject, jint index) {
  return g_engine ? g_engine->getParam(index) : 0.f;
}
GB_JNI(void, nSnapParams)(JNIEnv*, jobject) {
  if (g_engine) g_engine->snapParams();
}

GB_JNI(void, nSetSample)(JNIEnv* env, jobject, jfloatArray left, jfloatArray right, jint frames,
                         jint sampleRate) {
  if (!g_engine) return;
  if (!left || frames <= 0 || env->GetArrayLength(left) < frames) {
    g_engine->publishSample(nullptr, nullptr, 0, 48000.0);  // clears the sample
    return;
  }
  jfloat* l = env->GetFloatArrayElements(left, nullptr);
  jfloat* r = (right && env->GetArrayLength(right) >= frames) ? env->GetFloatArrayElements(right, nullptr) : nullptr;
  g_engine->publishSample(l, r ? r : l, frames, static_cast<double>(sampleRate));
  if (r) env->ReleaseFloatArrayElements(right, r, JNI_ABORT);
  env->ReleaseFloatArrayElements(left, l, JNI_ABORT);
}

GB_JNI(jstring, nStartAudio)(JNIEnv* env, jobject, jint outDevice, jint inDevice, jboolean useInput) {
  if (!g_io) return toJString(env, "engine not initialised");
  return toJString(env, g_io->start(outDevice, inDevice, useInput == JNI_TRUE));
}
GB_JNI(void, nStopAudio)(JNIEnv*, jobject) {
  if (g_io) g_io->stop();
}
GB_JNI(jboolean, nIsRunning)(JNIEnv*, jobject) { return (g_io && g_io->running()) ? JNI_TRUE : JNI_FALSE; }
GB_JNI(jboolean, nInputActive)(JNIEnv*, jobject) {
  return (g_io && g_io->inputActive()) ? JNI_TRUE : JNI_FALSE;
}
GB_JNI(jint, nSampleRate)(JNIEnv*, jobject) { return g_io ? g_io->sampleRate() : 0; }
GB_JNI(jint, nFramesPerBurst)(JNIEnv*, jobject) { return g_io ? g_io->framesPerBurst() : 0; }
GB_JNI(jstring, nMessage)(JNIEnv* env, jobject) { return toJString(env, g_io ? g_io->lastMessage() : ""); }

GB_JNI(jint, nStateSize)(JNIEnv*, jobject) { return gb::Engine::kStateSize; }
GB_JNI(void, nGetState)(JNIEnv* env, jobject, jfloatArray out) {
  if (!g_engine || !out) return;
  const jsize n = env->GetArrayLength(out);
  std::vector<float> tmp(static_cast<size_t>(n), 0.f);
  g_engine->getState(tmp.data(), static_cast<int>(n));
  env->SetFloatArrayRegion(out, 0, n, tmp.data());
}

GB_JNI(jboolean, nStartRecording)(JNIEnv*, jobject) {
  return (g_engine && g_engine->startRecording()) ? JNI_TRUE : JNI_FALSE;
}
GB_JNI(void, nStopRecording)(JNIEnv*, jobject) {
  if (g_engine) g_engine->stopRecording();
}
GB_JNI(jint, nRecordedFrames)(JNIEnv*, jobject) { return g_engine ? g_engine->recordedFrames() : 0; }
GB_JNI(jint, nRecordingSampleRate)(JNIEnv*, jobject) {
  return g_engine ? static_cast<jint>(g_engine->recordingSampleRate()) : 48000;
}
// Interleaved stereo float array of the last recording.
GB_JNI(jfloatArray, nGetRecording)(JNIEnv* env, jobject) {
  if (!g_engine) return nullptr;
  const int frames = g_engine->recordedFrames();
  jfloatArray arr = env->NewFloatArray(frames * 2);
  if (!arr || frames <= 0) return arr;
  std::vector<float> tmp(static_cast<size_t>(frames) * 2);
  g_engine->copyRecording(tmp.data(), frames);
  env->SetFloatArrayRegion(arr, 0, frames * 2, tmp.data());
  return arr;
}
