// Resampling pipe from a fixed-rate generator to the audio rate, shared by the Rings and Elements wrappers.
#pragma once

#include <algorithm>
#include <cstddef>

namespace gb {
namespace mutable_detail {

/// Pulls fixed-size blocks from a generator running at `nativeRate` and serves them at `outRate`.
class Pipe {
 public:
  void init(float nativeRate, float outRate) {
    ratio_ = static_cast<double>(nativeRate) / static_cast<double>(outRate);
    reset();
  }
  void reset() {
    std::fill(l_, l_ + kSize, 0.f);
    std::fill(r_, r_ + kSize, 0.f);
    written_ = 0;
    pos_ = 1.0;
  }
  template <typename Gen>
  void pull(float* outL, float* outR, int n, size_t block, Gen&& gen) {
    float bl[64], br[64];
    for (int i = 0; i < n; ++i) {
      const size_t need = static_cast<size_t>(pos_) + 3;
      while (written_ < need) {
        gen(bl, br);
        for (size_t k = 0; k < block; ++k) {
          l_[written_ & kMask] = bl[k];
          r_[written_ & kMask] = br[k];
          ++written_;
        }
      }
      const size_t i1 = static_cast<size_t>(pos_);
      const float f = static_cast<float>(pos_ - static_cast<double>(i1));
      outL[i] += hermite(l_, i1, f);
      outR[i] += hermite(r_, i1, f);
      pos_ += ratio_;
    }
  }

 private:
  static constexpr size_t kSize = 1024, kMask = kSize - 1;
  static float hermite(const float* b, size_t i1, float f) {
    const float ym1 = b[(i1 - 1) & kMask], y0 = b[i1 & kMask], y1 = b[(i1 + 1) & kMask], y2 = b[(i1 + 2) & kMask];
    const float c0 = y0, c1 = 0.5f * (y1 - ym1);
    const float c2 = ym1 - 2.5f * y0 + 2.f * y1 - 0.5f * y2;
    const float c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
    return ((c3 * f + c2) * f + c1) * f + c0;
  }
  float l_[kSize], r_[kSize];
  size_t written_ = 0;
  double pos_ = 1.0;
  double ratio_ = 1.0;
};

inline float smooth(float& state, float target, float k) {
  state += k * (target - state);
  return state;
}
inline float clamp01(float x) { return x < 0.f ? 0.f : (x > 1.f ? 1.f : x); }
/// A knob position for the firmware: the lookup tables read one entry past the end at exactly 1.0, so stay just below.
inline float pot(float x) { return x < 0.f ? 0.f : (x > 0.995f ? 0.995f : x); }


}  // namespace mutable_detail
}  // namespace gb
