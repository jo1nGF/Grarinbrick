// GrainBrick Android - parameter registry (single source of truth).
//
// Parameter ids deliberately match the keys used by the original GrainBrick
// project files ("format": 1, "parameters": {...}) so that those projects can be
// imported. Ranges/semantics are this project's own interpretation.
#pragma once

namespace gb {

enum class Kind : int { Knob = 0, Toggle = 1, Choice = 2 };
enum class Curve : int { Linear = 0, Log = 1 };

// X(ENUM, id, group, label, unit, min, max, default, kind, curve, choices, help)
#define GB_PARAMS(X)                                                                                         \
  /* ---- level / transport ---- */                                                                          \
  X(LEVEL_INPUT_DB, "level.input_db", "MIX", "Input", "dB", -24, 24, 0, Knob, Linear, nullptr,              \
    "Gain applied to the sound source (grain cloud and live input) before the effects chain.")               \
  X(LEVEL_MASTER_DB, "level.master_db", "MIX", "Master", "dB", -36, 12, 0, Knob, Linear, nullptr,            \
    "Final output level. A safety limiter follows this stage.")                                              \
  X(TRANSPORT_PLAYING, "transport.playing", "MIX", "Play", "", 0, 1, 0, Toggle, Linear, nullptr,           \
    "Starts or stops the grain cloud and ORBIX. Effect tails keep ringing after stop.")                      \
  /* ---- grain ---- */                                                                                      \
  X(GRAIN_ENABLED, "grain.enabled", "GRAIN", "Grains", "", 0, 1, 1, Toggle, Linear, nullptr,                \
    "Turns the granular sample player on or off.")                                                           \
  X(GRAIN_DENSITY, "grain.density", "GRAIN", "Density", "%", 0, 100, 50, Knob, Linear, nullptr,             \
    "How many grains are launched per second (about 0.4 to 80 grains/s).")                                   \
  X(GRAIN_SIZE, "grain.size", "GRAIN", "Size", "s", 0.01, 4.0, 0.4, Knob, Log, nullptr,                     \
    "Length of every grain in seconds. Long grains melt into pads, short grains sound granular.")            \
  X(GRAIN_PITCH, "grain.pitch", "GRAIN", "Pitch", "st", -24, 24, 0, Knob, Linear, nullptr,                  \
    "Playback pitch of the grains in semitones.")                                                            \
  X(GRAIN_POSITION, "grain.position", "GRAIN", "Position", "", 0, 1, 0.5, Knob, Linear, nullptr,            \
    "Where in the sample new grains start (0 = start, 1 = end).")                                            \
  X(GRAIN_SPRAY, "grain.spray", "GRAIN", "Spray", "", 0, 1, 0.2, Knob, Linear, nullptr,                     \
    "Random scatter of the start position around Position. 1 = anywhere in the sample.")                     \
  X(GRAIN_WIDTH, "grain.width", "GRAIN", "Width", "", 0, 1, 0.7, Knob, Linear, nullptr,                     \
    "Random stereo placement of each grain.")                                                                \
  /* ---- motion ---- */                                                                                     \
  X(MOTION_ENABLED, "motion.enabled", "MOTION", "Motion", "", 0, 1, 1, Toggle, Linear, nullptr,             \
    "Enables the per-grain motion behaviours below.")                                                        \
  X(MOTION_JUMP, "motion.jump", "MOTION", "Jump", "", 0, 1, 0, Knob, Linear, nullptr,                       \
    "Probability that a grain jumps to a completely random position in the sample.")                         \
  X(MOTION_REVERSE, "motion.reverse", "MOTION", "Reverse", "", 0, 1, 0, Knob, Linear, nullptr,              \
    "Probability that a grain plays backwards.")                                                             \
  X(MOTION_HOLD, "motion.hold", "MOTION", "Hold", "", 0, 1, 0, Knob, Linear, nullptr,                       \
    "Freezes position movement: at 1 Roam stops and Jump is disabled.")                                      \
  X(MOTION_ELASTIC, "motion.elastic", "MOTION", "Elastic", "", 0, 1, 0, Knob, Linear, nullptr,              \
    "Adds rubber-band glide to Pitch changes (up to ~3 seconds).")                                           \
  X(MOTION_CHAOS, "motion.chaos", "MOTION", "Chaos", "", 0, 1, 0, Knob, Linear, nullptr,                    \
    "Randomises grain timing, size and pitch.")                                                              \
  /* ---- roam ---- */                                                                                       \
  X(ROAM_ENABLED, "roam.enabled", "ROAM", "Roam", "", 0, 1, 0, Toggle, Linear, nullptr,                     \
    "Automatically moves the grain start position through the sample.")                                      \
  X(ROAM_MODE, "roam.mode", "ROAM", "Mode", "", 0, 3, 0, Choice, Linear, "Scan|Ping-pong|Sine|Random",      \
    "Scan: repeating forward sweep. Ping-pong: back and forth. Sine: smooth LFO. Random: wandering.")        \
  X(ROAM_RANGE, "roam.range", "ROAM", "Range", "", 0, 1, 0.5, Knob, Linear, nullptr,                        \
    "Portion of the sample covered by Roam, centred on Position.")                                           \
  X(ROAM_SPEED, "roam.speed", "ROAM", "Speed", "Hz", 0.005, 2.0, 0.1, Knob, Log, nullptr,                   \
    "Roam speed in cycles per second.")                                                                      \
  X(ROAM_SMOOTH, "roam.smooth", "ROAM", "Smooth", "", 0, 1, 0.5, Knob, Linear, nullptr,                     \
    "Slews the roaming position so it glides instead of stepping.")                                          \
  X(ROAM_WANDER, "roam.wander", "ROAM", "Wander", "", 0, 1, 0, Knob, Linear, nullptr,                       \
    "Adds a slow random drift on top of the Roam movement.")                                                 \
  /* ---- smoothing ---- */                                                                                  \
  X(SMOOTH_PARAM_MS, "smooth.param_ms", "SMOOTH", "Params", "ms", 1, 1000, 50, Knob, Log, nullptr,          \
    "Smoothing time applied to every knob movement.")                                                        \
  X(SMOOTH_XFADE_MS, "smooth.xfade_ms", "SMOOTH", "Xfade", "ms", 2, 1000, 100, Knob, Log, nullptr,         \
    "Minimum fade-in/out time of a grain (prevents clicks on short grains).")                                \
  X(SMOOTH_OVERLAP, "smooth.overlap", "SMOOTH", "Overlap", "", 0, 1, 0.5, Knob, Linear, nullptr,            \
    "Grain window shape. 0 = nearly rectangular, 1 = fully rounded (Hann).")                                 \
  X(SMOOTH_TAIL_MS, "smooth.tail_ms", "SMOOTH", "Tail", "ms", 5, 5000, 100, Knob, Log, nullptr,             \
    "Fade time of the source when Play is toggled. Reverb and delay tails ring on.")                         \
  X(SMOOTH_DELAY_MS, "smooth.delay_ms", "SMOOTH", "Delay glide", "ms", 1, 2000, 140, Knob, Log, nullptr,    \
    "Glide time when the Delay time changes (gives tape-like pitch sweeps).")                                \
  /* ---- tape ---- */                                                                                       \
  X(TAPE_ENABLED, "tape.enabled", "TAPE", "Tape", "", 0, 1, 1, Toggle, Linear, nullptr,                     \
    "Turns the tape emulation on or off.")                                                                   \
  X(TAPE_WOW, "tape.wow", "TAPE", "Wow", "", 0, 1, 0.2, Knob, Linear, nullptr,                              \
    "Slow tape speed drift (about 0.5 Hz pitch wobble).")                                                    \
  X(TAPE_FLUTTER, "tape.flutter", "TAPE", "Flutter", "", 0, 1, 0.15, Knob, Linear, nullptr,                 \
    "Fast tape speed flutter (about 8 Hz).")                                                                 \
  X(TAPE_HISS, "tape.hiss", "TAPE", "Hiss", "", 0, 1, 0.03, Knob, Linear, nullptr,                          \
    "Tape noise floor.")                                                                                     \
  X(TAPE_SATURATION, "tape.saturation", "TAPE", "Saturate", "", 0, 1, 0.2, Knob, Linear, nullptr,           \
    "Soft tape compression/saturation with high-frequency roll-off.")                                        \
  X(TAPE_CRINKLE, "tape.crinkle", "TAPE", "Crinkle", "", 0, 1, 0, Knob, Linear, nullptr,                    \
    "Random crackle and dust, like a worn cassette.")                                                        \
  X(TAPE_DROPOUT, "tape.dropout", "TAPE", "Dropout", "", 0, 1, 0, Knob, Linear, nullptr,                    \
    "Random short level dips, like oxide dropouts.")                                                         \
  X(TAPE_BIT8, "tape.bit8", "TAPE", "8-bit", "", 0, 1, 0, Knob, Linear, nullptr,                            \
    "Bit-depth reduction toward 8-bit.")                                                                     \
  /* ---- compressor ---- */                                                                                 \
  X(COMP_ENABLED, "comp.enabled", "COMP", "Comp", "", 0, 1, 1, Toggle, Linear, nullptr,                     \
    "Turns the compressor on or off.")                                                                       \
  X(COMP_REDUCTION, "comp.reduction", "COMP", "Reduction", "%", 0, 100, 40, Knob, Linear, nullptr,           \
    "Amount of compression (lowers the threshold and raises the ratio together).")                           \
  X(COMP_ATTACK, "comp.attack", "COMP", "Attack", "ms", 0.1, 200, 10, Knob, Log, nullptr,                   \
    "How fast the compressor reacts to louder sound.")                                                       \
  X(COMP_RELEASE, "comp.release", "COMP", "Release", "ms", 10, 2000, 350, Knob, Log, nullptr,               \
    "How fast the gain recovers.")                                                                           \
  X(COMP_GAIN, "comp.gain", "COMP", "Makeup", "dB", -12, 24, 2, Knob, Linear, nullptr,                      \
    "Make-up gain after compression.")                                                                       \
  X(COMP_MIX, "comp.mix", "COMP", "Mix", "", 0, 1, 1, Knob, Linear, nullptr,                                \
    "Dry/compressed blend (parallel compression).")                                                          \
  /* ---- eq ---- */                                                                                         \
  X(EQ_LOW, "eq.low", "EQ", "Low", "dB", -15, 15, 0, Knob, Linear, nullptr,                                 \
    "Low shelf at 90 Hz.")                                                                                   \
  X(EQ_LMID, "eq.lmid", "EQ", "Low-mid", "dB", -15, 15, 0, Knob, Linear, nullptr,                           \
    "Peaking band at 250 Hz.")                                                                               \
  X(EQ_MID, "eq.mid", "EQ", "Mid", "dB", -15, 15, 0, Knob, Linear, nullptr,                                 \
    "Peaking band at 1 kHz.")                                                                                \
  X(EQ_HMID, "eq.hmid", "EQ", "High-mid", "dB", -15, 15, 0, Knob, Linear, nullptr,                          \
    "Peaking band at 3.5 kHz.")                                                                              \
  X(EQ_HIGH, "eq.high", "EQ", "High", "dB", -15, 15, 0, Knob, Linear, nullptr,                              \
    "High shelf at 8 kHz.")                                                                                  \
  X(EQ_AIR, "eq.air", "EQ", "Air", "dB", -15, 15, 0, Knob, Linear, nullptr,                                 \
    "High shelf at 14 kHz.")                                                                                 \
  /* ---- delay ---- */                                                                                      \
  X(DELAY_TIME, "delay.time", "DELAY", "Time", "ms", 1, 2000, 500, Knob, Log, nullptr,                      \
    "Delay time.")                                                                                           \
  X(DELAY_FEEDBACK, "delay.feedback", "DELAY", "Feedback", "", 0, 0.95, 0.4, Knob, Linear, nullptr,         \
    "How much of the echo is fed back.")                                                                     \
  X(DELAY_LOWPASS, "delay.lowpass", "DELAY", "Lowpass", "Hz", 200, 20000, 6000, Knob, Log, nullptr,         \
    "Darkens each repeat. Lower values give dubbier echoes.")                                                \
  X(DELAY_MIX, "delay.mix", "DELAY", "Mix", "", 0, 1, 0.25, Knob, Linear, nullptr,                          \
    "Level of the echoes added to the dry signal.")                                                          \
  X(DELAY_PINGPONG, "delay.pingpong", "DELAY", "Ping-pong", "", 0, 1, 0.5, Knob, Linear, nullptr,           \
    "0 = two independent delays, 1 = echoes bounce between left and right.")                                 \
  X(DELAY_SPREAD, "delay.spread", "DELAY", "Spread", "", 0, 1, 0.5, Knob, Linear, nullptr,                  \
    "Makes the right delay time up to 12 percent longer than the left.")                                     \
  /* ---- reverb ---- */                                                                                     \
  X(REVERB_SIZE, "reverb.size", "REVERB", "Size", "", 0, 1, 0.6, Knob, Linear, nullptr,                     \
    "Room size (scales the internal delay lengths).")                                                        \
  X(REVERB_DECAY, "reverb.decay", "REVERB", "Decay", "s", 0.2, 30, 4, Knob, Log, nullptr,                   \
    "Reverb time (RT60) in seconds.")                                                                        \
  X(REVERB_DAMP, "reverb.damp", "REVERB", "Damping", "Hz", 500, 20000, 12000, Knob, Log, nullptr,           \
    "High-frequency damping inside the reverb loop.")                                                        \
  X(REVERB_DIFFUSE, "reverb.diffuse", "REVERB", "Diffuse", "", 0, 1, 0.7, Knob, Linear, nullptr,            \
    "Input diffusion: smears transients.")                                                                   \
  X(REVERB_MIX, "reverb.mix", "REVERB", "Mix", "", 0, 1, 0.35, Knob, Linear, nullptr,                       \
    "Dry/wet balance of the reverb.")                                                                        \
  X(REVERB_MOD, "reverb.mod", "REVERB", "Mod", "", 0, 1, 0.6, Knob, Linear, nullptr,                        \
    "Modulation depth of the reverb delay lines (lush, chorused tails).")                                    \
  X(REVERB_MOTION, "reverb.motion", "REVERB", "Motion", "", 0, 1, 0.6, Knob, Linear, nullptr,               \
    "Modulation rate of the reverb.")                                                                        \
  X(REVERB_PREDELAY, "reverb.predelay", "REVERB", "Pre-delay", "ms", 0, 500, 20, Knob, Linear, nullptr,     \
    "Delay before the reverb starts.")                                                                       \
  X(REVERB_WIDTH, "reverb.width", "REVERB", "Width", "", 0, 1, 1, Knob, Linear, nullptr,                    \
    "Stereo width of the reverb.")                                                                           \
  /* ---- shimmer ---- */                                                                                    \
  X(SHIMMER_MIX, "shimmer.mix", "SHIMMER", "Mix", "", 0, 1, 0.25, Knob, Linear, nullptr,                    \
    "Level of the shimmering pitched reverb added to the signal.")                                           \
  X(SHIMMER_FEEDBACK, "shimmer.feedback", "SHIMMER", "Feedback", "", 0, 0.95, 0.5, Knob, Linear, nullptr,   \
    "Amount of pitch-shifted sound fed back into the shimmer reverb. More = longer rising tails.")           \
  X(SHIMMER_SHIFT, "shimmer.shift", "SHIMMER", "Shift", "st", -12, 24, 12, Knob, Linear, nullptr,           \
    "Pitch shift of the feedback in semitones (12 = octave up, 19 = octave + fifth).")                       \
  X(SHIMMER_DUAL, "shimmer.dual", "SHIMMER", "Dual", "", 0, 1, 0, Toggle, Linear, nullptr,                  \
    "Adds a second voice that shifts the opposite way (up and down together), for a fuller, choir-like texture.")                                                      \
  X(SHIMMER_VOICE2, "shimmer.voice2_level", "SHIMMER", "Voice 2", "", 0, 1, 0.5, Knob, Linear, nullptr,     \
    "Level of the second voice when Dual is on.")                                                            \
  X(SHIMMER_TONE, "shimmer.tone", "SHIMMER", "Tone", "Hz", 500, 20000, 5000, Knob, Log, nullptr,            \
    "Brightness of the shimmer. Every pass adds a shift, so the highs pile up: lower = warmer, softer.")   \
  X(SHIMMER_SPREAD, "shimmer.spread", "SHIMMER", "Spread", "", 0, 1, 0.6, Knob, Linear, nullptr,            \
    "Stereo spread of the shimmer voices.")                                                                  \
  X(SHIMMER_SMOOTH, "shimmer.smooth", "SHIMMER", "Smooth", "", 0, 1, 0.5, Knob, Linear, nullptr,            \
    "Pitch-shifter splice length. Higher = smoother and more diffuse, lower = tighter.")                      \
  X(SHIMMER_SIZE, "shimmer.size", "SHIMMER", "Size", "", 0, 1, 0.5, Knob, Linear, nullptr,                    \
    "Size of the shimmer's own reverb. Small = quick, tight repeats; big = slow bloom and a longer tail.")    \
  X(SHIMMER_DIFFUSE, "shimmer.diffuse", "SHIMMER", "Diffusion", "", 0, 1, 0.85, Knob, Linear, nullptr,       \
    "Echo density. Low = the pitched repeats are heard as separate echoes, high = a smooth wash.")           \
  X(SHIMMER_LOWCUT, "shimmer.lowcut", "SHIMMER", "Low cut", "Hz", 20, 1000, 120, Knob, Log, nullptr,         \
    "High-pass in the feedback path. Higher = every repeat gets brighter and thinner.")                      \
  X(SHIMMER_MOD, "shimmer.mod", "SHIMMER", "Mod", "", 0, 1, 0.5, Knob, Linear, nullptr,                      \
    "Depth of the random modulation of the shimmer's reverb. Keep it moderate: the pitch shifting adds its own.") \
  /* ---- orbix ---- */                                                                                      \
  X(ORBIX_ENABLED, "orbix.enabled", "ORBIX", "Orbix", "", 0, 1, 0, Toggle, Linear, nullptr,                 \
    "Turns the ORBIX generative note engine on or off.")                                                     \
  X(ORBIX_VOLUME, "orbix.volume", "ORBIX", "Volume", "%", 0, 100, 60, Knob, Linear, nullptr,                \
    "Output level of the ORBIX notes.")                                                                      \
  X(ORBIX_BALLS, "orbix.balls", "ORBIX", "Balls", "", 1, 16, 4, Choice, Linear,                             \
    "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16",                                                                \
    "Number of bouncing balls. Every wall hit plays a note.")                                                \
  X(ORBIX_SHAPE, "orbix.shape", "ORBIX", "Sides", "", 3, 8, 4, Choice, Linear, "3|4|5|6|7|8",                \
    "Number of sides of the rotating arena.")                                                                \
  X(ORBIX_GRAVITY, "orbix.gravity", "ORBIX", "Gravity", "%", 0, 100, 20, Knob, Linear, nullptr,             \
    "Downward pull on the balls.")                                                                           \
  X(ORBIX_BOUNCE, "orbix.bounce", "ORBIX", "Bounce", "%", 0, 100, 90, Knob, Linear, nullptr,                \
    "Elasticity of the walls. 100 = no energy lost on impact.")                                              \
  X(ORBIX_ROTATION, "orbix.rotation", "ORBIX", "Rotation", "%", 0, 100, 30, Knob, Linear, nullptr,          \
    "Spin speed of the arena. The moving walls keep feeding energy into the balls.")                         \
  X(ORBIX_INSTRUMENT, "orbix.instrument", "ORBIX", "Voice", "", 0, 3, 1, Choice, Linear,                    \
    "Glass|Bell|Pluck|Sample",                                                                               \
    "Glass: soft sine pad. Bell: FM bell. Pluck: plucked string. Sample: pitched slice of your sample.")     \
  X(ORBIX_SCALE, "orbix.scale", "ORBIX", "Scale", "", 0, 9, 0, Choice, Linear,                              \
    "Minor pent.|Major pent.|Major|Minor|Dorian|Lydian|Mixolydian|Phrygian|Whole tone|Hirajoshi",           \
    "Musical scale used for the notes.")                                                                     \
  X(ORBIX_ROOT, "orbix.root", "ORBIX", "Root", "", 0, 11, 0, Choice, Linear,                                \
    "C|C#|D|D#|E|F|F#|G|G#|A|A#|B", "Root note of the scale.")                                              \
  X(ORBIX_OCTAVE, "orbix.octave", "ORBIX", "Octave", "", -3, 3, 0, Choice, Linear,                          \
    "-3|-2|-1|0|+1|+2|+3", "Octave shift of the notes.")                                                     \
  X(ORBIX_ATTACK, "orbix.attack", "ORBIX", "Attack", "ms", 1, 2000, 30, Knob, Log, nullptr,                 \
    "Fade-in time of each note.")                                                                            \
  X(ORBIX_RELEASE, "orbix.release", "ORBIX", "Release", "ms", 1, 4000, 300, Knob, Log, nullptr,             \
    "Fade-out time of each note.")                                                                           \
  X(ORBIX_REVERB, "orbix.reverb", "ORBIX", "Reverb", "%", 0, 100, 60, Knob, Linear, nullptr,                \
    "Extra send of the ORBIX notes into the shimmer and reverb stages.")                                     \
  /* ---- live input ---- */                                                                                 \
  X(LIVE_LEVEL, "live.level", "MIX", "Live in", "", 0, 1, 0, Knob, Linear, nullptr,                       \
    "Mixes the live microphone / USB audio input through the effects. Use headphones to avoid feedback.")

enum ParamId : int {
#define X(E, ...) P_##E,
  GB_PARAMS(X)
#undef X
      P_COUNT
};

struct ParamInfo {
  const char* id;
  const char* group;
  const char* label;
  const char* unit;
  float min;
  float max;
  float def;
  Kind kind;
  Curve curve;
  const char* choices;  // '|' separated labels for Choice params, else nullptr
  const char* help;
};

int paramCount();
const ParamInfo& paramInfo(int index);
int paramIndex(const char* id);  // -1 if unknown

}  // namespace gb
