// GrainBrick Android - ORBIX generative note engine.
//
// Balls bounce around inside a rotating regular polygon. Every wall impact plays a note whose
// pitch depends on the wall and on where along the wall the ball hit; loudness follows the impact
// speed. Rotating walls inject energy so the system keeps moving.
#pragma once

#include "dsp.h"
#include "granular.h"

namespace gb {

struct OrbixCtl {
  bool enabled = false;
  bool spawn = true;     // false => no new notes (running ones ring out)
  float volume = 0.6f;   // 0..1
  float gravity = 0.2f;  // 0..1
  float bounce = 0.9f;   // 0..1
  float rotation = 0.3f; // 0..1
  int balls = 4;
  int shape = 4;
  int instrument = 1;    // 0 glass, 1 bell, 2 pluck, 3 sample
  int scale = 0;
  int root = 0;
  int octave = 0;
  float attackMs = 30.f;
  float releaseMs = 300.f;
  float samplePos = 0.5f;
};

class Orbix {
 public:
  static constexpr int kMaxBalls = 16;
  static constexpr int kMaxVoices = 16;
  static constexpr int kKsMax = 4096;
  // Layout of getState(): [angle, shape, nBalls, then per ball: x, y, flashSeconds]
  static constexpr int kStateSize = 3 + kMaxBalls * 3;

  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    reset();
  }
  void reset() {
    for (auto& v : voices_) v.active = false;
    nBalls_ = 0;
    angle_ = 0.f;
    acc_ = 0.f;
    shape_ = 4;
  }
  void setSample(const SampleData* s) {
    sample_ = s;
    for (auto& v : voices_) if (v.type == 3) v.active = false;
  }

  void process(const OrbixCtl& c, float* outL, float* outR, int n) {
    if (c.enabled && c.spawn) {
      simulate(c, static_cast<float>(n) / sr_);
    }
    for (auto& v : voices_) {
      if (v.active) renderVoice(v, outL, outR, n, c.volume);
    }
  }

  void getState(float* out) const {
    out[0] = angle_;
    out[1] = static_cast<float>(shape_);
    out[2] = static_cast<float>(nBalls_);
    for (int i = 0; i < kMaxBalls; ++i) {
      if (i < nBalls_) {
        out[3 + i * 3] = balls_[i].x;
        out[4 + i * 3] = balls_[i].y;
        out[5 + i * 3] = balls_[i].sinceHit;
      } else {
        out[3 + i * 3] = out[4 + i * 3] = 0.f;
        out[5 + i * 3] = 99.f;
      }
    }
  }
  int activeVoices() const {
    int c = 0;
    for (const auto& v : voices_) c += v.active ? 1 : 0;
    return c;
  }

 private:
  struct Ball {
    float x = 0, y = 0, vx = 0, vy = 0;
    float cooldown = 0.f, sinceHit = 99.f, rest = 0.f;
  };
  struct Voice {
    bool active = false;
    int type = 0;
    float freq = 440.f, amp = 0.f, gL = 1.f, gR = 1.f;
    int age = 0, attackN = 1, gateN = 1, releaseN = 1;
    float ph1 = 0.f, ph2 = 0.f, phm = 0.f;
    // bell: running exponential envelopes (avoids exp() per sample)
    float bIdx = 0.f, bAmp = 0.f, bIdxD = 1.f, bAmpD = 1.f;
    // pluck (Karplus-Strong with allpass tuning)
    float ks[kKsMax];
    int ksLen = 1, ksIdx = 0;
    float ksPrev = 0.f, apC = 0.f, apX = 0.f, apY = 0.f, decay = 0.99f;
    // sample voice
    double pos = 0.0, inc = 1.0;
  };

  static const int* scaleIntervals(int scale, int& len) {
    static const int s0[] = {0, 3, 5, 7, 10};
    static const int s1[] = {0, 2, 4, 7, 9};
    static const int s2[] = {0, 2, 4, 5, 7, 9, 11};
    static const int s3[] = {0, 2, 3, 5, 7, 8, 10};
    static const int s4[] = {0, 2, 3, 5, 7, 9, 10};
    static const int s5[] = {0, 2, 4, 6, 7, 9, 11};
    static const int s6[] = {0, 2, 4, 5, 7, 9, 10};
    static const int s7[] = {0, 1, 3, 5, 7, 8, 10};
    static const int s8[] = {0, 2, 4, 6, 8, 10};
    static const int s9[] = {0, 2, 3, 7, 8};
    switch (scale) {
      default:
      case 0: len = 5; return s0;
      case 1: len = 5; return s1;
      case 2: len = 7; return s2;
      case 3: len = 7; return s3;
      case 4: len = 7; return s4;
      case 5: len = 7; return s5;
      case 6: len = 7; return s6;
      case 7: len = 7; return s7;
      case 8: len = 6; return s8;
      case 9: len = 5; return s9;
    }
  }

  void syncBalls(const OrbixCtl& c) {
    const int want = std::max(1, std::min(kMaxBalls, c.balls));
    while (nBalls_ < want) {
      Ball& b = balls_[nBalls_++];
      float a = rng_.uni() * kTwoPi, r = 0.55f * std::sqrt(rng_.uni());
      b.x = r * std::cos(a);
      b.y = r * std::sin(a);
      float sp = 0.5f + 0.6f * rng_.uni(), d = rng_.uni() * kTwoPi;
      b.vx = sp * std::cos(d);
      b.vy = sp * std::sin(d);
      b.cooldown = 0.f;
      b.sinceHit = 99.f;
      b.rest = 0.f;
    }
    if (nBalls_ > want) nBalls_ = want;
    if (c.shape != shape_) {
      shape_ = std::max(3, std::min(8, c.shape));
      for (int i = 0; i < nBalls_; ++i) {  // pull everyone safely inside the new arena
        balls_[i].x *= 0.6f;
        balls_[i].y *= 0.6f;
      }
    }
  }

  void simulate(const OrbixCtl& c, float dtBlock) {
    syncBalls(c);
    const float omega = c.rotation * 1.6f;
    const float g = c.gravity * 2.5f;
    const float e = 0.6f + 0.4f * c.bounce;
    const float apothem = std::cos(kPi / static_cast<float>(shape_));
    const float halfEdge = apothem * std::tan(kPi / static_cast<float>(shape_));
    const float rb = 0.05f;
    const float dt = 1.0f / 480.0f;

    acc_ += dtBlock;
    int guard = 0;
    while (acc_ >= dt && guard++ < 64) {
      acc_ -= dt;
      angle_ += omega * dt;
      if (angle_ > kTwoPi) angle_ -= kTwoPi;
      for (int bi = 0; bi < nBalls_; ++bi) {
        Ball& b = balls_[bi];
        b.vy -= g * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.cooldown -= dt;
        b.sinceHit += dt;
        for (int ei = 0; ei < shape_; ++ei) {
          float ang = angle_ + kTwoPi * static_cast<float>(ei) / static_cast<float>(shape_);
          float nx = std::cos(ang), ny = std::sin(ang);
          float pen = b.x * nx + b.y * ny + rb - apothem;
          if (pen <= 0.f) continue;
          b.x -= pen * nx;
          b.y -= pen * ny;
          float wvx = -omega * b.y, wvy = omega * b.x;
          float rvx = b.vx - wvx, rvy = b.vy - wvy;
          float vn = rvx * nx + rvy * ny;
          if (vn <= 0.f) continue;
          rvx -= (1.0f + e) * vn * nx;
          rvy -= (1.0f + e) * vn * ny;
          b.vx = rvx + wvx;
          b.vy = rvy + wvy;
          if (vn > 0.06f && b.cooldown <= 0.f) {
            float s = b.x * (-ny) + b.y * nx;
            float u = clampf(0.5f + s / (2.0f * halfEdge), 0.f, 0.999f);
            trigger(c, ei, u, vn, b.x);
            b.cooldown = 0.07f;
            b.sinceHit = 0.f;
          }
        }
        float sp2 = b.vx * b.vx + b.vy * b.vy;
        if (sp2 > 16.f) { b.vx *= 0.5f; b.vy *= 0.5f; }
        // Keep the piece alive: a ball that has come to rest gets a kick.
        if (sp2 < 0.02f) {
          b.rest += dt;
          if (b.rest > 1.0f) {
            float d = rng_.uni() * kTwoPi;
            b.vx = 0.7f * std::cos(d);
            b.vy = 0.7f * std::sin(d) + 0.5f;
            b.rest = 0.f;
          }
        } else {
          b.rest = 0.f;
        }
      }
    }
  }

  void trigger(const OrbixCtl& c, int edge, float u, float vn, float x) {
    int sl = 0;
    const int* iv = scaleIntervals(c.scale, sl);
    int k = (edge * 3 + static_cast<int>(u * 3.0f)) % (sl * 2);
    int semis = iv[k % sl] + 12 * (k / sl);
    float midi = 60.f + static_cast<float>(c.root + 12 * c.octave + semis);
    float freq = clampf(midiToHz(midi), 25.f, 0.45f * sr_);

    Voice* v = nullptr;
    int oldest = 0, oldestAge = -1;
    for (int i = 0; i < kMaxVoices; ++i) {
      if (!voices_[i].active) { v = &voices_[i]; break; }
      if (voices_[i].age > oldestAge) { oldestAge = voices_[i].age; oldest = i; }
    }
    if (!v) v = &voices_[oldest];

    const int type = std::max(0, std::min(3, c.instrument));
    static const float kGate[4] = {0.8f, 2.5f, 3.0f, 0.6f};
    v->active = true;
    v->type = type;
    v->freq = freq;
    v->age = 0;
    v->amp = 0.25f + 0.75f * clampf(vn / 1.5f, 0.f, 1.f);
    v->attackN = std::max(1, static_cast<int>(c.attackMs * 0.001f * sr_));
    v->gateN = v->attackN + static_cast<int>(kGate[type] * sr_);
    v->releaseN = std::max(1, static_cast<int>(c.releaseMs * 0.001f * sr_));
    float pan = clampf(x * 0.8f, -1.f, 1.f);
    float th = (pan + 1.0f) * kPi * 0.25f;
    v->gL = std::cos(th) * 1.41421356f;
    v->gR = std::sin(th) * 1.41421356f;
    v->ph1 = v->ph2 = v->phm = 0.f;
    v->bIdx = 2.5f;
    v->bAmp = 1.f;
    v->bIdxD = std::exp(-1.0f / (0.4f * sr_));
    v->bAmpD = std::exp(-1.0f / (0.9f * sr_));

    if (type == 2) {
      float P = sr_ / freq;
      int L = std::max(2, std::min(kKsMax - 1, static_cast<int>(std::floor(P - 1.0f))));
      float d = P - 0.5f - static_cast<float>(L);
      v->ksLen = L;
      v->ksIdx = 0;
      v->ksPrev = v->apX = v->apY = 0.f;
      v->apC = (1.0f - d) / (1.0f + d);
      v->decay = std::exp(-6.907755f / (3.0f * freq));
      float lp = 0.f, mean = 0.f;
      for (int i = 0; i < L; ++i) {
        lp += 0.45f * (rng_.bi() - lp);
        v->ks[i] = lp;
        mean += lp;
      }
      mean /= static_cast<float>(L);
      for (int i = 0; i < L; ++i) v->ks[i] -= mean;
    } else if (type == 3) {
      float ratio = freq / 261.6256f;
      double srcStep = static_cast<double>(ratio) * (sample_ ? sample_->sampleRate : sr_) / sr_;
      v->inc = srcStep;
      double N = sample_ ? static_cast<double>(sample_->frames) : 1.0;
      double span = srcStep * (kGate[3] + c.releaseMs * 0.001f + 0.1f) * sr_;
      double start = static_cast<double>(c.samplePos) * (N - 1.0);
      v->pos = std::min(std::max(0.0, start), std::max(0.0, N - 2.0 - span));
    }
  }

  void renderVoice(Voice& v, float* outL, float* outR, int n, float volume) {
    const float inv2pi = 1.0f / sr_;
    const float master = volume * 0.35f;
    for (int i = 0; i < n; ++i) {
      float env;
      if (v.age < v.attackN) env = static_cast<float>(v.age) / static_cast<float>(v.attackN);
      else if (v.age < v.gateN) env = 1.f;
      else if (v.age < v.gateN + v.releaseN) {
        float t = 1.0f - static_cast<float>(v.age - v.gateN) / static_cast<float>(v.releaseN);
        env = t * t;
      } else {
        v.active = false;
        return;
      }
      float s = 0.f;
      switch (v.type) {
        case 0: {  // glass pad
          v.ph1 += v.freq * inv2pi;
          v.ph2 += v.freq * 2.004f * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          if (v.ph2 >= 1.f) v.ph2 -= 1.f;
          s = 0.65f * std::sin(kTwoPi * v.ph1) + 0.3f * std::sin(kTwoPi * v.ph2);
          break;
        }
        case 1: {  // FM bell
          v.ph1 += v.freq * inv2pi;
          v.phm += v.freq * 3.5f * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          if (v.phm >= 1.f) v.phm -= 1.f;
          s = std::sin(kTwoPi * v.ph1 + v.bIdx * std::sin(kTwoPi * v.phm)) * v.bAmp;
          v.bIdx *= v.bIdxD;
          v.bAmp *= v.bAmpD;
          break;
        }
        case 2: {  // pluck
          float out = v.ks[v.ksIdx];
          float avg = 0.5f * (out + v.ksPrev);
          v.ksPrev = out;
          float ap = v.apC * (avg - v.apY) + v.apX;
          v.apX = avg;
          v.apY = ap;
          v.ks[v.ksIdx] = ap * v.decay;
          if (++v.ksIdx >= v.ksLen) v.ksIdx = 0;
          s = out * 1.6f;
          break;
        }
        default: {  // sample slice
          if (!sample_ || sample_->frames < 4) { v.active = false; return; }
          int N = sample_->frames;
          int i0 = static_cast<int>(v.pos);
          if (i0 >= N - 2) { v.active = false; return; }
          float f = static_cast<float>(v.pos - static_cast<double>(i0));
          float a = sample_->l[static_cast<size_t>(i0)], b = sample_->l[static_cast<size_t>(i0 + 1)];
          float a2 = sample_->r[static_cast<size_t>(i0)], b2 = sample_->r[static_cast<size_t>(i0 + 1)];
          s = 0.5f * ((a + (b - a) * f) + (a2 + (b2 - a2) * f)) * 1.2f;
          v.pos += v.inc;
          break;
        }
      }
      float o = s * env * v.amp * master;
      outL[i] += o * v.gL;
      outR[i] += o * v.gR;
      ++v.age;
    }
  }

  float sr_ = 48000.f;
  const SampleData* sample_ = nullptr;
  Ball balls_[kMaxBalls];
  int nBalls_ = 0, shape_ = 4;
  float angle_ = 0.f, acc_ = 0.f;
  Voice voices_[kMaxVoices];
  Rng rng_{0x0AB1Cu};
};

}  // namespace gb
