#include "mutable_orbix.h"

// The Mutable code picks ARM assembly for a few DSP helpers unless TEST is defined.
#ifndef TEST
#define TEST 1
#endif

#include <algorithm>
#include <cmath>
#include <cstring>

#include "elements/dsp/part.h"
#include "mutable_pipe.h"

namespace gb {
using mutable_detail::Pipe;
using mutable_detail::smooth;
using mutable_detail::pot;

// ------------------------------------------------------------------------------------------
// ELEMENTS
// ------------------------------------------------------------------------------------------
struct ElementsBank::Impl {
  elements::Part part;
  uint16_t reverb[32768];
  Pipe pipe;
  elements::PerformanceState ps{};
  bool gate = false, hitPending = false;
  float pendingNote = 60.f, pendingStrength = 0.8f;
  int hold = 0;
  float level = 0.f;
  float sr = 48000.f;
};

ElementsBank::ElementsBank(float sampleRate) : impl_(new Impl) {
  std::fill(impl_->reverb, impl_->reverb + 32768, uint16_t{0});
  // The firmware relies on zero-initialised static memory (Voice::Init does not clear the tube delay line).
  std::memset(static_cast<void*>(&impl_->part), 0, sizeof(impl_->part));
  impl_->part.Init(impl_->reverb);
  impl_->part.set_easter_egg(false);
  impl_->sr = sampleRate;
  impl_->pipe.init(elements::kSampleRate, sampleRate);
}
ElementsBank::~ElementsBank() = default;

void ElementsBank::reset() {
  std::fill(impl_->reverb, impl_->reverb + 32768, uint16_t{0});
  // The firmware relies on zero-initialised static memory (Voice::Init does not clear the tube delay line).
  std::memset(static_cast<void*>(&impl_->part), 0, sizeof(impl_->part));
  impl_->part.Init(impl_->reverb);
  impl_->part.set_easter_egg(false);
  impl_->pipe.reset();
  impl_->gate = impl_->hitPending = false;
  impl_->hold = 0;
  impl_->level = 0.f;
}

void ElementsBank::note(const ElementsParams& p, float midi, float strength) {
  (void)p;
  impl_->pendingNote = midi;
  impl_->pendingStrength = strength < 0.f ? 0.f : (strength > 1.f ? 1.f : strength);
  impl_->hitPending = true;
}

bool ElementsBank::sounding() const { return impl_->level > 1e-9f || impl_->gate; }

void ElementsBank::render(const ElementsParams& p, float* l, float* r, int n, float gain) {
  Impl& s = *impl_;
  s.part.set_resonator_model(static_cast<elements::ResonatorModel>(std::max(0, std::min(2, p.model))));
  elements::Patch* patch = s.part.mutable_patch();
  patch->exciter_envelope_shape = pot(p.contour);
  patch->exciter_bow_level = pot(p.bow);
  patch->exciter_bow_timbre = pot(p.bowTimbre);
  patch->exciter_blow_level = pot(p.blow);
  patch->exciter_blow_meta = pot(p.flow);
  patch->exciter_blow_timbre = pot(p.blowTimbre);
  patch->exciter_strike_level = pot(p.strike);
  patch->exciter_strike_meta = pot(p.mallet);
  patch->exciter_strike_timbre = pot(p.strikeTimbre);
  patch->resonator_geometry = pot(p.geometry);
  patch->resonator_brightness = pot(p.brightness);
  patch->resonator_damping = pot(p.damping);
  patch->resonator_position = pot(p.position);
  patch->space = std::max(0.f, std::min(2.f, p.space));
  const int gateBlocks = std::max(1, static_cast<int>(p.gateMs * 0.001f * elements::kSampleRate / static_cast<float>(elements::kMaxBlockSize)));
  s.pipe.pull(l, r, n, elements::kMaxBlockSize, [&](float* outL, float* outR) {
    // Gate logic: a new hit needs a falling edge first, so the envelope restarts.
    if (s.hitPending) {
      if (s.gate) {
        s.gate = false;
      } else {
        s.gate = true;
        s.hold = gateBlocks;
        s.ps.note = s.pendingNote;
        s.ps.strength = s.pendingStrength;
        s.hitPending = false;
      }
    } else if (s.gate && --s.hold <= 0) {
      s.gate = false;
    }
    s.ps.gate = s.gate;
    s.ps.modulation = 0.f;
    float silence[elements::kMaxBlockSize] = {0};
    float m[elements::kMaxBlockSize], a[elements::kMaxBlockSize];
    s.part.Process(s.ps, silence, silence, m, a, elements::kMaxBlockSize);
    float e = 0.f;
    for (size_t i = 0; i < elements::kMaxBlockSize; ++i) {
      if (!std::isfinite(m[i]) || !std::isfinite(a[i])) { m[i] = a[i] = 0.f; }
      outL[i] = std::tanh(m[i] * gain);
      outR[i] = std::tanh(a[i] * gain);
      e += m[i] * m[i] + a[i] * a[i];
    }
    s.level += 0.05f * (e / static_cast<float>(elements::kMaxBlockSize) - s.level);
  });
}

}  // namespace gb
