// GrainBrick Android - 8-line feedback delay network reverb and the shimmer built on top of it.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

#include "dsp.h"
#include "params.h"
#include "st_bridge.h"

namespace gb {

// ---------------------------------------------------------------------------------------------
// FDN reverb: stereo predelay -> allpass diffusion -> 8 modulated delay lines with a Hadamard
// feedback matrix, per-line decay gain and damping filters. Output is wet only.
// ---------------------------------------------------------------------------------------------
class Reverb {
 public:
  static constexpr int N = 8;

  void prepare(double sampleRate, float maxPredelaySec = 0.5f) {
    sr_ = static_cast<float>(sampleRate);
    const float scale = sr_ / 48000.f;
    static const int kBase[N] = {1087, 1283, 1481, 1699, 1951, 2203, 2447, 2711};
    for (int i = 0; i < N; ++i) {
      baseLen_[i] = static_cast<float>(kBase[i]) * scale;
      lines_[i].init(static_cast<int>(baseLen_[i] * 2.1f) + 64);
      rate_[i] = 0.6f + 0.8f * static_cast<float>((i * 5) % N) / static_cast<float>(N - 1);
      phase_[i] = static_cast<float>(i) / static_cast<float>(N);
    }
    pdL_.init(static_cast<int>(maxPredelaySec * sr_) + 8);
    pdR_.init(static_cast<int>(maxPredelaySec * sr_) + 8);
    static const int kAp[4] = {142, 107, 379, 277};
    for (int i = 0; i < 2; ++i) {
      apL_[i].init(static_cast<int>(static_cast<float>(kAp[i]) * scale) + 1);
      apR_[i].init(static_cast<int>(static_cast<float>(kAp[i + 2]) * scale) + 1);
    }
    reset();
    setParams(0.6f, 4.f, 12000.f, 0.7f, 0.3f, 0.3f, 20.f, 1.f);
  }

  void reset() {
    for (int i = 0; i < N; ++i) { lines_[i].clear(); lp_[i].reset(); hp_[i].reset(); }
    pdL_.clear(); pdR_.clear();
    for (int i = 0; i < 2; ++i) { apL_[i].clear(); apR_[i].clear(); }
  }

  // Cheap enough to call once per sub-block.
  void setParams(float size, float decaySec, float dampHz, float diffuse, float mod, float motion,
                 float predelayMs, float width) {
    const float sizeFactor = 0.4f + 1.6f * clampf(size, 0.f, 1.f);
    decaySec = std::max(0.05f, decaySec);
    float gsq = 0.f;
    for (int i = 0; i < N; ++i) {
      len_[i] = baseLen_[i] * sizeFactor;
      gain_[i] = std::exp(-6.907755f * len_[i] / (sr_ * decaySec));
      gsq += gain_[i] * gain_[i];
    }
    gsq /= static_cast<float>(N);
    // Normalise so a sustained input produces a roughly constant output level for any decay.
    wetNorm_ = std::sqrt(std::max(1e-4f, 1.0f - gsq)) * 1.15f;
    dampA_ = lowpassCoef(dampHz, sr_);
    apG_ = 0.65f * clampf(diffuse, 0.f, 1.f);
    modDepth_ = clampf(mod, 0.f, 1.f) * 12.0f * sr_ / 48000.f;
    const float f = 0.05f + 1.2f * clampf(motion, 0.f, 1.f);
    for (int i = 0; i < N; ++i) phaseInc_[i] = f * rate_[i] / sr_;
    preSamples_ = clampf(predelayMs * 0.001f * sr_, 0.f, static_cast<float>(pdL_.capacity() - 8));
    width_ = clampf(width, 0.f, 1.f);
  }

  inline void process(float inL, float inR, float& wetL, float& wetR) {
    pdL_.write(inL);
    pdR_.write(inR);
    float pl = pdL_.read(preSamples_), pr = pdR_.read(preSamples_);
    if (apG_ > 0.f) {
      for (int s = 0; s < 2; ++s) {
        pl = apL_[s].process(pl, apG_);
        pr = apR_[s].process(pr, apG_);
      }
    }

    float y[N], v[N];
    for (int i = 0; i < N; ++i) {
      phase_[i] += phaseInc_[i];
      if (phase_[i] >= 1.f) phase_[i] -= 1.f;
      float d = len_[i] + modDepth_ * fastSinTurns(phase_[i]);
      float s = lines_[i].read(d) * gain_[i];
      s = lp_[i].lp(s, dampA_);
      s = hp_[i].hp(s, 0.0003f * 48000.f / sr_);  // DC / sub blocker
      y[i] = s;
      v[i] = s;
    }
    // Hadamard mixing (orthogonal => lossless).
    for (int h = 1; h < N; h <<= 1) {
      for (int i = 0; i < N; i += h << 1) {
        for (int j = i; j < i + h; ++j) {
          float a = v[j], b = v[j + h];
          v[j] = a + b;
          v[j + h] = a - b;
        }
      }
    }
    const float k = 0.35355339f;  // 1/sqrt(8)
    for (int i = 0; i < N; ++i) {
      float inj = ((i & 1) ? pr : pl) * 0.5f;
      lines_[i].write(v[i] * k + inj);
    }
    // Decorrelated stereo taps.
    float l = (y[0] + y[1] - y[2] - y[3] + y[4] + y[5] - y[6] - y[7]) * k;
    float r = (y[0] - y[1] + y[2] - y[3] + y[4] - y[5] + y[6] - y[7]) * k;
    float m = 0.5f * (l + r), sd = 0.5f * (l - r) * width_;
    wetL = (m + sd) * wetNorm_;
    wetR = (m - sd) * wetNorm_;
  }

 private:
  float sr_ = 48000.f;
  float baseLen_[N], len_[N], gain_[N], rate_[N], phase_[N], phaseInc_[N];
  DelayLine lines_[N];
  OnePole lp_[N], hp_[N];
  DelayLine pdL_, pdR_;
  Allpass apL_[2], apR_[2];
  float dampA_ = 0.5f, apG_ = 0.4f, modDepth_ = 0.f, preSamples_ = 0.f, width_ = 1.f, wetNorm_ = 1.f;
};

// ---------------------------------------------------------------------------------------------
// One SoundTouch pitch-shift voice (stereo). SoundTouch (WSOLA time-domain stretching followed by
// sinc resampling) keeps tonal material phase-coherent, so the shifted copy is a clean tone with a
// little warble instead of the AM / comb-filter "ring" of a plain crossfading delay-line shifter.
//
// SoundTouch delivers its output in bursts (one analysis sequence at a time) and with a latency of
// roughly 80-150 ms. A small ring buffer turns that into a steady stream of fixed-size blocks; the
// shimmer feeds the result back into a reverb, where this delay is simply part of its "bloom".
// Everything that allocates (SoundTouch's internal FIFOs) happens in prepare().
// ---------------------------------------------------------------------------------------------
class StShifter {
 public:
  static constexpr int kMaxBlock = 256;
  static constexpr int kRing = 1 << 15;

  StShifter() = default;
  StShifter(const StShifter&) = delete;
  StShifter& operator=(const StShifter&) = delete;
  ~StShifter() { gbst_destroy(h_); }

  bool ok() const { return h_ != nullptr; }

  bool prepare(double sampleRate) {
    gbst_destroy(h_);
    h_ = gbst_create(static_cast<unsigned>(sampleRate), 2);
    sr_ = static_cast<float>(sampleRate);
    ringL_.assign(kRing, 0.f);
    ringR_.assign(kRing, 0.f);
    inter_.assign(static_cast<size_t>(kMaxBlock) * 2, 0.f);
    outBuf_.assign(static_cast<size_t>(kChunk) * 2, 0.f);
    if (!h_) return false;
    gbst_set_setting(h_, GBST_SETTING_USE_AA_FILTER, 1);
    gbst_set_setting(h_, GBST_SETTING_AA_FILTER_LENGTH, 64);
    gbst_set_setting(h_, GBST_SETTING_USE_QUICKSEEK, 1);  // ~2.5x cheaper, no audible difference here

    // Warm-up: run the longest sequences at the extreme pitches once so every internal buffer
    // reaches its final size here, not on the audio thread.
    applySmooth(1.0f);
    Rng rng(0xC0FFEEu);
    for (float st : {-12.5f, 0.f, 12.f, 24.5f}) {
      gbst_set_pitch_semitones(h_, st);
      for (int b = 0; b < static_cast<int>(sr_ / 64.f) + 8; ++b) {
        for (int i = 0; i < 64 * 2; ++i) inter_[static_cast<size_t>(i)] = rng.bi() * 0.1f;
        gbst_put(h_, inter_.data(), 64);
        drain();
      }
    }
    gbst_clear(h_);
    smoothQ_ = -1;
    primeFrames_ = 0;
    applySmooth(0.5f);
    setPitch(12.f);
    reset();
    return true;
  }

  void reset() {
    gbst_clear(h_);
    std::fill(ringL_.begin(), ringL_.end(), 0.f);
    std::fill(ringR_.begin(), ringR_.end(), 0.f);
    rd_ = wr_ = 0;
    started_ = false;
  }

  // Semitones; cheap, may be called every block.
  void setPitch(float st) {
    st = clampf(st, -12.f, 24.f);
    if (std::fabs(st - pitch_) < 1e-4f) return;
    pitch_ = st;
    gbst_set_pitch_semitones(h_, st);
    noteBurst();
  }

  // 0..1: longer sequences and overlaps = fewer, smoother splices (but more latency).
  void setSmooth(float s) {
    const int q = static_cast<int>(std::lround(clampf(s, 0.f, 1.f) * 8.f));
    if (q == smoothQ_) return;
    applySmooth(static_cast<float>(q) / 8.f);
    smoothQ_ = q;
    noteBurst();
  }

  // Latency of the whole voice in frames (SoundTouch + the ring reserve).
  int latencyFrames() const {
    return h_ ? gbst_get_setting(h_, GBST_SETTING_INITIAL_LATENCY) + primeFrames_ : 0;
  }

  // Feed n frames, get n frames of (older) shifted audio back. Silence until the reserve is built.
  void process(const float* inL, const float* inR, float* outL, float* outR, int n) {
    if (!h_ || n <= 0 || n > kMaxBlock) {
      std::memset(outL, 0, sizeof(float) * static_cast<size_t>(n > 0 ? n : 0));
      std::memset(outR, 0, sizeof(float) * static_cast<size_t>(n > 0 ? n : 0));
      return;
    }
    for (int i = 0; i < n; ++i) {
      inter_[static_cast<size_t>(2 * i)] = inL[i];
      inter_[static_cast<size_t>(2 * i + 1)] = inR[i];
    }
    gbst_put(h_, inter_.data(), static_cast<unsigned>(n));
    drain();

    const uint32_t have = wr_ - rd_;
    if (!started_ && have >= static_cast<uint32_t>(primeFrames_)) started_ = true;
    for (int i = 0; i < n; ++i) {
      if (started_ && wr_ != rd_) {
        outL[i] = ringL_[rd_ & (kRing - 1)];
        outR[i] = ringR_[rd_ & (kRing - 1)];
        ++rd_;
      } else {
        outL[i] = outR[i] = 0.f;
      }
    }
  }

 private:
  static constexpr int kChunk = 512;

  void drain() {
    unsigned got;
    while ((got = gbst_receive(h_, outBuf_.data(), kChunk)) > 0) {
      for (unsigned i = 0; i < got; ++i) {
        if (wr_ - rd_ >= static_cast<uint32_t>(kRing)) ++rd_;  // never happens in practice
        ringL_[wr_ & (kRing - 1)] = outBuf_[2 * i];
        ringR_[wr_ & (kRing - 1)] = outBuf_[2 * i + 1];
        ++wr_;
      }
    }
  }

  void applySmooth(float s) {
    gbst_set_setting(h_, GBST_SETTING_SEQUENCE_MS, static_cast<int>(60.f + 60.f * s));
    gbst_set_setting(h_, GBST_SETTING_SEEKWINDOW_MS, static_cast<int>(20.f + 10.f * s));
    gbst_set_setting(h_, GBST_SETTING_OVERLAP_MS, static_cast<int>(10.f + 14.f * s));
  }

  // The reserve must cover the largest burst SoundTouch can emit; it only ever grows.
  void noteBurst() {
    const int burst = gbst_get_setting(h_, GBST_SETTING_NOMINAL_OUTPUT_SEQUENCE);
    const int want = static_cast<int>(static_cast<float>(burst > 0 ? burst : 0) * 1.25f) + 2 * kMaxBlock;
    if (want > primeFrames_) primeFrames_ = std::min(want, kRing / 2);
  }

  void* h_ = nullptr;
  float sr_ = 48000.f, pitch_ = -100.f;
  int smoothQ_ = -1, primeFrames_ = 0;
  std::vector<float> ringL_, ringR_, inter_, outBuf_;
  uint32_t rd_ = 0, wr_ = 0;
  bool started_ = false;
};

// ---------------------------------------------------------------------------------------------
// Shimmer: a long reverb whose output is pitch shifted and fed back into its own input.
//
// What keeps it musical (the first version was metallic and shrill):
//  * clean WSOLA/sinc pitch shifting instead of a two-tap delay-line shifter (StShifter);
//  * a 12 dB/oct low-pass in the loop whose corner never goes above ~7 kHz, whatever the Tone knob
//    says: every pass through the loop moves the spectrum up by the shift, so without a steep,
//    always-on roll-off the upper octaves pile up into hiss and ring;
//  * a high-pass so that no mud builds up, a soft saturator so a high Feedback can swell but never
//    run away, and the loop gain is kept below unity.
// ---------------------------------------------------------------------------------------------
class Shimmer {
 public:
  static constexpr int kMaxBlock = StShifter::kMaxBlock;

  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    rev_.prepare(sampleRate, 0.05f);
    for (auto& v : voice_) v.prepare(sampleRate);
    reset();
  }

  void reset() {
    rev_.reset();
    for (auto& v : voice_) v.reset();
    for (int i = 0; i < kMaxBlock; ++i) fb_[0][0][i] = fb_[0][1][i] = fb_[1][0][i] = fb_[1][1][i] = 0.f;
    for (int c = 0; c < 2; ++c) { lp_[c].reset(); hp_[c].reset(); }
  }

  void setParams(const float* P) {
    gain_ = P[P_SHIMMER_FEEDBACK] * 0.9f;
    dual_ = P[P_SHIMMER_DUAL] > 0.5f;
    v2_ = dual_ ? P[P_SHIMMER_VOICE2] : 0.f;
    spread_ = 0.4f + 1.2f * P[P_SHIMMER_SPREAD];
    // Tone 500 Hz..20 kHz maps to a loop corner of 500 Hz..7 kHz (log-to-log).
    const float t = clampf(std::log(P[P_SHIMMER_TONE] / 500.f) / std::log(40.f), 0.f, 1.f);
    const float fc = 500.f * std::exp(t * std::log(14.f));
    for (int c = 0; c < 2; ++c) {
      lp_[c].setLowpass(sr_, fc, 0.62f);
      hp_[c].setHighpass(sr_, 140.f, 0.62f);
    }
    const float shift = P[P_SHIMMER_SHIFT];
    voice_[0].setPitch(shift);
    voice_[1].setPitch(clampf(shift - 7.f, -12.f, 24.f));
    for (auto& v : voice_) v.setSmooth(P[P_SHIMMER_SMOOTH]);
    // Strong delay-line modulation: it smears the reverb's modes, which is what stops a long tail
    // from ringing metallically on sustained, pitched material (measured: spread of the magnitude
    // response around its trend 8.7 dB -> 6.0 dB, 5.6 dB being a perfectly diffuse field).
    rev_.setParams(0.85f, 6.0f, clampf(fc * 1.4f, 1500.f, 9000.f), 0.85f, 1.0f, 0.8f, 0.f, 1.f);
  }

  // Wet output only. Works on any n; internally in chunks of kMaxBlock.
  void processBlock(const float* inL, const float* inR, float* wetL, float* wetR, int n) {
    for (int off = 0; off < n; off += kMaxBlock) {
      chunk(inL + off, inR + off, wetL + off, wetR + off, std::min(kMaxBlock, n - off));
    }
  }

 private:
  void chunk(const float* inL, const float* inR, float* wetL, float* wetR, int n) {
    const float k2 = 1.0f / (1.0f + v2_);
    for (int i = 0; i < n; ++i) {
      float fl = (fb_[0][0][i] + v2_ * fb_[1][0][i]) * k2;
      float fr = (fb_[0][1][i] + v2_ * fb_[1][1][i]) * k2;
      const float m = 0.5f * (fl + fr), s = 0.5f * (fl - fr) * spread_;
      fl = hp_[0].process(lp_[0].process(m + s)) * gain_;
      fr = hp_[1].process(lp_[1].process(m - s)) * gain_;
      fl = softClip(fl);
      fr = softClip(fr);
      rev_.process(inL[i] + fl, inR[i] + fr, wetL[i], wetR[i]);
    }
    // A NaN/inf anywhere in the recursive loop would never wash out: start over instead.
    if (!std::isfinite(wetL[n - 1] + wetR[n - 1])) {
      reset();
      for (int i = 0; i < n; ++i) wetL[i] = wetR[i] = 0.f;
      return;
    }
    // Next block's feedback: the shifters return what went in some 100+ ms ago.
    voice_[0].process(wetL, wetR, fb_[0][0], fb_[0][1], n);
    if (dual_) {
      voice_[1].process(wetL, wetR, fb_[1][0], fb_[1][1], n);
    } else {
      for (int i = 0; i < n; ++i) fb_[1][0][i] = fb_[1][1][i] = 0.f;
    }
    for (int i = n; i < kMaxBlock; ++i) fb_[0][0][i] = fb_[0][1][i] = fb_[1][0][i] = fb_[1][1][i] = 0.f;
  }

  static inline float softClip(float x) { return x / std::sqrt(1.0f + x * x); }

  float sr_ = 48000.f, gain_ = 0.45f, v2_ = 0.f, spread_ = 1.f;
  bool dual_ = false;
  Reverb rev_;
  StShifter voice_[2];
  Biquad lp_[2], hp_[2];
  float fb_[2][2][kMaxBlock] = {};  // [voice][channel][frame]
};

}  // namespace gb
