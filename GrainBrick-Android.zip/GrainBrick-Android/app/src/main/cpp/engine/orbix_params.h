// Maps the flat parameter array onto the ORBIX control block. Shared by the engine and the host tools.
#pragma once

#include <cmath>

#include "orbix.h"
#include "params.h"

namespace gb {

inline OrbixCtl orbixCtlFromParams(const float* P) {
  auto ri = [](float v) { return static_cast<int>(std::lround(v)); };
  OrbixCtl oc;
  oc.enabled = P[P_ORBIX_ENABLED] > 0.5f;
  oc.volume = P[P_ORBIX_VOLUME] * 0.01f;
  oc.gravity = P[P_ORBIX_GRAVITY] * 0.01f;
  oc.bounce = P[P_ORBIX_BOUNCE] * 0.01f;
  oc.rotation = P[P_ORBIX_ROTATION] * 0.01f;
  oc.balls = ri(P[P_ORBIX_BALLS]);
  oc.shape = ri(P[P_ORBIX_SHAPE]);
  oc.instrument = ri(P[P_ORBIX_INSTRUMENT]);
  oc.scale = ri(P[P_ORBIX_SCALE]);
  oc.root = ri(P[P_ORBIX_ROOT]);
  oc.octave = ri(P[P_ORBIX_OCTAVE]);
  oc.attackMs = P[P_ORBIX_ATTACK];
  oc.releaseMs = P[P_ORBIX_RELEASE];
  oc.fmRatio = ri(P[P_ORBIX_FM_RATIO]);
  oc.fmIndex = P[P_ORBIX_FM_INDEX] * 0.01f;
  oc.fmDecayMs = P[P_ORBIX_FM_DECAY];
  oc.fmFeedback = P[P_ORBIX_FM_FB] * 0.01f;
  oc.pswShape = P[P_ORBIX_PSW_SHAPE] * 0.01f;
  oc.pswWidth = P[P_ORBIX_PSW_WIDTH] * 0.01f;
  oc.pswDetuneCents = P[P_ORBIX_PSW_DETUNE];
  oc.pswCutoff = P[P_ORBIX_PSW_CUTOFF];
  oc.pswRes = P[P_ORBIX_PSW_RES] * 0.01f;
  oc.pswEnv = P[P_ORBIX_PSW_ENV] * 0.01f;
  oc.mExciter = P[P_ORBIX_M_EXCITER] * 0.01f;
  oc.mHardness = P[P_ORBIX_M_HARDNESS] * 0.01f;
  oc.mGeometry = P[P_ORBIX_M_GEOMETRY] * 0.01f;
  oc.mBright = P[P_ORBIX_M_BRIGHT] * 0.01f;
  oc.mDamp = P[P_ORBIX_M_DAMP] * 0.01f;
  oc.mPos = P[P_ORBIX_M_POS] * 0.01f;
  return oc;
}

/// The RINGS ORBIX: the same note engine, always playing the Rings resonator (instrument 9).
inline OrbixCtl ringsCtlFromParams(const float* P) {
  auto ri = [](float v) { return static_cast<int>(std::lround(v)); };
  OrbixCtl oc;
  oc.enabled = P[P_RINGS_ENABLED] > 0.5f;
  oc.volume = P[P_RINGS_VOLUME] * 0.01f;
  oc.gravity = P[P_RINGS_GRAVITY] * 0.01f;
  oc.bounce = P[P_RINGS_BOUNCE] * 0.01f;
  oc.rotation = P[P_RINGS_ROTATION] * 0.01f;
  oc.balls = ri(P[P_RINGS_BALLS]);
  oc.shape = ri(P[P_RINGS_SHAPE]);
  oc.scale = ri(P[P_RINGS_SCALE]);
  oc.root = ri(P[P_RINGS_ROOT]);
  oc.octave = ri(P[P_RINGS_OCTAVE]);
  oc.instrument = 9;
  oc.rings.model = std::max(0, std::min(5, ri(P[P_RINGS_MODEL])));
  oc.rings.polyphony = 1 << std::max(0, std::min(2, ri(P[P_RINGS_POLY])));
  oc.rings.chord = std::max(0, std::min(10, ri(P[P_RINGS_CHORD])));
  oc.rings.structure = P[P_RINGS_STRUCTURE] * 0.01f;
  oc.rings.brightness = P[P_RINGS_BRIGHT] * 0.01f;
  oc.rings.damping = P[P_RINGS_DAMPING] * 0.01f;
  oc.rings.position = P[P_RINGS_POS] * 0.01f;
  return oc;
}

/// The ELEMENTS ORBIX: the same note engine, always playing the Elements voice (instrument 10).
inline OrbixCtl elementsCtlFromParams(const float* P) {
  auto ri = [](float v) { return static_cast<int>(std::lround(v)); };
  OrbixCtl oc;
  oc.enabled = P[P_ELEMENTS_ENABLED] > 0.5f;
  oc.volume = P[P_ELEMENTS_VOLUME] * 0.01f;
  oc.gravity = P[P_ELEMENTS_GRAVITY] * 0.01f;
  oc.bounce = P[P_ELEMENTS_BOUNCE] * 0.01f;
  oc.rotation = P[P_ELEMENTS_ROTATION] * 0.01f;
  oc.balls = ri(P[P_ELEMENTS_BALLS]);
  oc.shape = ri(P[P_ELEMENTS_SHAPE]);
  oc.scale = ri(P[P_ELEMENTS_SCALE]);
  oc.root = ri(P[P_ELEMENTS_ROOT]);
  oc.octave = ri(P[P_ELEMENTS_OCTAVE]);
  oc.instrument = 10;
  ElementsParams& e = oc.elements;
  e.model = std::max(0, std::min(2, ri(P[P_ELEMENTS_MODEL])));
  e.gateMs = P[P_ELEMENTS_GATE];
  e.contour = P[P_ELEMENTS_CONTOUR] * 0.01f;
  e.bow = P[P_ELEMENTS_BOW] * 0.01f;
  e.bowTimbre = P[P_ELEMENTS_BOW_TIMBRE] * 0.01f;
  e.blow = P[P_ELEMENTS_BLOW] * 0.01f;
  e.flow = P[P_ELEMENTS_FLOW] * 0.01f;
  e.blowTimbre = P[P_ELEMENTS_BLOW_TIMBRE] * 0.01f;
  e.strike = P[P_ELEMENTS_STRIKE] * 0.01f;
  e.mallet = P[P_ELEMENTS_MALLET] * 0.01f;
  e.strikeTimbre = P[P_ELEMENTS_STRIKE_TIMBRE] * 0.01f;
  e.geometry = P[P_ELEMENTS_GEOMETRY] * 0.01f;
  e.brightness = P[P_ELEMENTS_BRIGHT] * 0.01f;
  e.damping = P[P_ELEMENTS_DAMPING] * 0.01f;
  e.position = P[P_ELEMENTS_POS] * 0.01f;
  e.space = P[P_ELEMENTS_SPACE] * 0.02f;
  return oc;
}

}  // namespace gb
