// GrainBrick Android - granular sample player + roam (position automation).
#pragma once

#include <atomic>
#include <memory>

#include "dsp.h"

namespace gb {

// Immutable-after-publish sample buffer shared between UI thread (creator) and audio thread.
struct SampleData {
  std::vector<float> l, r;
  int frames = 0;
  double sampleRate = 48000.0;
  uint32_t seq = 0;  // publication sequence number (see Engine::publishSample)
};

// Per-block control values for the granular engine (already smoothed by the Engine).
struct GrainCtl {
  bool enabled = true;
  bool spawn = true;       // false => let running grains finish but start no new ones
  float density = 50.f;    // 0..100 (%)
  float sizeSec = 0.4f;
  float pitchSemis = 0.f;
  float position = 0.5f;   // 0..1, including roam offset
  float spray = 0.f;
  float width = 0.7f;
  float jump = 0.f;        // probability 0..1
  float reverse = 0.f;     // probability 0..1
  float chaos = 0.f;
  float overlap = 0.5f;    // 0..1 window rounding
  float xfadeSec = 0.1f;
};

inline float densityToRate(float densityPct) {
  // 0.4 .. 80 grains per second, exponential.
  return 0.4f * std::pow(200.0f, clampf(densityPct, 0.f, 100.f) * 0.01f);
}

class Granular {
 public:
  static constexpr int kMaxGrains = 64;

  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    reset();
  }
  void reset() {
    for (auto& g : grains_) g.active = false;
    untilNext_ = 0.0;
    activeCount_ = 0;
  }
  void setSample(const SampleData* s) {
    sample_ = s;
    reset();
  }

  // Adds into outL/outR. Call with n <= any size.
  void process(const GrainCtl& c, float* outL, float* outR, int n) {
    if (!sample_ || sample_->frames < 16) {
      activeCount_ = 0;
      return;
    }
    const float rate = densityToRate(c.density);
    if (c.enabled && c.spawn) {
      // Launch as many grains as have become due (block-quantised, <=64 frames).
      untilNext_ -= n;
      int guard = 0;
      while (untilNext_ <= 0.0 && guard++ < 8) {
        spawn(c);
        float jitter = 0.3f + c.chaos * 0.5f;
        float interval = (sr_ / rate) * std::max(0.1f, 1.0f + jitter * rng_.bi());
        untilNext_ += interval;
      }
      if (untilNext_ < -sr_) untilNext_ = 0.0;
    } else {
      untilNext_ = 0.0;
    }

    // Loudness compensation: keep the cloud level roughly constant as overlap grows.
    float overlap = rate * c.sizeSec;
    float norm = 0.9f / std::sqrt(std::max(1.0f, overlap * 0.6f));

    const float* dl = sample_->l.data();
    const float* dr = sample_->r.data();
    const int N = sample_->frames;
    int active = 0;
    for (auto& g : grains_) {
      if (!g.active) continue;
      ++active;
      const int remaining = g.len - g.age;
      const int cnt = std::min(n, remaining);
      double pos = g.pos;
      int age = g.age;
      for (int k = 0; k < cnt; ++k, ++age) {
        float tin = std::min(1.0f, static_cast<float>(age) * g.invFade);
        float tout = std::min(1.0f, static_cast<float>(g.len - age) * g.invFade);
        float env = smoothstep(std::min(tin, tout)) * g.amp * norm;
        float sl, sr;
        readHermite(dl, dr, N, pos, sl, sr);
        outL[k] += sl * env * g.gL;
        outR[k] += sr * env * g.gR;
        pos += g.inc;
      }
      g.pos = pos;
      g.age = age;
      if (g.age >= g.len) {
        g.active = false;
        --active;
      }
    }
    activeCount_ = active;
  }

  int activeCount() const { return activeCount_; }
  // Normalised read positions of currently active grains (-1 for inactive slots).
  void activePositions(float* out) const {
    if (!sample_ || sample_->frames < 2) {
      for (int i = 0; i < kMaxGrains; ++i) out[i] = -1.f;
      return;
    }
    const double inv = 1.0 / static_cast<double>(sample_->frames);
    for (int i = 0; i < kMaxGrains; ++i) {
      const Grain& g = grains_[i];
      if (!g.active) {
        out[i] = -1.f;
        continue;
      }
      double p = g.pos * inv;
      p -= std::floor(p);
      out[i] = static_cast<float>(p);
    }
  }

 private:
  struct Grain {
    bool active = false;
    double pos = 0.0;
    double inc = 1.0;
    int age = 0;
    int len = 0;
    float invFade = 1.f;
    float gL = 1.f, gR = 1.f;
    float amp = 1.f;
  };

  static inline int wrapIdx(int i, int n) {
    if (i < 0) i += n;
    else if (i >= n) i -= n;
    return i;
  }

  static inline void readHermite(const float* dl, const float* dr, int N, double pos, float& oL,
                                 float& oR) {
    double fl = std::floor(pos);
    float f = static_cast<float>(pos - fl);
    int i1 = static_cast<int>(fl);
    if (i1 >= N || i1 < 0) {  // rare: only when a grain crosses the loop point
      i1 %= N;
      if (i1 < 0) i1 += N;
    }
    int i0 = wrapIdx(i1 - 1, N), i2 = wrapIdx(i1 + 1, N), i3 = wrapIdx(i1 + 2, N);
    oL = hermite(dl[i0], dl[i1], dl[i2], dl[i3], f);
    oR = hermite(dr[i0], dr[i1], dr[i2], dr[i3], f);
  }
  static inline float hermite(float y0, float y1, float y2, float y3, float f) {
    float c0 = y1;
    float c1 = 0.5f * (y2 - y0);
    float c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3;
    float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * f + c2) * f + c1) * f + c0;
  }

  void spawn(const GrainCtl& c) {
    Grain* slot = nullptr;
    int oldest = -1, oldestAge = -1;
    for (int i = 0; i < kMaxGrains; ++i) {
      if (!grains_[i].active) { slot = &grains_[i]; break; }
      if (grains_[i].age > oldestAge) { oldestAge = grains_[i].age; oldest = i; }
    }
    if (!slot) slot = &grains_[oldest];  // steal the oldest

    const int N = sample_->frames;
    float size = c.sizeSec;
    float semis = c.pitchSemis;
    if (c.chaos > 0.f) {
      size *= std::exp(c.chaos * 0.7f * rng_.bi());
      semis += c.chaos * 0.5f * rng_.bi();
    }
    size = clampf(size, 0.01f, 8.0f);
    int len = std::max(64, static_cast<int>(size * sr_));
    float ratio = semitonesToRatio(semis);
    bool rev = rng_.uni() < c.reverse;
    double srcStep = static_cast<double>(ratio) * sample_->sampleRate / static_cast<double>(sr_);
    double inc = rev ? -srcStep : srcStep;

    float p = c.position;
    if (rng_.uni() < c.jump) p = rng_.uni();
    else p += rng_.bi() * c.spray * 0.5f;
    p -= std::floor(p);
    double start = static_cast<double>(p) * static_cast<double>(N - 1);
    double span = static_cast<double>(len) * srcStep;
    if (span < static_cast<double>(N) - 4.0) {
      if (rev) start = std::min(std::max(start, span + 1.0), static_cast<double>(N) - 2.0);
      else start = std::min(std::max(start, 0.0), static_cast<double>(N) - 2.0 - span);
    }

    float alpha = clampf(c.overlap, 0.02f, 1.0f);
    float fade = std::max(alpha * static_cast<float>(len) * 0.5f,
                          std::min(c.xfadeSec * sr_, static_cast<float>(len) * 0.5f));
    fade = clampf(fade, 16.0f, static_cast<float>(len) * 0.5f);

    float pan = rng_.bi() * c.width;
    float th = (pan + 1.0f) * kPi * 0.25f;

    slot->active = true;
    slot->pos = start;
    slot->inc = inc;
    slot->age = 0;
    slot->len = len;
    slot->invFade = 1.0f / fade;
    slot->gL = std::cos(th) * 1.41421356f;
    slot->gR = std::sin(th) * 1.41421356f;
    slot->amp = 1.0f;
  }

  float sr_ = 48000.f;
  const SampleData* sample_ = nullptr;
  Grain grains_[kMaxGrains];
  double untilNext_ = 0.0;
  int activeCount_ = 0;
  Rng rng_{0xC0FFEEu};
};

// Automatic movement of the grain start position (the "Roam" section).
class Roamer {
 public:
  void reset() {
    phase_ = 0.f; rnd_ = rndTarget_ = 0.f; wander_ = wanderTarget_ = 0.f;
    rndTimer_ = wanderTimer_ = 0.f; smoothed_ = 0.f;
  }
  // Returns a position offset in normalised sample units. dt = block duration in seconds.
  float update(int mode, float range, float speedHz, float smooth, float wanderAmt, float hold,
               float dt) {
    const float move = (1.0f - hold);
    float o = 0.f;
    switch (mode) {
      default:
      case 0:  // scan
        phase_ += speedHz * dt * move;
        phase_ -= std::floor(phase_);
        o = (phase_ - 0.5f) * range;
        break;
      case 1: {  // ping-pong
        phase_ += speedHz * dt * move;
        phase_ -= std::floor(phase_);
        float tri = 1.0f - std::fabs(2.0f * phase_ - 1.0f);
        o = (tri - 0.5f) * range;
        break;
      }
      case 2:  // sine
        phase_ += speedHz * dt * move;
        phase_ -= std::floor(phase_);
        o = 0.5f * std::sin(kTwoPi * phase_) * range;
        break;
      case 3: {  // random glide
        rndTimer_ -= dt * move;
        if (rndTimer_ <= 0.f) {
          rndTarget_ = rng_.bi();
          rndTimer_ = 1.0f / std::max(0.005f, speedHz);
        }
        rnd_ += (rndTarget_ - rnd_) * (1.0f - std::exp(-dt * std::max(0.02f, speedHz) * 3.0f));
        o = rnd_ * 0.5f * range;
        break;
      }
    }
    // Slow random drift, independent of range.
    wanderTimer_ -= dt * move;
    if (wanderTimer_ <= 0.f) {
      wanderTarget_ = rng_.bi();
      wanderTimer_ = 1.5f;
    }
    wander_ += (wanderTarget_ - wander_) * (1.0f - std::exp(-dt / 0.8f));
    o += wander_ * wanderAmt * 0.25f;

    // Smoothing; snap on large discontinuities (e.g. scan wrap-around).
    if (std::fabs(o - smoothed_) > 0.5f * std::max(range, 0.05f) + 0.1f * wanderAmt + 0.01f) {
      smoothed_ = o;
    } else {
      float tc = 0.005f + smooth * 2.0f;
      smoothed_ += (o - smoothed_) * (1.0f - std::exp(-dt / tc));
    }
    return smoothed_;
  }

 private:
  float phase_ = 0.f, rnd_ = 0.f, rndTarget_ = 0.f, wander_ = 0.f, wanderTarget_ = 0.f;
  float rndTimer_ = 0.f, wanderTimer_ = 0.f, smoothed_ = 0.f;
  Rng rng_{0xBADA55u};
};

}  // namespace gb
