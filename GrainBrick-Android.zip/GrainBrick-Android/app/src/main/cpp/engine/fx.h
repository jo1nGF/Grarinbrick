// GrainBrick Android - tape, EQ, compressor and stereo delay.
#pragma once

#include "dsp.h"
#include "params.h"

namespace gb {

// ---------------------------------------------------------------------------------------------
// Tape: wow/flutter (modulated delay), saturation, 8-bit, dropouts, crackle and hiss.
// ---------------------------------------------------------------------------------------------
class Tape {
 public:
  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    baseDelay_ = 0.012f * sr_;
    dl_.init(static_cast<int>(0.03f * sr_) + 8);
    dr_.init(static_cast<int>(0.03f * sr_) + 8);
    reset();
  }
  void reset() {
    dl_.clear(); dr_.clear();
    en_ = 0.f; satL_.reset(); satR_.reset(); hissHpL_.reset(); hissHpR_.reset();
    dropGain_ = 1.f; dropTarget_ = 1.f; dropHold_ = 0; crackEnv_ = 0.f;
  }

  // hissGate (0..1) lets the engine mute the noise floor while the transport is stopped.
  void process(const float* P, float* l, float* r, int n, float hissGate = 1.f) {
    const bool on = P[P_TAPE_ENABLED] > 0.5f;
    en_ += ((on ? 1.f : 0.f) - en_) * onePoleCoef(0.03f, sr_ / static_cast<float>(n));
    if (!on && en_ < 0.002f) { en_ = 0.f; return; }

    const float wow = P[P_TAPE_WOW], flutter = P[P_TAPE_FLUTTER];
    const float hiss = P[P_TAPE_HISS], sat = P[P_TAPE_SATURATION];
    const float crinkle = P[P_TAPE_CRINKLE], dropout = P[P_TAPE_DROPOUT], bit8 = P[P_TAPE_BIT8];

    // Depth in samples so that peak pitch deviation is ~1.2% (wow) and ~0.4% (flutter).
    const float wowDepth = wow * 0.0038f * sr_;
    const float flDepth = flutter * 8.5e-5f * sr_;
    const float g = 1.0f + 4.0f * sat;
    const float makeup = (1.0f + 0.25f * sat) / g;
    const float lpA = lowpassCoef(18000.f - 11000.f * sat, sr_);
    const float hissAmp = 0.04f * hiss * hiss * hissGate;
    const float hissA = lowpassCoef(1500.f, sr_);
    const float bitMix = std::min(1.f, bit8 * 3.f);
    const float levels = std::exp2(15.0f - 8.0f * bit8);  // 2^(bits-1)
    const float crackRate = crinkle * crinkle * 30.0f / sr_;
    const float dropRate = dropout * 1.2f / sr_;
    const float crackDecay = std::exp(-1.0f / (0.0015f * sr_));
    const float dropAtt = onePoleCoef(0.005f, sr_), dropRel = onePoleCoef(0.04f, sr_);
    const float pi2 = kTwoPi;

    for (int i = 0; i < n; ++i) {
      wowP1_ += 0.37f / sr_; wowP2_ += 0.91f / sr_;
      flP1_ += 7.3f / sr_;   flP2_ += 11.9f / sr_;
      if (wowP1_ > 1.f) wowP1_ -= 1.f;
      if (wowP2_ > 1.f) wowP2_ -= 1.f;
      if (flP1_ > 1.f) flP1_ -= 1.f;
      if (flP2_ > 1.f) flP2_ -= 1.f;
      float wm = 0.65f * std::sin(pi2 * wowP1_) + 0.35f * std::sin(pi2 * wowP2_);
      float fm = 0.7f * std::sin(pi2 * flP1_) + 0.3f * std::sin(pi2 * flP2_);
      float d = baseDelay_ + wowDepth * wm + flDepth * fm;

      float inL = l[i], inR = r[i];
      dl_.write(inL);
      dr_.write(inR);
      float xl = dl_.read(d), xr = dr_.read(d);

      if (sat > 0.001f) {
        xl = satL_.lp(makeup * std::tanh(g * xl), lpA);
        xr = satR_.lp(makeup * std::tanh(g * xr), lpA);
      }
      if (bit8 > 0.001f) {
        float ql = std::round(xl * levels) / levels, qr = std::round(xr * levels) / levels;
        xl += (ql - xl) * bitMix;
        xr += (qr - xr) * bitMix;
      }
      if (dropRate > 0.f) {
        if (dropHold_ <= 0 && rng_.uni() < dropRate) {
          dropTarget_ = dbToLin(-(8.f + 22.f * rng_.uni()));
          dropHold_ = static_cast<int>((0.03f + 0.22f * rng_.uni()) * sr_);
        }
        if (dropHold_ > 0) {
          --dropHold_;
          dropGain_ += (dropTarget_ - dropGain_) * dropAtt;
        } else {
          dropGain_ += (1.f - dropGain_) * dropRel;
        }
        xl *= dropGain_; xr *= dropGain_;
      } else {
        dropGain_ = 1.f;
      }
      if (crackRate > 0.f) {
        if (rng_.uni() < crackRate) crackEnv_ = 0.3f + 0.7f * rng_.uni();
        crackEnv_ *= crackDecay;
        float a = crackEnv_ * crinkle * 0.15f;
        xl += rng_.bi() * a;
        xr += rng_.bi() * a;
      }
      if (hissAmp > 0.f) {
        xl += hissHpL_.hp(rng_.bi(), hissA) * hissAmp * 1.7f;
        xr += hissHpR_.hp(rng_.bi(), hissA) * hissAmp * 1.7f;
      }
      l[i] = inL + (xl - inL) * en_;
      r[i] = inR + (xr - inR) * en_;
    }
  }

 private:
  float sr_ = 48000.f, baseDelay_ = 576.f;
  DelayLine dl_, dr_;
  float en_ = 0.f;
  float wowP1_ = 0.f, wowP2_ = 0.31f, flP1_ = 0.f, flP2_ = 0.57f;
  OnePole satL_, satR_, hissHpL_, hissHpR_;
  float dropGain_ = 1.f, dropTarget_ = 1.f;
  int dropHold_ = 0;
  float crackEnv_ = 0.f;
  Rng rng_{0x7A9E5u};
};

// ---------------------------------------------------------------------------------------------
// Six band EQ: low shelf, three peaking bands, two high shelves.
// ---------------------------------------------------------------------------------------------
class Eq6 {
 public:
  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    for (int c = 0; c < 2; ++c) for (int b = 0; b < 6; ++b) bq_[c][b].reset();
    for (int b = 0; b < 6; ++b) last_[b] = 1e9f;
  }
  void process(const float* P, float* l, float* r, int n) {
    const float g[6] = {P[P_EQ_LOW], P[P_EQ_LMID], P[P_EQ_MID], P[P_EQ_HMID], P[P_EQ_HIGH], P[P_EQ_AIR]};
    bool any = false;
    for (int b = 0; b < 6; ++b) {
      if (std::fabs(g[b]) > 0.02f) any = true;
      if (std::fabs(g[b] - last_[b]) > 0.005f) {
        last_[b] = g[b];
        for (int c = 0; c < 2; ++c) design(c, b, g[b]);
      }
    }
    if (!any) {
      for (int c = 0; c < 2; ++c) for (int b = 0; b < 6; ++b) bq_[c][b].reset();
      return;
    }
    for (int i = 0; i < n; ++i) {
      float xl = l[i], xr = r[i];
      for (int b = 0; b < 6; ++b) {
        if (std::fabs(last_[b]) <= 0.02f) continue;
        xl = bq_[0][b].process(xl);
        xr = bq_[1][b].process(xr);
      }
      l[i] = xl; r[i] = xr;
    }
  }

 private:
  void design(int c, int b, float gainDb) {
    Biquad& q = bq_[c][b];
    switch (b) {
      case 0: q.setLowShelf(sr_, 90.f, gainDb); break;
      case 1: q.setPeaking(sr_, 250.f, gainDb, 0.9f); break;
      case 2: q.setPeaking(sr_, 1000.f, gainDb, 0.8f); break;
      case 3: q.setPeaking(sr_, 3500.f, gainDb, 0.8f); break;
      case 4: q.setHighShelf(sr_, 8000.f, gainDb); break;
      default: q.setHighShelf(sr_, 14000.f, gainDb); break;
    }
  }
  float sr_ = 48000.f;
  Biquad bq_[2][6];
  float last_[6];
};

// ---------------------------------------------------------------------------------------------
// Stereo-linked feed-forward compressor with soft knee and parallel mix.
// ---------------------------------------------------------------------------------------------
class Compressor {
 public:
  void prepare(double sampleRate) { sr_ = static_cast<float>(sampleRate); reset(); }
  void reset() { grDb_ = 0.f; en_ = 0.f; }

  void process(const float* P, float* l, float* r, int n) {
    const bool on = P[P_COMP_ENABLED] > 0.5f;
    en_ += ((on ? 1.f : 0.f) - en_) * onePoleCoef(0.02f, sr_ / static_cast<float>(n));
    if (!on && en_ < 0.002f) { en_ = 0.f; grDb_ = 0.f; return; }

    const float red = P[P_COMP_REDUCTION] * 0.01f;
    const float thr = -2.0f - 30.0f * red;           // dB
    const float ratio = 1.0f + 7.0f * red;
    const float slope = 1.0f / ratio - 1.0f;          // <= 0
    const float knee = 6.0f;
    const float makeup = dbToLin(P[P_COMP_GAIN]);
    const float mix = P[P_COMP_MIX] * en_;
    const float atk = std::exp(-1.0f / (std::max(0.0001f, P[P_COMP_ATTACK] * 0.001f) * sr_));
    const float rel = std::exp(-1.0f / (std::max(0.001f, P[P_COMP_RELEASE] * 0.001f) * sr_));

    for (int i = 0; i < n; ++i) {
      float lvl = std::max(std::fabs(l[i]), std::fabs(r[i]));
      float lvlDb = linToDb(lvl);
      float over = lvlDb - thr;
      float target;
      if (2.0f * over < -knee) target = 0.f;
      else if (2.0f * std::fabs(over) <= knee) {
        float t = over + knee * 0.5f;
        target = slope * t * t / (2.0f * knee);
      } else target = slope * over;
      // grDb_ is <= 0; "attack" = reduction increasing (more negative).
      if (target < grDb_) grDb_ = atk * grDb_ + (1.f - atk) * target;
      else grDb_ = rel * grDb_ + (1.f - rel) * target;
      float gain = dbToLin(grDb_) * makeup;
      l[i] = l[i] + (l[i] * gain - l[i]) * mix;
      r[i] = r[i] + (r[i] * gain - r[i]) * mix;
    }
  }
  float gainReductionDb() const { return grDb_; }

 private:
  float sr_ = 48000.f, grDb_ = 0.f, en_ = 0.f;
};

// ---------------------------------------------------------------------------------------------
// Stereo delay with ping-pong, feedback filtering and glide on time changes.
// ---------------------------------------------------------------------------------------------
class StereoDelay {
 public:
  void prepare(double sampleRate) {
    sr_ = static_cast<float>(sampleRate);
    int maxSamples = static_cast<int>(2.4f * sr_) + 8;
    ll_.init(maxSamples);
    lr_.init(maxSamples);
    reset();
  }
  void reset() {
    ll_.clear(); lr_.clear();
    lpL_.reset(); lpR_.reset(); hpL_.reset(); hpR_.reset();
    timeSm_ = -1.f;
  }

  void process(const float* P, float* l, float* r, int n) {
    const float mix = P[P_DELAY_MIX];
    const float fb = P[P_DELAY_FEEDBACK];
    const float pp = P[P_DELAY_PINGPONG];
    const float spread = P[P_DELAY_SPREAD];
    const float target = clampf(P[P_DELAY_TIME] * 0.001f * sr_, 4.f, 2.0f * sr_);
    if (timeSm_ < 0.f) timeSm_ = target;
    const float k = onePoleCoef(std::max(0.001f, P[P_SMOOTH_DELAY_MS] * 0.001f), sr_);
    const float lpA = lowpassCoef(P[P_DELAY_LOWPASS], sr_);
    const float hpA = lowpassCoef(60.f, sr_);
    const float maxD = static_cast<float>(ll_.capacity() - 8);

    for (int i = 0; i < n; ++i) {
      timeSm_ += (target - timeSm_) * k;
      float dL = std::min(timeSm_, maxD);
      float dR = std::min(timeSm_ * (1.0f + 0.12f * spread), maxD);
      // read() is relative to the last written sample, so subtract one to get exact delay times.
      float oL = ll_.read(dL - 1.f), oR = lr_.read(dR - 1.f);
      float inL = l[i], inR = r[i];
      float inM = 0.5f * (inL + inR);
      float wL = lerpf(inL, inM, pp) + fb * lerpf(oL, oR, pp);
      float wR = lerpf(inR, 0.f, pp) + fb * lerpf(oR, oL, pp);
      wL = hpL_.hp(lpL_.lp(wL, lpA), hpA);
      wR = hpR_.hp(lpR_.lp(wR, lpA), hpA);
      if (std::fabs(wL) > 1.f) wL = std::tanh(wL);
      if (std::fabs(wR) > 1.f) wR = std::tanh(wR);
      ll_.write(wL);
      lr_.write(wR);
      l[i] = inL + mix * oL;
      r[i] = inR + mix * oR;
    }
  }

 private:
  float sr_ = 48000.f, timeSm_ = -1.f;
  DelayLine ll_, lr_;
  OnePole lpL_, lpR_, hpL_, hpR_;
};

}  // namespace gb
