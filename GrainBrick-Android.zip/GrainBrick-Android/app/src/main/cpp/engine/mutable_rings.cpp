#include "mutable_orbix.h"

// The Mutable code picks ARM assembly for a few DSP helpers unless TEST is defined.
#ifndef TEST
#define TEST 1
#endif

#include <algorithm>
#include <cmath>
#include <cstring>

#include "rings/dsp/part.h"
#include "mutable_pipe.h"

namespace gb {
using mutable_detail::Pipe;
using mutable_detail::smooth;
using mutable_detail::pot;

// ------------------------------------------------------------------------------------------
// RINGS
// ------------------------------------------------------------------------------------------
struct RingsBank::Impl {
  rings::Part part;
  uint16_t reverb[32768];
  Pipe pipe;
  rings::Patch patch{};
  float sm[4] = {0.4f, 0.6f, 0.6f, 0.3f};
  float note = 60.f;
  bool strumPending = false;
  float level = 0.f;
  float sr = 48000.f;
  int chord = 0;
};

RingsBank::RingsBank(float sampleRate) : impl_(new Impl) {
  std::fill(impl_->reverb, impl_->reverb + 32768, uint16_t{0});
  std::memset(static_cast<void*>(&impl_->part), 0, sizeof(impl_->part));  // firmware assumes zeroed static memory
  impl_->part.Init(impl_->reverb);
  impl_->sr = sampleRate;
  impl_->pipe.init(rings::kSampleRate, sampleRate);
}
RingsBank::~RingsBank() = default;

void RingsBank::reset() {
  std::fill(impl_->reverb, impl_->reverb + 32768, uint16_t{0});
  std::memset(static_cast<void*>(&impl_->part), 0, sizeof(impl_->part));  // firmware assumes zeroed static memory
  impl_->part.Init(impl_->reverb);
  impl_->pipe.reset();
  impl_->strumPending = false;
  impl_->level = 0.f;
}

void RingsBank::note(const RingsParams& p, float midi, float strength) {
  (void)p;
  (void)strength;  // Rings has no velocity: the internal exciter always plucks with the same force
  impl_->note = midi;
  impl_->strumPending = true;
}

bool RingsBank::sounding() const { return impl_->level > 1e-9f; }

void RingsBank::render(const RingsParams& p, float* l, float* r, int n, float gain) {
  Impl& s = *impl_;
  s.part.set_model(static_cast<rings::ResonatorModel>(std::max(0, std::min(5, p.model))));
  const int poly = std::max(1, std::min(4, p.polyphony));
  if (poly != s.part.polyphony()) s.part.set_polyphony(poly);  // sets the dirty flag, which re-initialises the resonators
  s.chord = std::max(0, std::min(rings::kNumChords - 1, p.chord));
  const float target[4] = {pot(p.structure), pot(p.brightness), pot(p.damping), pot(p.position)};
  s.pipe.pull(l, r, n, rings::kMaxBlockSize, [&](float* outL, float* outR) {
    rings::PerformanceState ps;
    ps.strum = s.strumPending;
    ps.internal_exciter = true;
    ps.internal_strum = false;
    ps.internal_note = false;
    ps.tonic = 0.f;
    ps.note = s.note;
    ps.fm = 0.f;
    ps.chord = s.chord;
    s.strumPending = false;
    s.patch.structure = smooth(s.sm[0], target[0], 0.25f);
    s.patch.brightness = smooth(s.sm[1], target[1], 0.25f);
    s.patch.damping = smooth(s.sm[2], target[2], 0.25f);
    s.patch.position = smooth(s.sm[3], target[3], 0.25f);
    float in[rings::kMaxBlockSize] = {0};
    float o[rings::kMaxBlockSize], a[rings::kMaxBlockSize];
    s.part.Process(ps, s.patch, in, o, a, rings::kMaxBlockSize);
    float e = 0.f;
    for (size_t i = 0; i < rings::kMaxBlockSize; ++i) {
      if (!std::isfinite(o[i]) || !std::isfinite(a[i])) { o[i] = a[i] = 0.f; }
      outL[i] = std::tanh(o[i] * gain);
      outR[i] = std::tanh(a[i] * gain);
      e += o[i] * o[i] + a[i] * a[i];
    }
    s.level += 0.05f * (e / static_cast<float>(rings::kMaxBlockSize) - s.level);
  });
}

}  // namespace gb
