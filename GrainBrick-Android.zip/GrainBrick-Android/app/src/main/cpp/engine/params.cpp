#include "params.h"

#include <cstring>

namespace gb {

namespace {
const ParamInfo kParams[] = {
#define X(E, id, group, label, unit, mn, mx, df, kind, curve, choices, help)                                  \
  {id, group, label, unit, static_cast<float>(mn), static_cast<float>(mx), static_cast<float>(df),            \
   Kind::kind, Curve::curve, choices, help},
    GB_PARAMS(X)
#undef X
};
static_assert(sizeof(kParams) / sizeof(kParams[0]) == static_cast<size_t>(P_COUNT),
              "registry/enum mismatch");
}  // namespace

int paramCount() { return P_COUNT; }

const ParamInfo& paramInfo(int index) {
  if (index < 0 || index >= P_COUNT) index = 0;
  return kParams[index];
}

int paramIndex(const char* id) {
  if (!id) return -1;
  for (int i = 0; i < P_COUNT; ++i) {
    if (std::strcmp(kParams[i].id, id) == 0) return i;
  }
  return -1;
}

}  // namespace gb
