// GrainBrick Android - Rings and Elements resonators for the RINGS / ELEMENTS ORBIX.
//
// The DSP is the original MIT-licensed firmware code of the Mutable Instruments Rings and Elements
// modules by Emilie Gillet (third_party/mutable, with its copyright notices untouched). This file
// only wraps it: it feeds the note-on events of an ORBIX into the modules the way their own firmware
// feeds strums and gates, runs them at their native sample rates (Rings 48 kHz, Elements 32 kHz) and
// resamples the result to the audio rate. Mutable Instruments is not affiliated with this project.
#pragma once

#include <cstdint>
#include <memory>

namespace gb {

/// Controls of the RINGS ORBIX resonator. All 0..1 except the integers.
struct RingsParams {
  int model = 0;         // 0 modal, 1 sympathetic strings, 2 string, 3 fm, 4 quantized sympathetic, 5 string + reverb
  int polyphony = 1;     // 1, 2 or 4
  int chord = 0;         // 0..10, used by model 4
  float structure = 0.4f, brightness = 0.6f, damping = 0.6f, position = 0.3f;
};

/// Controls of the ELEMENTS ORBIX voice. All 0..1 except space (0..2) and the integers.
struct ElementsParams {
  int model = 0;         // 0 modal, 1 string, 2 strings
  float gateMs = 120.f;  // how long every note holds the gate (bow and blow need it, strikes do not)
  float contour = 0.f;   // exciter envelope shape
  float bow = 0.f, bowTimbre = 0.5f;
  float blow = 0.f, flow = 0.5f, blowTimbre = 0.5f;
  float strike = 0.8f, mallet = 0.5f, strikeTimbre = 0.5f;
  float geometry = 0.2f, brightness = 0.5f, damping = 0.25f, position = 0.3f;
  float space = 0.5f;    // 0..2
};

/// A resampling pipe from a fixed-rate generator to the audio rate (cubic Hermite).
class RingsBank {
 public:
  explicit RingsBank(float sampleRate);
  ~RingsBank();
  RingsBank(const RingsBank&) = delete;
  RingsBank& operator=(const RingsBank&) = delete;

  void reset();
  void note(const RingsParams& p, float midi, float strength);
  /// Adds n frames to l / r.
  void render(const RingsParams& p, float* l, float* r, int n, float gain);
  bool sounding() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class ElementsBank {
 public:
  explicit ElementsBank(float sampleRate);
  ~ElementsBank();
  ElementsBank(const ElementsBank&) = delete;
  ElementsBank& operator=(const ElementsBank&) = delete;

  void reset();
  void note(const ElementsParams& p, float midi, float strength);
  void render(const ElementsParams& p, float* l, float* r, int n, float gain);
  bool sounding() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace gb
