// C ABI around SoundTouch (LGPL-2.1, third_party/soundtouch).
//
// On Android SoundTouch is built as its own shared library (libSoundTouch.so) so that it can be
// replaced by a modified build, as the LGPL asks; the engine only talks to it through these plain
// C functions, so no C++ object ever crosses the library boundary. Host tests link the sources
// directly. All functions are safe to call with a null handle.
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Same numbers as the SETTING_* constants of SoundTouch.h.
enum {
  GBST_SETTING_USE_AA_FILTER = 0,
  GBST_SETTING_AA_FILTER_LENGTH = 1,
  GBST_SETTING_USE_QUICKSEEK = 2,
  GBST_SETTING_SEQUENCE_MS = 3,
  GBST_SETTING_SEEKWINDOW_MS = 4,
  GBST_SETTING_OVERLAP_MS = 5,
  GBST_SETTING_NOMINAL_INPUT_SEQUENCE = 6,
  GBST_SETTING_NOMINAL_OUTPUT_SEQUENCE = 7,
  GBST_SETTING_INITIAL_LATENCY = 8,
};

void* gbst_create(unsigned sampleRate, unsigned channels);
void gbst_destroy(void* h);
void gbst_clear(void* h);
void gbst_set_pitch_semitones(void* h, float semitones);
int gbst_set_setting(void* h, int setting, int value);
int gbst_get_setting(void* h, int setting);
// Interleaved float frames.
void gbst_put(void* h, const float* interleaved, unsigned frames);
unsigned gbst_receive(void* h, float* interleaved, unsigned maxFrames);
unsigned gbst_available(void* h);

#ifdef __cplusplus
}
#endif
