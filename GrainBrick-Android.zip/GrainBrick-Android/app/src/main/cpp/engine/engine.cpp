#include "engine.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>

namespace gb {

namespace {
inline int roundInt(float v) { return static_cast<int>(std::lround(v)); }
}  // namespace

Engine::Engine() {
  for (int i = 0; i < P_COUNT; ++i) {
    float d = paramInfo(i).def;
    target_[i].store(d, std::memory_order_relaxed);
    cur_[i] = d;
  }
  for (int i = 0; i < Granular::kMaxGrains + Orbix::kStateSize; ++i)
    shared_[i].store(i < Granular::kMaxGrains ? -1.f : 0.f, std::memory_order_relaxed);
}

void Engine::prepare(double sampleRate) {
  sr_ = sampleRate > 8000.0 ? sampleRate : 48000.0;
  const size_t cap = static_cast<size_t>(kBlock);
  for (auto* v : {&srcL_, &srcR_, &orbL_, &orbR_, &busL_, &busR_, &revInL_, &revInR_, &tmpL_, &tmpR_,
                  &inL_, &inR_, &shimOutL_, &shimOutR_}) {
    v->assign(cap, 0.f);
  }
  granular_.prepare(sr_);
  roamer_.reset();
  orbix_.prepare(sr_);
  tape_.prepare(sr_);
  eq_.prepare(sr_);
  comp_.prepare(sr_);
  delay_.prepare(sr_);
  reverb_.prepare(sr_, 0.5f);
  shimmer_.prepare(sr_);
  granular_.setSample(sample_);
  orbix_.setSample(sample_);
  playGain_ = 0.f;
  pitchElastic_ = target_[P_GRAIN_PITCH].load(std::memory_order_relaxed);
  roamOffset_ = 0.f;
  limGain_ = 1.f;
  outPeak_ = inPeak_ = 0.f;
  snap_.store(true, std::memory_order_relaxed);
  prepared_ = true;
}

// ------------------------------------------------------------------------------------------
// parameters
// ------------------------------------------------------------------------------------------
void Engine::setParam(int index, float value) {
  if (index < 0 || index >= P_COUNT) return;
  const ParamInfo& pi = paramInfo(index);
  if (!std::isfinite(value)) value = pi.def;
  value = clampf(value, pi.min, pi.max);
  if (pi.kind != Kind::Knob) value = static_cast<float>(roundInt(value));
  target_[index].store(value, std::memory_order_relaxed);
}

float Engine::getParam(int index) const {
  if (index < 0 || index >= P_COUNT) return 0.f;
  return target_[index].load(std::memory_order_relaxed);
}

void Engine::snapParams() { snap_.store(true, std::memory_order_relaxed); }

void Engine::updateParams(int n) {
  const bool snap = snap_.exchange(false, std::memory_order_relaxed);
  const float stepHz = static_cast<float>(sr_) / static_cast<float>(n);
  const float coef =
      onePoleCoef(target_[P_SMOOTH_PARAM_MS].load(std::memory_order_relaxed) * 0.001f, stepHz);
  for (int i = 0; i < P_COUNT; ++i) {
    const float t = target_[i].load(std::memory_order_relaxed);
    if (snap || i == P_SMOOTH_PARAM_MS || paramInfo(i).kind != Kind::Knob) {
      cur_[i] = t;
    } else {
      cur_[i] += (t - cur_[i]) * coef;
    }
  }
}

// ------------------------------------------------------------------------------------------
// samples
// ------------------------------------------------------------------------------------------
void Engine::publishSample(const float* l, const float* r, int frames, double sampleRate) {
  auto d = std::make_shared<SampleData>();
  if (l && frames > 0) {
    d->l.assign(l, l + frames);
    d->r.assign((r ? r : l), (r ? r : l) + frames);
    d->frames = frames;
  }
  d->sampleRate = sampleRate > 1000.0 ? sampleRate : 48000.0;
  std::lock_guard<std::mutex> lock(ownMutex_);
  d->seq = nextSeq_++;
  owned_.push_back(Published{d});
  pending_.store(d.get(), std::memory_order_release);
  collectGarbage();
}

void Engine::collectGarbage() {  // ownMutex_ held
  const uint32_t ack = ackSeq_.load(std::memory_order_acquire);
  size_t w = 0;
  for (size_t i = 0; i < owned_.size(); ++i) {
    if (owned_[i].data->seq >= ack) {
      if (w != i) owned_[w] = std::move(owned_[i]);
      ++w;
    }
  }
  owned_.resize(w);
}

void Engine::adoptPendingSample() {
  const SampleData* p = pending_.exchange(nullptr, std::memory_order_acquire);
  if (!p) return;
  sample_ = p->frames > 0 ? p : nullptr;
  granular_.setSample(sample_);
  orbix_.setSample(sample_);
  ackSeq_.store(p->seq, std::memory_order_release);
}

// ------------------------------------------------------------------------------------------
// recording
// ------------------------------------------------------------------------------------------
bool Engine::startRecording() {
  if (!prepared_ || recording_.load()) return false;
  const int inRate = inRate_.load(std::memory_order_relaxed);
  const int rate = inRate > 8000 ? inRate : static_cast<int>(sr_);
  const int cap = rate * kMaxRecSeconds;
  if (static_cast<int>(recL_.size()) != cap) {
    recL_.assign(static_cast<size_t>(cap), 0.f);
    recR_.assign(static_cast<size_t>(cap), 0.f);
  }
  recCap_.store(cap, std::memory_order_relaxed);
  recRate_.store(rate, std::memory_order_relaxed);
  recWritten_.store(0, std::memory_order_release);
  recording_.store(true, std::memory_order_release);
  return true;
}

void Engine::stopRecording() { recording_.store(false, std::memory_order_release); }

void Engine::recordInput(const float* in, int frames) {
  if (!in || frames <= 0 || !recording_.load(std::memory_order_acquire)) return;
  int w = recWritten_.load(std::memory_order_relaxed);
  const int cap = recCap_.load(std::memory_order_relaxed);
  const int cnt = std::min(cap - w, frames);
  if (cnt <= 0) {  // buffer full
    recording_.store(false, std::memory_order_release);
    return;
  }
  float* l = recL_.data() + w;
  float* r = recR_.data() + w;
  for (int k = 0; k < cnt; ++k) {
    const float a = in[2 * k];
    const float b = in[2 * k + 1];
    l[k] = std::isfinite(a) ? a : 0.f;
    r[k] = std::isfinite(b) ? b : 0.f;
  }
  // If a new recording was started while this block was being copied the counter no longer
  // equals `w` and the block is dropped instead of corrupting the new take.
  if (!recWritten_.compare_exchange_strong(w, w + cnt, std::memory_order_release, std::memory_order_relaxed)) return;
  if (cnt < frames) recording_.store(false, std::memory_order_release);
}

int Engine::copyRecording(float* dst, int maxFrames) const {
  int n = std::min(recordedFrames(), maxFrames);
  for (int i = 0; i < n; ++i) {
    dst[2 * i] = recL_[static_cast<size_t>(i)];
    dst[2 * i + 1] = recR_[static_cast<size_t>(i)];
  }
  return n;
}

// ------------------------------------------------------------------------------------------
// audio thread
// ------------------------------------------------------------------------------------------
void Engine::render(float* out, int frames, const float* in) {
  if (!prepared_ || frames <= 0) {
    if (out && frames > 0) std::memset(out, 0, sizeof(float) * 2 * static_cast<size_t>(frames));
    return;
  }
  const auto t0 = std::chrono::steady_clock::now();
  enableFlushToZero();
  adoptPendingSample();

  int done = 0;
  while (done < frames) {
    const int n = std::min(kBlock, frames - done);
    const float* iL = nullptr;
    const float* iR = nullptr;
    if (in) {
      const float* src = in + 2 * done;
      for (int k = 0; k < n; ++k) {
        inL_[static_cast<size_t>(k)] = src[2 * k];
        inR_[static_cast<size_t>(k)] = src[2 * k + 1];
      }
      iL = inL_.data();
      iR = inR_.data();
    }
    processBlock(n, iL, iR, tmpL_.data(), tmpR_.data());
    float* dst = out + 2 * done;
    for (int k = 0; k < n; ++k) {
      dst[2 * k] = tmpL_[static_cast<size_t>(k)];
      dst[2 * k + 1] = tmpR_[static_cast<size_t>(k)];
    }
    done += n;
  }

  // DSP load for the UI: time spent here against the time the callback has to last.
  const double spent = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  const float load = static_cast<float>(spent * sr_ / static_cast<double>(frames));
  dspLoad_ += 0.15f * (std::min(load, 4.f) - dspLoad_);
  meterLoad_.store(dspLoad_, std::memory_order_relaxed);
}

void Engine::processBlock(int n, const float* inL, const float* inR, float* outL, float* outR) {
  updateParams(n);
  const float* P = cur_;
  const float sr = static_cast<float>(sr_);
  const float dt = static_cast<float>(n) / sr;
  const bool playing = P[P_TRANSPORT_PLAYING] > 0.5f;
  const bool motionOn = P[P_MOTION_ENABLED] > 0.5f;

  float* sL = srcL_.data();
  float* sR = srcR_.data();
  float* oL = orbL_.data();
  float* oR = orbR_.data();
  float* bL = busL_.data();
  float* bR = busR_.data();
  std::fill(sL, sL + n, 0.f);
  std::fill(sR, sR + n, 0.f);
  std::fill(oL, oL + n, 0.f);
  std::fill(oR, oR + n, 0.f);

  // ---- input metering (raw input, before any gain; recording is fed by recordInput()) ----
  float inPk = 0.f;
  if (inL) {
    for (int k = 0; k < n; ++k) inPk = std::max(inPk, std::max(std::fabs(inL[k]), std::fabs(inR[k])));
  }
  inPeak_ = std::max(inPk, inPeak_ * std::exp(-dt / 0.3f));

  // ---- transport ----
  const float tailSec = std::max(0.005f, P[P_SMOOTH_TAIL_MS] * 0.001f);
  const float g0 = playGain_;
  const float tgtGain = playing ? 1.f : 0.f;
  const float stepG = dt / tailSec;
  playGain_ = playGain_ < tgtGain ? std::min(tgtGain, playGain_ + stepG)
                                  : std::max(tgtGain, playGain_ - stepG);
  const float g1 = playGain_;

  // ---- motion / roam -> grain controls ----
  const float hold = motionOn ? P[P_MOTION_HOLD] : 0.f;
  const float elastic = motionOn ? P[P_MOTION_ELASTIC] : 0.f;
  pitchElastic_ += (P[P_GRAIN_PITCH] - pitchElastic_) * onePoleCoef(elastic * 3.0f, 1.0f / dt);

  float roamTarget = 0.f;
  if (P[P_ROAM_ENABLED] > 0.5f) {
    roamTarget = roamer_.update(roundInt(P[P_ROAM_MODE]), P[P_ROAM_RANGE], P[P_ROAM_SPEED],
                                P[P_ROAM_SMOOTH], P[P_ROAM_WANDER], hold, dt);
  }
  roamOffset_ += (roamTarget - roamOffset_) * onePoleCoef(0.15f, 1.0f / dt);
  float pos = P[P_GRAIN_POSITION] + roamOffset_;
  pos -= std::floor(pos);
  posNow_ = pos;

  GrainCtl gc;
  gc.enabled = P[P_GRAIN_ENABLED] > 0.5f;
  gc.spawn = g1 > 0.001f || g0 > 0.001f;
  gc.density = P[P_GRAIN_DENSITY];
  gc.sizeSec = P[P_GRAIN_SIZE];
  gc.pitchSemis = pitchElastic_;
  gc.position = pos;
  gc.spray = P[P_GRAIN_SPRAY];
  gc.width = P[P_GRAIN_WIDTH];
  gc.jump = motionOn ? P[P_MOTION_JUMP] * (1.f - hold) : 0.f;
  gc.reverse = motionOn ? P[P_MOTION_REVERSE] : 0.f;
  gc.chaos = motionOn ? P[P_MOTION_CHAOS] : 0.f;
  gc.overlap = P[P_SMOOTH_OVERLAP];
  gc.xfadeSec = P[P_SMOOTH_XFADE_MS] * 0.001f;
  granular_.process(gc, sL, sR, n);

  const float inGain = dbToLin(P[P_LEVEL_INPUT_DB]);
  for (int k = 0; k < n; ++k) {
    float t = static_cast<float>(k + 1) / static_cast<float>(n);
    float pg = (g0 + (g1 - g0) * t) * inGain;
    sL[k] *= pg;
    sR[k] *= pg;
  }
  const float live = P[P_LIVE_LEVEL];
  if (inL && live > 0.001f) {
    const float lg = live * live * 2.0f * inGain;
    for (int k = 0; k < n; ++k) {
      sL[k] += inL[k] * lg;
      sR[k] += inR[k] * lg;
    }
  }

  // ---- ORBIX ----
  OrbixCtl oc;
  oc.enabled = P[P_ORBIX_ENABLED] > 0.5f;
  oc.spawn = playing;
  oc.volume = P[P_ORBIX_VOLUME] * 0.01f;
  oc.gravity = P[P_ORBIX_GRAVITY] * 0.01f;
  oc.bounce = P[P_ORBIX_BOUNCE] * 0.01f;
  oc.rotation = P[P_ORBIX_ROTATION] * 0.01f;
  oc.balls = roundInt(P[P_ORBIX_BALLS]);
  oc.shape = roundInt(P[P_ORBIX_SHAPE]);
  oc.instrument = roundInt(P[P_ORBIX_INSTRUMENT]);
  oc.scale = roundInt(P[P_ORBIX_SCALE]);
  oc.root = roundInt(P[P_ORBIX_ROOT]);
  oc.octave = roundInt(P[P_ORBIX_OCTAVE]);
  oc.attackMs = P[P_ORBIX_ATTACK];
  oc.releaseMs = P[P_ORBIX_RELEASE];
  oc.samplePos = pos;
  orbix_.process(oc, oL, oR, n);

  // ---- bus + insert effects ----
  for (int k = 0; k < n; ++k) {
    bL[k] = sL[k] + oL[k];
    bR[k] = sR[k] + oR[k];
  }
  tape_.process(P, bL, bR, n, std::min(1.f, g1 + (inL ? live : 0.f)));
  eq_.process(P, bL, bR, n);
  comp_.process(P, bL, bR, n);
  delay_.process(P, bL, bR, n);

  // ---- reverb + shimmer (parallel sends) ----
  const float orbSend = P[P_ORBIX_REVERB] * 0.01f * (oc.enabled ? 1.f : 0.f);
  const float rMix = P[P_REVERB_MIX];
  const float sMix = P[P_SHIMMER_MIX];
  reverb_.setParams(P[P_REVERB_SIZE], P[P_REVERB_DECAY], P[P_REVERB_DAMP], P[P_REVERB_DIFFUSE],
                    P[P_REVERB_MOD], P[P_REVERB_MOTION], P[P_REVERB_PREDELAY], P[P_REVERB_WIDTH]);
  shimmer_.setParams(P);
  // The shimmer works on whole blocks (its pitch shifters do); its send is the same as before.
  for (int k = 0; k < n; ++k) {
    revInL_[static_cast<size_t>(k)] = bL[k] * sMix + oL[k] * orbSend * 0.6f;
    revInR_[static_cast<size_t>(k)] = bR[k] * sMix + oR[k] * orbSend * 0.6f;
  }
  shimmer_.processBlock(revInL_.data(), revInR_.data(), shimOutL_.data(), shimOutR_.data(), n);
  const float dryG = 1.0f - 0.35f * rMix;
  const float master = dbToLin(P[P_LEVEL_MASTER_DB]);
  const float relCoef = std::exp(-1.0f / (0.12f * sr));
  float blockPeak = 0.f;
  for (int k = 0; k < n; ++k) {
    const float dl = bL[k], dr = bR[k];
    const float orbL = oL[k] * orbSend, orbR = oR[k] * orbSend;
    float rl, rr;
    reverb_.process(dl * rMix + orbL * 0.8f, dr * rMix + orbR * 0.8f, rl, rr);
    const float sl = shimOutL_[static_cast<size_t>(k)], sr2 = shimOutR_[static_cast<size_t>(k)];
    float l = (dl * dryG + rl + sl) * master;
    float r = (dr * dryG + rr + sr2) * master;
    if (!std::isfinite(l)) l = 0.f;
    if (!std::isfinite(r)) r = 0.f;

    // safety limiter (instant attack, 120 ms release)
    const float pk = std::max(std::fabs(l), std::fabs(r));
    const float need = pk > 0.97f ? 0.97f / pk : 1.f;
    if (need < limGain_) limGain_ = need;
    else limGain_ = 1.f - (1.f - limGain_) * relCoef;
    l = clampf(l * limGain_, -1.f, 1.f);
    r = clampf(r * limGain_, -1.f, 1.f);
    outL[k] = l;
    outR[k] = r;
    blockPeak = std::max(blockPeak, std::max(std::fabs(l), std::fabs(r)));
  }
  outPeak_ = std::max(blockPeak, outPeak_ * std::exp(-dt / 0.3f));

  // ---- UI metering ----
  meterOut_.store(outPeak_, std::memory_order_relaxed);
  meterIn_.store(inPeak_, std::memory_order_relaxed);
  meterGr_.store(comp_.gainReductionDb(), std::memory_order_relaxed);
  meterPos_.store(posNow_, std::memory_order_relaxed);
  meterGrains_.store(granular_.activeCount(), std::memory_order_relaxed);
  meterVoices_.store(orbix_.activeVoices(), std::memory_order_relaxed);
  float tmp[Granular::kMaxGrains + Orbix::kStateSize];
  granular_.activePositions(tmp);
  orbix_.getState(tmp + Granular::kMaxGrains);
  for (int i = 0; i < Granular::kMaxGrains + Orbix::kStateSize; ++i)
    shared_[i].store(tmp[i], std::memory_order_relaxed);
}

void Engine::getState(float* out, int capacity) const {
  if (!out || capacity <= 0) return;
  float tmp[kStateSize];
  tmp[0] = meterPos_.load(std::memory_order_relaxed);
  tmp[1] = static_cast<float>(meterGrains_.load(std::memory_order_relaxed));
  tmp[2] = meterOut_.load(std::memory_order_relaxed);
  tmp[3] = meterGr_.load(std::memory_order_relaxed);
  tmp[4] = static_cast<float>(recWritten_.load(std::memory_order_relaxed)) /
           static_cast<float>(recordingSampleRate() > 0 ? recordingSampleRate() : 48000.0);
  tmp[5] = meterIn_.load(std::memory_order_relaxed);
  tmp[6] = static_cast<float>(meterVoices_.load(std::memory_order_relaxed));
  tmp[7] = recording_.load(std::memory_order_relaxed) ? 1.f : 0.f;
  tmp[8] = meterLoad_.load(std::memory_order_relaxed);
  tmp[9] = tmp[10] = tmp[11] = 0.f;  // reserved
  for (int i = 0; i < Granular::kMaxGrains + Orbix::kStateSize; ++i)
    tmp[kStateHeader + i] = shared_[i].load(std::memory_order_relaxed);
  const int n = std::min(capacity, static_cast<int>(kStateSize));
  std::memcpy(out, tmp, sizeof(float) * static_cast<size_t>(n));
  for (int i = n; i < capacity; ++i) out[i] = 0.f;
}

}  // namespace gb
