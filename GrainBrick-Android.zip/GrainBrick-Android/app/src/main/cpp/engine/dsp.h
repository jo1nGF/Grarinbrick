// GrainBrick Android - DSP building blocks.
// Original clean-room implementation (see README: this is NOT derived from the
// closed-source TrimUI Brick build).
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

namespace gb {

constexpr float kPi = 3.14159265358979323846f;
constexpr float kTwoPi = 6.28318530717958647692f;

inline float clampf(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline float dbToLin(float db) { return std::exp(db * 0.11512925464970229f); }
inline float linToDb(float x) { return 8.685889638065035f * std::log(x > 1e-9f ? x : 1e-9f); }
inline float semitonesToRatio(float st) { return std::exp2(st * (1.0f / 12.0f)); }
inline float midiToHz(float m) { return 440.0f * std::exp2((m - 69.0f) * (1.0f / 12.0f)); }
inline float smoothstep(float t) { return t * t * (3.0f - 2.0f * t); }
// sin(2*pi*turns) for turns in [0,1): parabolic approximation with one refinement step, error
// below 0.1 %. Plenty for LFOs and about 5x cheaper than std::sin.
inline float fastSinTurns(float turns) {
  float x = turns >= 0.5f ? turns - 1.0f : turns;
  float y = 8.0f * x - 16.0f * x * (x < 0.f ? -x : x);
  return 0.225f * (y * (y < 0.f ? -y : y) - y) + y;
}

// One-pole smoothing coefficient for a time constant (seconds) at a given step rate.
inline float onePoleCoef(float timeSec, float stepHz) {
  if (timeSec <= 1e-6f) return 1.0f;
  return 1.0f - std::exp(-1.0f / (timeSec * stepHz));
}
inline float lowpassCoef(float fc, float sr) {
  fc = clampf(fc, 5.0f, 0.49f * sr);
  return 1.0f - std::exp(-kTwoPi * fc / sr);
}

// Cheap xorshift RNG. Real-time safe, deterministic.
struct Rng {
  uint32_t s;
  explicit Rng(uint32_t seed = 0x9E3779B9u) : s(seed ? seed : 1u) {}
  uint32_t next() {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return s;
  }
  float uni() { return static_cast<float>(next() >> 8) * (1.0f / 16777216.0f); }  // [0,1)
  float bi() { return uni() * 2.0f - 1.0f; }                                       // [-1,1)
};

struct OnePole {
  float y = 0.f;
  inline float lp(float x, float a) { y += a * (x - y); return y; }
  inline float hp(float x, float a) { y += a * (x - y); return x - y; }
  void reset() { y = 0.f; }
};

// RBJ biquad, transposed direct form II.
struct Biquad {
  float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
  float z1 = 0, z2 = 0;
  inline float process(float x) {
    float y = b0 * x + z1;
    z1 = b1 * x - a1 * y + z2;
    z2 = b2 * x - a2 * y;
    return y;
  }
  void reset() { z1 = z2 = 0.f; }
  void setIdentity() { b0 = 1; b1 = b2 = a1 = a2 = 0; }

  void setLowpass(float sr, float f, float q = 0.70710678f) {
    f = clampf(f, 10.f, 0.45f * sr);
    float w = kTwoPi * f / sr, s = std::sin(w), c = std::cos(w);
    float alpha = s / (2.f * q);
    float a0 = 1.f + alpha;
    set((1.f - c) * 0.5f / a0, (1.f - c) / a0, (1.f - c) * 0.5f / a0, (-2.f * c) / a0, (1.f - alpha) / a0);
  }
  void setHighpass(float sr, float f, float q = 0.70710678f) {
    f = clampf(f, 10.f, 0.45f * sr);
    float w = kTwoPi * f / sr, s = std::sin(w), c = std::cos(w);
    float alpha = s / (2.f * q);
    float a0 = 1.f + alpha;
    set((1.f + c) * 0.5f / a0, -(1.f + c) / a0, (1.f + c) * 0.5f / a0, (-2.f * c) / a0, (1.f - alpha) / a0);
  }
  void setPeaking(float sr, float f, float gainDb, float q) {
    f = clampf(f, 10.f, 0.45f * sr);
    float A = std::sqrt(dbToLin(gainDb));
    float w = kTwoPi * f / sr, s = std::sin(w), c = std::cos(w);
    float alpha = s / (2.f * q);
    float a0 = 1.f + alpha / A;
    set((1.f + alpha * A) / a0, (-2.f * c) / a0, (1.f - alpha * A) / a0, (-2.f * c) / a0,
        (1.f - alpha / A) / a0);
  }
  void setLowShelf(float sr, float f, float gainDb, float slope = 0.8f) {
    f = clampf(f, 10.f, 0.45f * sr);
    float A = std::sqrt(dbToLin(gainDb));
    float w = kTwoPi * f / sr, s = std::sin(w), c = std::cos(w);
    float alpha = s * 0.5f * std::sqrt((A + 1.f / A) * (1.f / slope - 1.f) + 2.f);
    float tsa = 2.f * std::sqrt(A) * alpha;
    float a0 = (A + 1.f) + (A - 1.f) * c + tsa;
    set(A * ((A + 1.f) - (A - 1.f) * c + tsa) / a0, 2.f * A * ((A - 1.f) - (A + 1.f) * c) / a0,
        A * ((A + 1.f) - (A - 1.f) * c - tsa) / a0, -2.f * ((A - 1.f) + (A + 1.f) * c) / a0,
        ((A + 1.f) + (A - 1.f) * c - tsa) / a0);
  }
  void setHighShelf(float sr, float f, float gainDb, float slope = 0.8f) {
    f = clampf(f, 10.f, 0.45f * sr);
    float A = std::sqrt(dbToLin(gainDb));
    float w = kTwoPi * f / sr, s = std::sin(w), c = std::cos(w);
    float alpha = s * 0.5f * std::sqrt((A + 1.f / A) * (1.f / slope - 1.f) + 2.f);
    float tsa = 2.f * std::sqrt(A) * alpha;
    float a0 = (A + 1.f) - (A - 1.f) * c + tsa;
    set(A * ((A + 1.f) + (A - 1.f) * c + tsa) / a0, -2.f * A * ((A - 1.f) + (A + 1.f) * c) / a0,
        A * ((A + 1.f) + (A - 1.f) * c - tsa) / a0, 2.f * ((A - 1.f) - (A + 1.f) * c) / a0,
        ((A + 1.f) - (A - 1.f) * c - tsa) / a0);
  }

 private:
  void set(float nb0, float nb1, float nb2, float na1, float na2) {
    b0 = nb0; b1 = nb1; b2 = nb2; a1 = na1; a2 = na2;
  }
};

// Circular delay line with linear-interpolated fractional reads.
class DelayLine {
 public:
  void init(int maxSamples) {
    int n = 16;
    while (n < maxSamples + 4) n <<= 1;
    buf_.assign(static_cast<size_t>(n), 0.f);
    mask_ = n - 1;
    w_ = 0;
  }
  void clear() { std::fill(buf_.begin(), buf_.end(), 0.f); }
  inline void write(float x) {
    buf_[static_cast<size_t>(w_)] = x;
    w_ = (w_ + 1) & mask_;
  }
  // Delay in samples relative to the most recently written sample (0 => last written).
  inline float read(float d) const {
    float rp = static_cast<float>(w_ - 1) - d;
    int i0 = static_cast<int>(std::floor(rp));
    float fr = rp - static_cast<float>(i0);
    float a = buf_[static_cast<size_t>(i0 & mask_)];
    float b = buf_[static_cast<size_t>((i0 + 1) & mask_)];
    return a + (b - a) * fr;
  }
  inline float readInt(int d) const { return buf_[static_cast<size_t>((w_ - 1 - d) & mask_)]; }
  int capacity() const { return mask_ + 1; }

 private:
  std::vector<float> buf_;
  int mask_ = 0;
  int w_ = 0;
};

// Schroeder allpass with fixed integer delay.
class Allpass {
 public:
  void init(int len) {
    len_ = std::max(1, len);
    buf_.assign(static_cast<size_t>(len_), 0.f);
    i_ = 0;
  }
  void clear() { std::fill(buf_.begin(), buf_.end(), 0.f); }
  inline float process(float x, float g) {
    float d = buf_[static_cast<size_t>(i_)];
    float v = x - g * d;
    buf_[static_cast<size_t>(i_)] = v;
    if (++i_ >= len_) i_ = 0;
    return d + g * v;
  }

 private:
  std::vector<float> buf_;
  int len_ = 1;
  int i_ = 0;
};

// Enable flush-to-zero / denormals-are-zero for the calling thread (audio thread).
inline void enableFlushToZero() {
#if defined(__aarch64__)
  uint64_t fpcr;
  __asm__ volatile("mrs %0, fpcr" : "=r"(fpcr));
  fpcr |= (1ULL << 24);  // FZ
  __asm__ volatile("msr fpcr, %0" : : "r"(fpcr));
#elif defined(__SSE__) || defined(__x86_64__)
  unsigned int csr;
  __asm__ volatile("stmxcsr %0" : "=m"(csr));
  csr |= 0x8040;  // FTZ | DAZ
  __asm__ volatile("ldmxcsr %0" : : "m"(csr));
#endif
}

}  // namespace gb
