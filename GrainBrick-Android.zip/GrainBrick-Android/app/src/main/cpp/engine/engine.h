// GrainBrick Android - top level audio engine.
//
// Threading model
//   * UI / JNI threads call setParam(), publishSample(), startRecording(), ... (lock-free or
//     short mutex on non-realtime data only).
//   * The audio thread calls render() only. It never allocates and never takes a lock.
#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <vector>

#include "dsp.h"
#include "fx.h"
#include "granular.h"
#include "orbix.h"
#include "params.h"
#include "reverb.h"

namespace gb {

class Engine {
 public:
  static constexpr int kBlock = 64;             // internal processing block (frames)
  static constexpr int kMaxRecSeconds = 120;
  static constexpr int kStateHeader = 12;
  // State layout (floats), see getState():
  //   [0] playhead 0..1   [1] active grains   [2] output peak   [3] compressor GR (dB, <=0)
  //   [4] recorded seconds [5] input peak     [6] orbix voices  [7] recording flag
  //   [8] DSP load (1.0 = the whole callback budget)  [9..11] reserved
  //   [12 .. 12+64)  grain positions (-1 = inactive)
  //   [76 .. 76+51) orbix state (angle, sides, nBalls, 16 x {x, y, secondsSinceHit})
  // Kotlin mirror: EngineState.kt
  static constexpr int kStateSize = kStateHeader + Granular::kMaxGrains + Orbix::kStateSize;

  Engine();

  // Not realtime: call before the first render() and whenever the stream sample rate changes.
  void prepare(double sampleRate);

  // ---- parameters (any thread) ----
  void setParam(int index, float value);
  float getParam(int index) const;
  void snapParams();  // jump to the targets on the next block instead of gliding

  // ---- sample handling (non-audio thread) ----
  // l/r hold `frames` samples each (r may equal l for mono). Data is copied.
  void publishSample(const float* l, const float* r, int frames, double sampleRate);

  // ---- recording (UI thread starts / stops, the INPUT thread feeds it) ----
  bool startRecording();
  void stopRecording();
  bool isRecording() const { return recording_.load(std::memory_order_relaxed); }
  // Called from the input stream's callback with every captured block (interleaved stereo).
  // Recording is taken straight from the input stream, not from the output callback, so a busy or
  // late output callback (heavy effects, buffer under-runs, clock drift between the two streams)
  // can never drop or repeat captured audio. Lock-free, no allocation.
  void recordInput(const float* interleavedStereo, int frames);
  // The real sample rate of the input stream (0 = same as the output). Recordings are made and
  // saved at this rate, so they always play back at the pitch they were recorded at.
  void setInputSampleRate(int hz) { inRate_.store(hz, std::memory_order_relaxed); }
  int recordedFrames() const {
    return std::min(recWritten_.load(std::memory_order_acquire), recCap_.load(std::memory_order_relaxed));
  }
  // Copies up to maxFrames of the recording into interleaved stereo `dst`; returns frames copied.
  int copyRecording(float* dstInterleaved, int maxFrames) const;
  double recordingSampleRate() const {
    const int r = recRate_.load(std::memory_order_relaxed);
    return r > 0 ? static_cast<double>(r) : sr_;
  }

  // ---- audio thread ----
  // `in` is interleaved stereo or nullptr when no input stream is running.
  void render(float* outInterleaved, int frames, const float* in);

  // ---- UI polling ----
  void getState(float* out, int capacity) const;
  double sampleRate() const { return sr_; }

 private:
  void processBlock(int n, const float* inL, const float* inR, float* outL, float* outR);
  void updateParams(int n);
  void adoptPendingSample();
  void collectGarbage();

  double sr_ = 48000.0;
  bool prepared_ = false;

  // parameters
  std::atomic<float> target_[P_COUNT];
  float cur_[P_COUNT];
  std::atomic<bool> snap_{true};

  // sample hand-over (see publishSample)
  struct Published {
    std::shared_ptr<SampleData> data;
  };
  std::mutex ownMutex_;
  std::vector<Published> owned_;
  uint32_t nextSeq_ = 1;
  std::atomic<const SampleData*> pending_{nullptr};
  std::atomic<uint32_t> ackSeq_{0};
  const SampleData* sample_ = nullptr;

  // DSP
  Granular granular_;
  Roamer roamer_;
  Orbix orbix_;
  Tape tape_;
  Eq6 eq_;
  Compressor comp_;
  StereoDelay delay_;
  Reverb reverb_;
  Shimmer shimmer_;

  // block state
  float playGain_ = 0.f;
  float pitchElastic_ = 0.f;
  float roamOffset_ = 0.f;
  float posNow_ = 0.5f;
  float limGain_ = 1.f;
  float outPeak_ = 0.f, inPeak_ = 0.f;
  std::vector<float> srcL_, srcR_, orbL_, orbR_, busL_, busR_, revInL_, revInR_, tmpL_, tmpR_;
  std::vector<float> inL_, inR_, shimOutL_, shimOutR_;

  // metering (written by audio thread, read by UI)
  std::atomic<float> meterOut_{0.f}, meterIn_{0.f}, meterGr_{0.f}, meterPos_{0.5f};
  std::atomic<float> meterLoad_{0.f};  // fraction of the real-time budget used by render()
  float dspLoad_ = 0.f;
  std::atomic<int> meterGrains_{0}, meterVoices_{0};
  // Grain positions + ORBIX state, published block by block (relaxed atomics: UI may read torn
  // sets of values, never torn floats).
  std::atomic<float> shared_[Granular::kMaxGrains + Orbix::kStateSize];

  // recording
  std::atomic<bool> recording_{false};
  std::atomic<int> recWritten_{0};
  std::atomic<int> recCap_{0};      // frames the recording buffers hold (set by startRecording)
  std::atomic<int> recRate_{0};     // sample rate of the recording in progress / the last one
  std::atomic<int> inRate_{0};      // sample rate of the input stream, 0 = unknown
  std::vector<float> recL_, recR_;
};

}  // namespace gb
