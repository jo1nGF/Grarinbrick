// GrainBrick Android - Oboe audio I/O: one output stream, optional input stream (mic / USB).
#pragma once

#include <cstring>  // Oboe headers use memset() without including it

#include <oboe/Oboe.h>

#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "engine/engine.h"

namespace gb {

// Single-producer / single-consumer ring of interleaved stereo frames.
class StereoRing {
 public:
  void init(size_t minFrames) {
    size_t n = 1024;
    while (n < minFrames) n <<= 1;
    buf_.assign(n * 2, 0.f);
    mask_ = n - 1;
    w_.store(0);
    r_.store(0);
  }
  size_t available() const { return w_.load(std::memory_order_acquire) - r_.load(std::memory_order_acquire); }
  size_t write(const float* src, size_t frames) {  // producer
    size_t w = w_.load(std::memory_order_relaxed);
    size_t room = (mask_ + 1) - (w - r_.load(std::memory_order_acquire));
    if (frames > room) frames = room;
    for (size_t i = 0; i < frames; ++i) {
      size_t k = ((w + i) & mask_) * 2;
      buf_[k] = src[2 * i];
      buf_[k + 1] = src[2 * i + 1];
    }
    w_.store(w + frames, std::memory_order_release);
    return frames;
  }
  size_t read(float* dst, size_t frames) {  // consumer
    size_t r = r_.load(std::memory_order_relaxed);
    size_t avail = w_.load(std::memory_order_acquire) - r;
    if (frames > avail) frames = avail;
    for (size_t i = 0; i < frames; ++i) {
      size_t k = ((r + i) & mask_) * 2;
      dst[2 * i] = buf_[k];
      dst[2 * i + 1] = buf_[k + 1];
    }
    r_.store(r + frames, std::memory_order_release);
    return frames;
  }
  void skip(size_t frames) {  // consumer
    size_t r = r_.load(std::memory_order_relaxed);
    size_t avail = w_.load(std::memory_order_acquire) - r;
    r_.store(r + std::min(frames, avail), std::memory_order_release);
  }

 private:
  std::vector<float> buf_;
  size_t mask_ = 1023;
  std::atomic<size_t> w_{0}, r_{0};
};

class AudioIO {
 public:
  explicit AudioIO(Engine& engine);

  // Opens and starts the streams. Returns an empty string on success or an error description.
  // deviceId 0 means "system default". A missing input is not fatal for the output.
  std::string start(int outputDeviceId, int inputDeviceId, bool useInput);
  void stop();

  bool running() const { return running_.load(); }
  bool inputActive() const { return inputActive_.load(); }
  int sampleRate() const { return sampleRate_.load(); }
  int framesPerBurst() const { return burst_.load(); }
  int inputChannels() const { return inputChannels_.load(); }
  std::string lastMessage() const;

 private:
  class OutCallback;
  class InCallback;
  class ErrCallback;
  friend class OutCallback;
  friend class InCallback;
  friend class ErrCallback;

  std::string startLocked(int outId, int inId, bool useInput);
  void stopLocked();
  void scheduleRestart();
  void setMessage(const std::string& m);

  Engine& engine_;
  std::mutex mutex_;
  std::shared_ptr<oboe::AudioStream> out_, in_;
  std::shared_ptr<OutCallback> outCb_;
  std::shared_ptr<InCallback> inCb_;
  std::shared_ptr<ErrCallback> errCb_;
  StereoRing ring_;
  std::vector<float> scratch_;

  std::atomic<bool> running_{false};
  std::atomic<bool> wantRunning_{false};
  std::atomic<bool> restarting_{false};
  std::atomic<bool> inputActive_{false};
  std::atomic<bool> monitorOk_{true};  // input rate == output rate, so it can be monitored through the ring
  std::atomic<int> sampleRate_{0};
  std::atomic<int> burst_{0};
  std::atomic<int> inputChannels_{0};
  int reqOut_ = 0, reqIn_ = 0;
  bool reqUseInput_ = false;
  mutable std::mutex msgMutex_;
  std::string message_;
};

}  // namespace gb
