// C ABI around SoundTouch. See engine/st_bridge.h. Original code of this project (MIT).
#include "../engine/st_bridge.h"

#include <new>

#include "RateTransposer.h"
#include "SoundTouch.h"

using soundtouch::SoundTouch;

#define GBST_API __attribute__((visibility("default")))

extern "C" {

GBST_API void* gbst_create(unsigned sampleRate, unsigned channels) {
  if (sampleRate < 8000 || sampleRate > 384000 || (channels != 1 && channels != 2)) return nullptr;
  try {
    // Cubic interpolation for the rate change. (Shannon/sinc is slightly cleaner but costs a
    // double-precision sin() per tap, about a quarter of the whole engine; the anti-alias filter
    // in front of the transposer already does the job that matters when shifting up.)
    soundtouch::TransposerBase::setAlgorithm(soundtouch::TransposerBase::CUBIC);
    SoundTouch* st = new SoundTouch();
    st->setSampleRate(sampleRate);
    st->setChannels(channels);
    return st;
  } catch (...) {
    return nullptr;
  }
}

GBST_API void gbst_destroy(void* h) {
  try {
    delete static_cast<SoundTouch*>(h);
  } catch (...) {
  }
}

GBST_API void gbst_clear(void* h) {
  if (!h) return;
  try {
    static_cast<SoundTouch*>(h)->clear();
  } catch (...) {
  }
}

GBST_API void gbst_set_pitch_semitones(void* h, float semitones) {
  if (!h) return;
  try {
    static_cast<SoundTouch*>(h)->setPitchSemiTones(semitones);
  } catch (...) {
  }
}

GBST_API int gbst_set_setting(void* h, int setting, int value) {
  if (!h) return 0;
  try {
    return static_cast<SoundTouch*>(h)->setSetting(setting, value) ? 1 : 0;
  } catch (...) {
    return 0;
  }
}

GBST_API int gbst_get_setting(void* h, int setting) {
  if (!h) return -1;
  try {
    return static_cast<SoundTouch*>(h)->getSetting(setting);
  } catch (...) {
    return -1;
  }
}

GBST_API void gbst_put(void* h, const float* data, unsigned frames) {
  if (!h || !data) return;
  try {
    static_cast<SoundTouch*>(h)->putSamples(data, frames);
  } catch (...) {
  }
}

GBST_API unsigned gbst_receive(void* h, float* data, unsigned maxFrames) {
  if (!h || !data) return 0;
  try {
    return static_cast<SoundTouch*>(h)->receiveSamples(data, maxFrames);
  } catch (...) {
    return 0;
  }
}

GBST_API unsigned gbst_available(void* h) {
  if (!h) return 0;
  try {
    return static_cast<SoundTouch*>(h)->numSamples();
  } catch (...) {
    return 0;
  }
}

}  // extern "C"
