#!/usr/bin/env python3
"""Renders every bundled preset through the real C++ engine and sanity-checks the audio.

Usage: check_presets_audio.py <render-binary> <demo.wav> [seconds]
Checks: finite, no clipping, audible, not silent for the whole render, no huge DC offset,
        and that stereo content is actually stereo.
"""
import glob
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np


def read_wav(path):
    with wave.open(path, "rb") as w:
        ch, sw, n = w.getnchannels(), w.getsampwidth(), w.getnframes()
        assert sw == 2, "expected 16-bit"
        data = np.frombuffer(w.readframes(n), dtype="<i2").astype(np.float32) / 32768.0
    return data.reshape(-1, ch)


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    render, demo = sys.argv[1], sys.argv[2]
    secs = sys.argv[3] if len(sys.argv) > 3 else "25"
    here = os.path.dirname(os.path.abspath(__file__))
    files = sorted(glob.glob(os.path.join(here, "..", "app", "src", "main", "assets", "presets", "*.json")))
    bad = 0
    print(f"{'preset':22s} {'peak dBFS':>9s} {'rms dBFS':>9s} {'late rms':>9s} {'L/R corr':>9s}")
    with tempfile.TemporaryDirectory() as tmp:
        for fn in files:
            out = os.path.join(tmp, "o.wav")
            subprocess.run([render, demo, out, secs, fn], check=True)
            x = read_wav(out)
            problems = []
            if not np.isfinite(x).all():
                problems.append("non-finite samples")
            peak = float(np.abs(x).max())
            rms = float(np.sqrt((x ** 2).mean()))
            late = x[x.shape[0] // 2:]
            late_rms = float(np.sqrt((late ** 2).mean()))
            db = lambda v: 20 * np.log10(max(v, 1e-9))
            if peak >= 0.9999:
                problems.append("hits full scale")
            if db(rms) < -45:
                problems.append("too quiet overall")
            if db(late_rms) < -50:
                problems.append("goes silent in the second half")
            if db(rms) > -8:
                problems.append("too loud")
            dc = abs(float(x.mean()))
            if dc > 0.01:
                problems.append(f"DC offset {dc:.3f}")
            l, r = x[:, 0], x[:, 1]
            corr = float(np.corrcoef(l, r)[0, 1]) if l.std() > 1e-6 and r.std() > 1e-6 else 1.0
            if corr > 0.9995:
                problems.append("effectively mono")
            name = os.path.basename(fn)
            print(f"{name:22s} {db(peak):9.1f} {db(rms):9.1f} {db(late_rms):9.1f} {corr:9.3f}" + ("   <-- " + "; ".join(problems) if problems else ""))
            bad += bool(problems)
    print("OK" if not bad else f"{bad} preset(s) with problems")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
