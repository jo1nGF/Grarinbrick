#!/usr/bin/env python3
"""Checks every bundled preset against the engine's parameter registry.
Usage: validate_presets.py params.tsv [presets_dir]   (params.tsv comes from tests/host/dump_params.cpp)
"""
import glob
import json
import os
import sys


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    reg = {}
    for line in open(sys.argv[1], encoding="utf-8"):
        f = line.rstrip("\n").split("\t")
        if len(f) >= 11:
            reg[f[0]] = (float(f[4]), float(f[5]), int(f[7]))
    here = os.path.dirname(os.path.abspath(__file__))
    pdir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, "..", "app", "src", "main", "assets", "presets")
    files = sorted(glob.glob(os.path.join(pdir, "*.json")))
    errors = []
    names = set()
    if not files:
        errors.append("no presets found in " + pdir)
    for fn in files:
        base = os.path.basename(fn)
        try:
            doc = json.load(open(fn, encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            errors.append(f"{base}: invalid JSON ({e})")
            continue
        if doc.get("format") != 1:
            errors.append(f"{base}: format must be 1")
        name = doc.get("name")
        if not isinstance(name, str) or not name.strip():
            errors.append(f"{base}: missing name")
        elif name in names:
            errors.append(f"{base}: duplicate name {name}")
        names.add(name)
        params = doc.get("parameters")
        if not isinstance(params, dict) or not params:
            errors.append(f"{base}: missing parameters")
            continue
        for k, v in params.items():
            if k not in reg:
                errors.append(f"{base}: unknown parameter {k}")
                continue
            lo, hi, kind = reg[k]
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                errors.append(f"{base}: {k} is not a number")
                continue
            if not (lo - 1e-6 <= v <= hi + 1e-6):
                errors.append(f"{base}: {k}={v} outside [{lo}, {hi}]")
            if kind != 0 and abs(v - round(v)) > 1e-6:
                errors.append(f"{base}: {k}={v} must be an integer (toggle/choice)")
        for k in ("transport.playing", "live.level"):
            if k in params:
                errors.append(f"{base}: presets must not set {k}")
        s = doc.get("sample")
        if s is not None and (s.get("type") not in ("builtin", "relative") or not s.get("path")):
            errors.append(f"{base}: bad sample reference")
    for e in errors:
        print("ERROR:", e)
    print(f"{len(files)} presets checked, {len(errors)} errors")
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
