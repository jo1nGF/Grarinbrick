#!/usr/bin/env python3
"""Generates app/src/main/assets/presets/*.json from the engine's parameter registry.

Every preset starts from the registry defaults and overrides a few values, so presets stay valid
when parameters are added. Usage:
    g++ -std=c++17 tests/host/dump_params.cpp app/src/main/cpp/engine/params.cpp -o /tmp/dump_params
    /tmp/dump_params > /tmp/params.tsv
    python3 tools/make_presets.py /tmp/params.tsv
"""
import json
import os
import sys

EXCLUDED = {"transport.playing", "live.level"}

PRESETS = [
    ("Drift", {
        "grain.density": 40, "grain.size": 1.2, "grain.spray": 0.35, "grain.width": 0.9,
        "motion.reverse": 0.1, "motion.elastic": 0.2, "motion.chaos": 0.05,
        "roam.enabled": 1, "roam.mode": 2, "roam.range": 0.6, "roam.speed": 0.05, "roam.smooth": 0.8, "roam.wander": 0.3,
        "tape.wow": 0.25, "tape.flutter": 0.1, "tape.hiss": 0.02, "tape.saturation": 0.25,
        "comp.reduction": 35, "eq.low": -3, "eq.air": 2,
        "delay.time": 620, "delay.feedback": 0.35, "delay.lowpass": 5000, "delay.mix": 0.22, "delay.pingpong": 0.8, "delay.spread": 0.6,
        "reverb.size": 0.8, "reverb.decay": 9, "reverb.damp": 9000, "reverb.diffuse": 0.8, "reverb.mix": 0.4, "reverb.mod": 0.4, "reverb.predelay": 30,
        "shimmer.mix": 0.2, "shimmer.feedback": 0.45, "shimmer.shift": 12,
    }),
    ("Glass Cathedral", {
        "grain.density": 25, "grain.size": 2.0, "grain.pitch": 12, "grain.spray": 0.5, "grain.width": 1.0,
        "roam.enabled": 1, "roam.mode": 1, "roam.range": 0.8, "roam.speed": 0.03, "roam.smooth": 0.9,
        "tape.enabled": 0, "comp.reduction": 30, "eq.low": -6, "eq.high": 2, "eq.air": 4,
        "delay.time": 900, "delay.feedback": 0.45, "delay.lowpass": 7000, "delay.mix": 0.25, "delay.pingpong": 1.0, "delay.spread": 1.0,
        "reverb.size": 1.0, "reverb.decay": 18, "reverb.damp": 14000, "reverb.diffuse": 0.9, "reverb.mix": 0.55, "reverb.mod": 0.5, "reverb.motion": 0.4, "reverb.predelay": 45,
        "shimmer.mix": 0.6, "shimmer.feedback": 0.7, "shimmer.shift": 19, "shimmer.dual": 1, "shimmer.voice2_level": 0.5, "shimmer.tone": 12000, "shimmer.spread": 0.8,
    }),
    ("Tape Garden", {
        "grain.density": 55, "grain.size": 0.25, "grain.spray": 0.5, "grain.width": 0.8,
        "motion.jump": 0.15, "motion.reverse": 0.25, "motion.chaos": 0.2,
        "tape.wow": 0.5, "tape.flutter": 0.35, "tape.hiss": 0.15, "tape.saturation": 0.5, "tape.crinkle": 0.3, "tape.dropout": 0.2, "tape.bit8": 0.15,
        "comp.reduction": 55, "comp.gain": 4, "eq.low": -4, "eq.high": -5, "eq.air": -8,
        "delay.time": 380, "delay.feedback": 0.5, "delay.lowpass": 3000, "delay.mix": 0.3, "delay.pingpong": 0.4,
        "reverb.size": 0.4, "reverb.decay": 3, "reverb.damp": 6000, "reverb.mix": 0.25,
        "shimmer.mix": 0.0,
    }),
    ("Frozen Pad", {
        "grain.density": 70, "grain.size": 3.0, "grain.position": 0.3, "grain.spray": 0.08, "grain.width": 1.0,
        "motion.hold": 0.9, "motion.elastic": 0.5,
        "roam.enabled": 0,
        "tape.wow": 0.1, "tape.flutter": 0.05, "tape.hiss": 0.0, "tape.saturation": 0.1,
        "comp.reduction": 50, "eq.lmid": -3,
        "delay.mix": 0.1, "delay.time": 700, "delay.feedback": 0.3,
        "reverb.size": 0.9, "reverb.decay": 14, "reverb.mix": 0.5, "reverb.mod": 0.45,
        "shimmer.mix": 0.3, "shimmer.feedback": 0.55, "shimmer.shift": 12,
    }),
    ("Sub Ocean", {
        "grain.density": 30, "grain.size": 2.5, "grain.pitch": -12, "grain.spray": 0.6, "grain.width": 0.9,
        "roam.enabled": 1, "roam.mode": 3, "roam.range": 1.0, "roam.speed": 0.08, "roam.smooth": 0.7, "roam.wander": 0.4,
        "tape.wow": 0.3, "tape.flutter": 0.2, "tape.hiss": 0.05, "tape.saturation": 0.4,
        "comp.reduction": 45, "comp.gain": 3, "eq.low": 4, "eq.lmid": 2, "eq.high": -6, "eq.air": -9,
        "delay.time": 900, "delay.feedback": 0.6, "delay.lowpass": 2500, "delay.mix": 0.3, "delay.pingpong": 1.0, "delay.spread": 0.8,
        "reverb.size": 0.9, "reverb.decay": 12, "reverb.damp": 5000, "reverb.mix": 0.45,
        "shimmer.mix": 0.15, "shimmer.shift": 7, "shimmer.feedback": 0.4,
    }),
    ("Orbix Bells", {
        "grain.density": 20, "grain.size": 2.0, "grain.pitch": -12, "grain.spray": 0.7, "grain.width": 1.0,
        "tape.wow": 0.15, "tape.flutter": 0.1, "tape.saturation": 0.15, "comp.reduction": 35,
        "delay.time": 560, "delay.feedback": 0.4, "delay.mix": 0.25, "delay.pingpong": 1.0, "delay.lowpass": 5000,
        "reverb.size": 0.8, "reverb.decay": 7, "reverb.mix": 0.4,
        "shimmer.mix": 0.3, "shimmer.shift": 12, "shimmer.feedback": 0.5,
        "orbix.enabled": 1, "orbix.volume": 75, "orbix.balls": 5, "orbix.shape": 5, "orbix.gravity": 25, "orbix.bounce": 92,
        "orbix.rotation": 35, "orbix.instrument": 1, "orbix.scale": 1, "orbix.root": 9, "orbix.octave": 0,
        "orbix.attack": 5, "orbix.release": 900, "orbix.reverb": 80,
    }),
    ("Pluck Rain", {
        "grain.enabled": 0,
        "tape.wow": 0.1, "tape.flutter": 0.05, "tape.saturation": 0.1, "comp.reduction": 30,
        "delay.time": 430, "delay.feedback": 0.45, "delay.mix": 0.3, "delay.pingpong": 1.0, "delay.lowpass": 4500,
        "reverb.size": 0.7, "reverb.decay": 6, "reverb.mix": 0.35,
        "shimmer.mix": 0.2, "shimmer.shift": 12,
        "orbix.enabled": 1, "orbix.volume": 85, "orbix.balls": 8, "orbix.shape": 6, "orbix.gravity": 45, "orbix.bounce": 88,
        "orbix.rotation": 20, "orbix.instrument": 2, "orbix.scale": 9, "orbix.root": 2, "orbix.octave": 0,
        "orbix.attack": 3, "orbix.release": 400, "orbix.reverb": 60,
    }),
]


def load_registry(path):
    reg = {}
    for line in open(path, encoding="utf-8"):
        f = line.rstrip("\n").split("\t")
        if len(f) < 11:
            continue
        reg[f[0]] = {"min": float(f[4]), "max": float(f[5]), "def": float(f[6]), "kind": int(f[7])}
    return reg


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    reg = load_registry(sys.argv[1])
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets", "presets")
    os.makedirs(out_dir, exist_ok=True)
    for i, (name, over) in enumerate(PRESETS, 1):
        params = {k: v["def"] for k, v in reg.items() if k not in EXCLUDED}
        for k, v in over.items():
            if k not in reg:
                sys.exit(f"{name}: unknown parameter {k}")
            params[k] = float(v)
        doc = {
            "format": 1,
            "name": name,
            "parameters": {k: params[k] for k in sorted(params)},
            "sample": {"path": "samples/demo-pad.wav", "type": "builtin"},
        }
        fn = os.path.join(out_dir, f"{i:02d}-{name.lower().replace(' ', '-')}.json")
        with open(fn, "w", encoding="utf-8") as fh:
            json.dump(doc, fh, indent=2)
            fh.write("\n")
        print("wrote", os.path.relpath(fn))


if __name__ == "__main__":
    main()
