# GrainBrick para Android

Instrumento de **som ambiente granular** para Android: carrega (ou grava) um sample, transforma em nuvens de grãos e passa por fita, EQ, compressor, delay, reverb, shimmer e o gerador de notas **ORBIX** (bolinhas quicando dentro de um polígono giratório). O APK é compilado pelo **GitHub Actions**.

> **Aviso importante – projeto "clean-room", não afiliado.**
> Este app é uma **reimplementação independente**, escrita do zero para Android, inspirada nas funções descritas publicamente no README do *GrainBrick 1.0.0‑beta.1* (TrimUI Brick / KNULLI) e no formato do projeto `AMBIENT.json`. O app original é de código fechado; **nenhum código, binário, áudio ou preset dele foi copiado ou decompilado**. Este repositório **não tem ligação** com o autor original.
> Se você **não** é o autor do GrainBrick original, peça autorização antes de distribuir publicamente com este nome (ou renomeie: o nome de exibição está em `app/src/main/res/values/strings.xml` e o `applicationId` em `app/build.gradle.kts`).

## O que ele faz

A interface imita o visor de um instrumento: texto monoespaçado em maiúsculas, vidro escuro com moldura fina, cursor âmbar e traço ciano para o áudio. Tudo é uma lista de linhas tipo LCD: toque numa linha para selecioná-la (aparece o cursor `>` e o texto de ajuda na barra de baixo), **arraste na horizontal** para mudar o valor (dois dedos = ajuste fino), **toque duplo** volta ao padrão, toque nos itens ON/OFF para alternar. Escolhas (bolinhas, lados, escala, voz…) também são sliders em passos: arraste na horizontal ou toque na metade direita/esquerda da linha. No topo ficam o nome do projeto (toque para ir a SAVE), a carga de DSP em %, o medidor de saída e o botão PLAY/STOP.

| Aba | Conteúdo |
| --- | --- |
| **SAMPLE** | Importar áudio (WAV, e MP3/OGG/AAC/FLAC etc. via decodificador do Android), gravar do microfone/entrada USB (RECORD/STOP), cortar início/fim (SAVE TRIM), escolher dispositivos de saída/entrada e o sample demo embutido (gerado por código). |
| **GRAIN** | Waveform em ciano com a posição de leitura, a janela do grão (colchetes âmbar) e um traço por grão ativo; pad XY (posição × tamanho/pitch/densidade/spray); listas GRAIN, ROAM e MOTION. |
| **FX** | EQ (6 bandas), COMP, DELAY (ping‑pong), REVERB (FDN de 8 linhas) e SHIMMER, uma seção por vez. |
| **TAPE** | Dois carretéis animados (a velocidade oscila com WOW e FLUTTER) e os knobs da fita. |
| **ORBIX** | Visualização das bolinhas e do polígono; 4 vozes (Glass, Bell/FM, Pluck/Karplus‑Strong, Sample) e 10 escalas. |
| **SETUP** | Níveis (entrada, master, live), tempos de suavização, estado do áudio e carga de DSP. |
| **SAVE** | 7 presets embutidos, salvar/abrir/apagar projetos, importar/exportar `.json` (compatível com o formato de projeto do GrainBrick original; chaves como `grain.size`). |

**Gravação:** a captura vem direto do stream de entrada (não do callback de saída), então carga alta de DSP ou diferença de clock entre os dois streams não cortam o áudio gravado. Ao parar, o app remove o *DC offset*, recusa takes silenciosos (e avisa), sobe takes baixos até ≈ −1 dBFS (no máximo +24 dB) e aplica fades de 4 ms nas pontas. O sample é salvo na taxa real da entrada.

**Shimmer** (modelado segundo o manual do Valhalla Shimmer): o shimmer *é* o reverb, cuja cauda é refeita a partir de cópias transpostas de si mesma (SoundTouch, +12 st por padrão), então a energia sobe em oitavas (nota, +1, +2, +3…) até o passa‑baixa do laço encerrar a escada. Feedback ≥ 0,5 já dá o shimmer clássico. Controles: MIX, FEEDBACK, SHIFT, DUAL (uma voz sobe e outra desce), VOICE 2, TONE (corte agudo do laço), LOW CUT, SIZE, DIFFUSION, MOD, SPREAD e SMOOTH. O laço é limitado por saturação suave e foi medido estável até feedback 0,95 com acorde contínuo.

Detalhes técnicos:

* Motor de áudio em **C++17** (`app/src/main/cpp/engine`), sem alocação nem locks no callback de áudio, saída via **Oboe** (incluído em `third_party/oboe`, Apache‑2.0).
* Interface **100 % views nativas** (sem AndroidX/Compose), nenhuma dependência Maven além do plugin do Android/Kotlin.
* **SoundTouch 2.3.2** (LGPL‑2.1, `third_party/soundtouch`, com pequenas alterações listadas em `MODIFICATIONS.txt` para não alocar memória no thread de áudio) é compilado como biblioteca separada (`libSoundTouch.so`) e usado só pela ponte C `gbst_*`; dá para trocá‑la por outra build do SoundTouch, como a LGPL pede.
* Áudio continua com a tela desligada (serviço em primeiro plano com notificação). O microfone só funciona com o app aberto (regra do Android).
* Android 8.0+ (API 26), ABIs `arm64-v8a`, `armeabi-v7a`, `x86_64`; ELF com páginas de 16 KB.
* Samples importados são limitados a **90 s**; gravações a **120 s**.

## Como gerar o APK pelo GitHub

1. Crie um repositório vazio no GitHub e envie este projeto:
   ```bash
   cd GrainBrick-Android
   git init -b main
   git add .
   git commit -m "GrainBrick para Android"
   git remote add origin https://github.com/<seu-usuario>/<seu-repo>.git
   git push -u origin main
   ```
2. Abra a aba **Actions**. O workflow **Android** roda sozinho a cada push (também dá para disparar manualmente em *Run workflow*):
   * `engine-tests`: compila e testa o motor de áudio no próprio runner e valida os presets;
   * `apk`: instala SDK 36 + NDK 28 + CMake, roda `./gradlew assembleDebug assembleRelease` e publica o artefato **GrainBrick-APKs**.
3. Baixe o zip do artefato no fim da execução, extraia e instale `GrainBrick-<versão>-debug.apk` (ou `-release.apk`) no celular (permita "instalar apps desconhecidos").
4. **Release automática:** crie uma tag `vX.Y.Z` (`git tag v1.0.0-beta.1 && git push --tags`) e os APKs são anexados a uma Release do GitHub.

### Assinatura própria (opcional, recomendado para atualizar o app sem desinstalar)

Sem configuração, o APK *release* é assinado com a chave de debug (instala, mas a chave muda a cada runner). Para uma chave fixa:

```bash
keytool -genkeypair -v -keystore release.keystore -alias grainbrick -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.keystore      # copie a saída
```

Em *Settings → Secrets and variables → Actions* crie: `GB_KEYSTORE_BASE64` (a saída acima), `GB_KEYSTORE_PASSWORD`, `GB_KEY_ALIAS` e `GB_KEY_PASSWORD`. **Guarde o keystore em local seguro e nunca o envie ao repositório.**

## Compilar localmente

Requisitos: JDK 17, Android SDK (plataforma 36, build‑tools 35.0.0), NDK 28.2.13676358 e CMake 3.22.1.

```bash
./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
```

Testes que rodam sem Android:

```bash
# motor C++ (sinais sintéticos, fuzz de parâmetros, threads, shimmer, gravação, alocações no thread de áudio)
tests/host/build.sh build engine_test && build/engine_test

# registro de parâmetros + validação dos presets
tests/host/build.sh build dump_params
build/dump_params > build/params.tsv && python3 tools/validate_presets.py build/params.tsv

# renderização offline (ouvir presets no PC) e métricas do shimmer
tests/host/build.sh build render shimmer_eval shimmer_tail
build/shimmer_tail shimmer.feedback=0.7      # mostra a energia da cauda subindo de oitava em oitava
```

Os testes de lógica Kotlin (`tests/kotlin/UnitTests.kt`: JSON, WAV, projetos, registro de parâmetros) rodam na JVM com `kotlinc`; o cabeçalho do arquivo mostra o comando.

## Estrutura

```
app/src/main/cpp/engine/   motor DSP (granular, fita, EQ, comp, delay, reverb, shimmer, ORBIX)
app/src/main/cpp/          Oboe I/O + ponte JNI
app/src/main/java/…/       app Kotlin (UI em views, sessão, serviço, importação/gravação)
app/src/main/assets/presets/   presets embutidos (gerados por tools/make_presets.py)
third_party/oboe/          Oboe 1.11.0 (Apache‑2.0)
third_party/soundtouch/    SoundTouch 2.3.2 (LGPL‑2.1)
tests/ tools/              testes e utilitários
.github/workflows/         CI
```

O registro de parâmetros (`engine/params.h`) é a **única fonte de verdade**: nomes, faixas, padrões e textos de ajuda. O Kotlin lê tudo via JNI, então adicionar um parâmetro exige mexer só no C++ (e no DSP que o usa).

## Limitações conhecidas

* **Não foi testado em aparelho real** por quem escreveu o código: o ambiente de desenvolvimento não tinha o Android SDK, então o motor e a lógica foram verificados por testes no PC, mas **a primeira execução do GitHub Actions pode revelar ajustes de build** (versões de AGP/NDK, por exemplo). Se falhar, abra o log do job `apk` e corrija o ponto indicado.
* Interface em inglês; layout pensado para celular (toque), sem suporte a gamepad. A interface só foi verificada por compilação: ainda não foi vista rodando num aparelho.
* O shimmer foi ajustado por **medições** (escada de oitavas na cauda, estabilidade, centroide, aspereza), não de ouvido: se algo soar áspero ou fraco, ajuste TONE, FEEDBACK, SIZE e SMOOTH, ou me diga o que ouviu.
* O som não é idêntico ao do GrainBrick original (os algoritmos são independentes); projetos do original abrem e mapeiam os parâmetros, mas o resultado soará diferente.

## Licença

MIT (veja `LICENSE`; ajuste o titular dos direitos autorais). Bibliotecas de terceiros (Oboe, SoundTouch) em `THIRD_PARTY_NOTICES.md`.
