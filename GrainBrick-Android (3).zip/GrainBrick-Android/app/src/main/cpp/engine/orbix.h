// GrainBrick Android - ORBIX generative note engine.
//
// Balls bounce around inside a rotating regular polygon. Every wall impact plays a note whose
// pitch depends on the wall and on where along the wall the ball hit; loudness follows the impact
// speed. Rotating walls inject energy so the system keeps moving.
#pragma once

#include "dsp.h"
#include "granular.h"
#include "rings_res.h"

namespace gb {

struct OrbixCtl {
  bool enabled = false;
  bool spawn = true;     // false => no new notes (running ones ring out)
  float volume = 0.6f;   // 0..1
  float gravity = 0.2f;  // 0..1
  float bounce = 0.9f;   // 0..1
  float rotation = 0.3f; // 0..1
  int balls = 4;
  int shape = 4;
  int instrument = 1;    // 0 glass, 1 bell, 2 pluck, 3 sample, 4 pad, 5 organ, 6 fm, 7 mini, 8 modal, 9 rings resonator
  int scale = 0;
  int root = 0;
  int octave = 0;
  float attackMs = 30.f;
  float releaseMs = 300.f;
  float samplePos = 0.5f;
  // FM voice
  int fmRatio = 1;       // index into kFmRatios
  float fmIndex = 0.4f, fmDecayMs = 600.f, fmFeedback = 0.f;
  // mini synth voice (pulse / saw / triangle through a low-pass)
  float pswShape = 0.5f, pswWidth = 0.5f, pswDetuneCents = 8.f, pswCutoff = 1800.f, pswRes = 0.2f, pswEnv = 0.5f;
  // modal voice (physical model)
  // RINGS ORBIX (instrument 9): resonator model, see rings_res.h
  RingsCtl rings;
  float mExciter = 0.f, mHardness = 0.55f, mGeometry = 0.33f, mBright = 0.6f, mDamp = 0.45f, mPos = 0.25f;
};

class Orbix {
 public:
  static constexpr int kMaxBalls = 16;
  static constexpr int kMaxVoices = 16;
  static constexpr int kKsMax = 4096;
  static constexpr int kModes = 12;
  // Layout of getState(): [angle, shape, nBalls, then per ball: x, y, flashSeconds]
  static constexpr int kStateSize = 3 + kMaxBalls * 3;

  /// withRings: also allocate the resonator pool of the RINGS ORBIX (instrument 9).
  void prepare(double sampleRate, bool withRings = false) {
    sr_ = static_cast<float>(sampleRate);
    if (withRings) rings_.prepare(sr_);
    reset();
  }
  void reset() {
    for (auto& v : voices_) v.active = false;
    rings_.reset();
    nBalls_ = 0;
    angle_ = 0.f;
    acc_ = 0.f;
    shape_ = 4;
  }
  void setSample(const SampleData* s) {
    sample_ = s;
    for (auto& v : voices_) if (v.type == 3) v.active = false;
  }

  void process(const OrbixCtl& c, float* outL, float* outR, int n) {
    if (c.enabled && c.spawn) {
      simulate(c, static_cast<float>(n) / sr_);
    }
    for (auto& v : voices_) {
      if (v.active) renderVoice(v, outL, outR, n, c.volume);
    }
    if (rings_.ready()) rings_.render(outL, outR, n, c.volume);
  }

  void getState(float* out) const {
    out[0] = angle_;
    out[1] = static_cast<float>(shape_);
    out[2] = static_cast<float>(nBalls_);
    for (int i = 0; i < kMaxBalls; ++i) {
      if (i < nBalls_) {
        out[3 + i * 3] = balls_[i].x;
        out[4 + i * 3] = balls_[i].y;
        out[5 + i * 3] = balls_[i].sinceHit;
      } else {
        out[3 + i * 3] = out[4 + i * 3] = 0.f;
        out[5 + i * 3] = 99.f;
      }
    }
  }
  /// Plays one note directly (tests and previews). vel is the impact speed: 1.5 = full strength.
  void playNote(const OrbixCtl& c, float midi, float vel, float pan) {
    startVoice(c, clampf(midiToHz(midi), 25.f, 0.45f * sr_), vel, pan);
  }
  int activeVoices() const {
    int c = 0;
    for (const auto& v : voices_) c += v.active ? 1 : 0;
    return c + rings_.activeCount();
  }

 private:
  struct Ball {
    float x = 0, y = 0, vx = 0, vy = 0;
    float cooldown = 0.f, sinceHit = 99.f, rest = 0.f;
  };
  struct Voice {
    bool active = false;
    int type = 0;
    float freq = 440.f, amp = 0.f, gL = 1.f, gR = 1.f;
    int age = 0, attackN = 1, gateN = 1, releaseN = 1;
    float ph1 = 0.f, ph2 = 0.f, phm = 0.f;
    // bell: running exponential envelopes (avoids exp() per sample)
    float bIdx = 0.f, bAmp = 0.f, bIdxD = 1.f, bAmpD = 1.f;
    // pluck (Karplus-Strong with allpass tuning)
    float ks[kKsMax];
    int ksLen = 1, ksIdx = 0;
    float ksPrev = 0.f, apC = 0.f, apX = 0.f, apY = 0.f, decay = 0.99f;
    // sample voice
    double pos = 0.0, inc = 1.0;
    // fm voice (reuses bIdx/bAmp/bAmpD for the index envelope)
    float fmRatio = 1.f, fmFb = 0.f, fmPrev = 0.f, fmIdx0 = 0.f;
    // mini synth voice
    float inc1 = 0.f, inc2 = 0.f, pwWidth = 0.5f, pwShape = 0.5f;
    float fcBase = 1000.f, fcAmt = 0.f, fcEnv = 1.f, fcEnvD = 1.f, svK = 1.f, svComp = 1.f;
    float svA1 = 0.f, svA2 = 0.f, svA3 = 0.f, svI1 = 0.f, svI2 = 0.f;
    // modal voice: a bank of two-pole resonators driven by a strike and / or a bow
    int nModes = 0, strikeN = 0, strikeI = 0;
    float mA1[kModes], mR2[kModes], mB0[kModes], mAmp[kModes], mBowT[kModes], mBowN[kModes], mY1[kModes], mY2[kModes];
    float strikeAmp = 0.f, bowAmp = 0.f, bowNoise = 0.f, bowPh = 0.f, bowInc = 0.f;
  };

  static const int* scaleIntervals(int scale, int& len) {
    static const int s0[] = {0, 3, 5, 7, 10};
    static const int s1[] = {0, 2, 4, 7, 9};
    static const int s2[] = {0, 2, 4, 5, 7, 9, 11};
    static const int s3[] = {0, 2, 3, 5, 7, 8, 10};
    static const int s4[] = {0, 2, 3, 5, 7, 9, 10};
    static const int s5[] = {0, 2, 4, 6, 7, 9, 11};
    static const int s6[] = {0, 2, 4, 5, 7, 9, 10};
    static const int s7[] = {0, 1, 3, 5, 7, 8, 10};
    static const int s8[] = {0, 2, 4, 6, 8, 10};
    static const int s9[] = {0, 2, 3, 7, 8};
    switch (scale) {
      default:
      case 0: len = 5; return s0;
      case 1: len = 5; return s1;
      case 2: len = 7; return s2;
      case 3: len = 7; return s3;
      case 4: len = 7; return s4;
      case 5: len = 7; return s5;
      case 6: len = 7; return s6;
      case 7: len = 7; return s7;
      case 8: len = 6; return s8;
      case 9: len = 5; return s9;
    }
  }

  void syncBalls(const OrbixCtl& c) {
    const int want = std::max(1, std::min(kMaxBalls, c.balls));
    while (nBalls_ < want) {
      Ball& b = balls_[nBalls_++];
      float a = rng_.uni() * kTwoPi, r = 0.55f * std::sqrt(rng_.uni());
      b.x = r * std::cos(a);
      b.y = r * std::sin(a);
      float sp = 0.5f + 0.6f * rng_.uni(), d = rng_.uni() * kTwoPi;
      b.vx = sp * std::cos(d);
      b.vy = sp * std::sin(d);
      b.cooldown = 0.f;
      b.sinceHit = 99.f;
      b.rest = 0.f;
    }
    if (nBalls_ > want) nBalls_ = want;
    if (c.shape != shape_) {
      shape_ = std::max(3, std::min(8, c.shape));
      for (int i = 0; i < nBalls_; ++i) {  // pull everyone safely inside the new arena
        balls_[i].x *= 0.6f;
        balls_[i].y *= 0.6f;
      }
    }
  }

  void simulate(const OrbixCtl& c, float dtBlock) {
    syncBalls(c);
    const float omega = c.rotation * 1.6f;
    const float g = c.gravity * 2.5f;
    const float e = 0.6f + 0.4f * c.bounce;
    const float apothem = std::cos(kPi / static_cast<float>(shape_));
    const float halfEdge = apothem * std::tan(kPi / static_cast<float>(shape_));
    const float rb = 0.05f;
    const float dt = 1.0f / 480.0f;

    acc_ += dtBlock;
    int guard = 0;
    while (acc_ >= dt && guard++ < 64) {
      acc_ -= dt;
      angle_ += omega * dt;
      if (angle_ > kTwoPi) angle_ -= kTwoPi;
      for (int bi = 0; bi < nBalls_; ++bi) {
        Ball& b = balls_[bi];
        b.vy -= g * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.cooldown -= dt;
        b.sinceHit += dt;
        for (int ei = 0; ei < shape_; ++ei) {
          float ang = angle_ + kTwoPi * static_cast<float>(ei) / static_cast<float>(shape_);
          float nx = std::cos(ang), ny = std::sin(ang);
          float pen = b.x * nx + b.y * ny + rb - apothem;
          if (pen <= 0.f) continue;
          b.x -= pen * nx;
          b.y -= pen * ny;
          float wvx = -omega * b.y, wvy = omega * b.x;
          float rvx = b.vx - wvx, rvy = b.vy - wvy;
          float vn = rvx * nx + rvy * ny;
          if (vn <= 0.f) continue;
          rvx -= (1.0f + e) * vn * nx;
          rvy -= (1.0f + e) * vn * ny;
          b.vx = rvx + wvx;
          b.vy = rvy + wvy;
          if (vn > 0.06f && b.cooldown <= 0.f) {
            float s = b.x * (-ny) + b.y * nx;
            float u = clampf(0.5f + s / (2.0f * halfEdge), 0.f, 0.999f);
            trigger(c, ei, u, vn, b.x);
            b.cooldown = 0.07f;
            b.sinceHit = 0.f;
          }
        }
        float sp2 = b.vx * b.vx + b.vy * b.vy;
        if (sp2 > 16.f) { b.vx *= 0.5f; b.vy *= 0.5f; }
        // Keep the piece alive: a ball that has come to rest gets a kick.
        if (sp2 < 0.02f) {
          b.rest += dt;
          if (b.rest > 1.0f) {
            float d = rng_.uni() * kTwoPi;
            b.vx = 0.7f * std::cos(d);
            b.vy = 0.7f * std::sin(d) + 0.5f;
            b.rest = 0.f;
          }
        } else {
          b.rest = 0.f;
        }
      }
    }
  }

  void trigger(const OrbixCtl& c, int edge, float u, float vn, float x) {
    int sl = 0;
    const int* iv = scaleIntervals(c.scale, sl);
    int k = (edge * 3 + static_cast<int>(u * 3.0f)) % (sl * 2);
    int semis = iv[k % sl] + 12 * (k / sl);
    float midi = 60.f + static_cast<float>(c.root + 12 * c.octave + semis);
    float freq = clampf(midiToHz(midi), 25.f, 0.45f * sr_);
    startVoice(c, freq, vn, x);
  }

  static float lerpf(float a, float b, float t) { return a + (b - a) * t; }

  void startVoice(const OrbixCtl& c, float freq, float vn, float x) {
    if (c.instrument == 9) {
      rings_.note(c.rings, freq, vn, x);
      return;
    }
    Voice* v = nullptr;
    int oldest = 0, oldestAge = -1;
    for (int i = 0; i < kMaxVoices; ++i) {
      if (!voices_[i].active) { v = &voices_[i]; break; }
      if (voices_[i].age > oldestAge) { oldestAge = voices_[i].age; oldest = i; }
    }
    if (!v) v = &voices_[oldest];

    const int type = std::max(0, std::min(8, c.instrument));
    static const float kGate[9] = {0.8f, 2.5f, 3.0f, 0.6f, 3.2f, 2.4f, 2.0f, 1.6f, 2.6f};
    v->active = true;
    v->type = type;
    v->freq = freq;
    v->age = 0;
    v->amp = 0.25f + 0.75f * clampf(vn / 1.5f, 0.f, 1.f);
    v->attackN = std::max(1, static_cast<int>(c.attackMs * 0.001f * sr_));
    v->gateN = v->attackN + static_cast<int>(kGate[type] * sr_);
    v->releaseN = std::max(1, static_cast<int>(c.releaseMs * 0.001f * sr_));
    float pan = clampf(x * 0.8f, -1.f, 1.f);
    float th = (pan + 1.0f) * kPi * 0.25f;
    v->gL = std::cos(th) * 1.41421356f;
    v->gR = std::sin(th) * 1.41421356f;
    v->ph1 = v->ph2 = v->phm = 0.f;
    v->bIdx = 2.5f;
    v->bAmp = 1.f;
    v->bIdxD = std::exp(-1.0f / (0.4f * sr_));
    v->bAmpD = std::exp(-1.0f / (0.9f * sr_));

    if (type == 6) {
      static const float kRatios[8] = {0.5f, 1.f, 1.5f, 2.f, 3.f, 4.f, 5.f, 7.f};
      v->fmRatio = kRatios[std::max(0, std::min(7, c.fmRatio))];
      v->fmFb = c.fmFeedback * 2.0f;
      v->fmPrev = 0.f;
      const float vel01 = clampf((v->amp - 0.25f) / 0.75f, 0.f, 1.f);
      v->fmIdx0 = 10.f * c.fmIndex * c.fmIndex * (0.5f + 0.5f * vel01);
      v->bAmp = 1.f;
      v->bAmpD = std::exp(-1.0f / (std::max(5.f, c.fmDecayMs) * 0.001f * sr_));
    } else if (type == 7) {
      const float det = std::pow(2.f, c.pswDetuneCents / 2400.f);
      v->inc1 = std::min(0.49f, freq * det / sr_);
      v->inc2 = std::min(0.49f, freq / det / sr_);
      v->ph1 = rng_.uni();
      v->ph2 = rng_.uni();
      v->pwShape = clampf(c.pswShape, 0.f, 1.f);
      v->pwWidth = clampf(c.pswWidth, 0.05f, 0.95f);
      v->fcBase = c.pswCutoff * std::pow(freq / 261.6256f, 0.5f);
      v->fcAmt = 4.f * clampf(c.pswEnv, 0.f, 1.f);
      v->fcEnv = 1.f;
      v->fcEnvD = std::exp(-1.0f / (std::max(0.08f, c.releaseMs * 0.001f) * sr_));
      v->svK = 1.6f * (1.f - clampf(c.pswRes, 0.f, 0.97f)) + 0.08f;
      v->svComp = 1.f / (1.f + 0.5f * clampf(c.pswRes, 0.f, 0.97f));
      v->svI1 = v->svI2 = 0.f;
      updateSvf(*v);
    } else if (type == 8) {
      initModal(*v, c, freq);
    }

    if (type == 2) {
      float P = sr_ / freq;
      int L = std::max(2, std::min(kKsMax - 1, static_cast<int>(std::floor(P - 1.0f))));
      float d = P - 0.5f - static_cast<float>(L);
      v->ksLen = L;
      v->ksIdx = 0;
      v->ksPrev = v->apX = v->apY = 0.f;
      v->apC = (1.0f - d) / (1.0f + d);
      v->decay = std::exp(-6.907755f / (3.0f * freq));
      float lp = 0.f, mean = 0.f;
      for (int i = 0; i < L; ++i) {
        lp += 0.45f * (rng_.bi() - lp);
        v->ks[i] = lp;
        mean += lp;
      }
      mean /= static_cast<float>(L);
      for (int i = 0; i < L; ++i) v->ks[i] -= mean;
    } else if (type == 3) {
      float ratio = freq / 261.6256f;
      double srcStep = static_cast<double>(ratio) * (sample_ ? sample_->sampleRate : sr_) / sr_;
      v->inc = srcStep;
      double N = sample_ ? static_cast<double>(sample_->frames) : 1.0;
      double span = srcStep * (kGate[3] + c.releaseMs * 0.001f + 0.1f) * sr_;
      double start = static_cast<double>(c.samplePos) * (N - 1.0);
      v->pos = std::min(std::max(0.0, start), std::max(0.0, N - 2.0 - span));
    }
  }

  void updateSvf(Voice& v) const {
    float fc = v.fcBase * std::exp2(v.fcAmt * v.fcEnv);
    fc = clampf(fc, 20.f, 0.45f * sr_);
    const float g = std::tan(kPi * fc / sr_);
    v.svA1 = 1.f / (1.f + g * (g + v.svK));
    v.svA2 = g * v.svA1;
    v.svA3 = g * v.svA2;
  }

  // Mode ratios / levels of the four body types the geometry control morphs between:
  // string (harmonic), tine (e-piano: fundamental, pickup 2nd and 3rd, the 6.27x bar mode), free bar
  // (marimba / vibraphone) and bell.
  static const float* modeRatios(int body) {
    static const float r[4][kModes] = {
        {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12},
        {1, 2, 3, 6.27f, 8.1f, 10.f, 12.5f, 17.55f, 21.f, 25.f, 30.f, 34.4f},
        {1, 2.756f, 5.404f, 8.933f, 13.344f, 18.638f, 24.81f, 31.87f, 39.8f, 48.6f, 58.3f, 68.9f},
        {1, 1.2f, 1.5f, 2.f, 2.5f, 3.f, 3.7f, 4.2f, 5.1f, 6.f, 7.2f, 8.5f}};
    return r[body];
  }
  static const float* modeLevels(int body) {
    static const float a[4][kModes] = {
        {1, .5f, .333f, .25f, .2f, .167f, .143f, .125f, .111f, .1f, .091f, .083f},
        {1, .3f, .1f, .7f, .06f, .05f, .03f, .15f, .03f, .02f, .015f, .01f},
        {1, .9f, .6f, .4f, .25f, .18f, .12f, .09f, .07f, .05f, .04f, .03f},
        {1, .7f, .6f, .7f, .4f, .3f, .25f, .2f, .15f, .12f, .1f, .08f}};
    return a[body];
  }

  void initModal(Voice& v, const OrbixCtl& c, float freq) {
    const float vel01 = clampf((v.amp - 0.25f) / 0.75f, 0.f, 1.f);
    const float g = clampf(c.mGeometry, 0.f, 1.f) * 3.f;
    const int gi = std::min(2, static_cast<int>(g));
    float gf = g - static_cast<float>(gi);
    gf = gf * gf * (3.f - 2.f * gf);  // linger on each body type, so the named ones are clean
    const float bright = clampf(c.mBright, 0.f, 1.f);
    const float bq = 0.25f + 0.75f * bright;
    const float alpha = 0.2f + 1.8f * (1.f - bright);
    float t0 = 10.f * std::pow(0.025f, clampf(c.mDamp, 0.f, 1.f));
    t0 *= clampf(std::pow(261.6256f / freq, 0.35f), 0.4f, 3.f);
    const float posn = 0.04f + 0.46f * clampf(c.mPos, 0.f, 1.f);

    float energy = 0.f;
    int n = 0;
    for (int j = 0; j < kModes; ++j) {
      const float ratio = lerpf(modeRatios(gi)[j], modeRatios(gi + 1)[j], gf);
      const float f = freq * ratio;
      if (f > 0.45f * sr_) continue;
      float amp = lerpf(modeLevels(gi)[j], modeLevels(gi + 1)[j], gf);
      amp *= 0.2f + 0.8f * std::fabs(std::sin(kPi * static_cast<float>(j + 1) * posn));
      amp *= std::pow(bq, std::log2(ratio));
      float t60 = std::min(12.f, std::max(0.02f, t0 * std::pow(ratio, -alpha)));
      const float r = std::exp(-6.9078f / (t60 * sr_));
      const float w = kTwoPi * f / sr_;
      v.mA1[n] = 2.f * r * std::cos(w);
      v.mR2[n] = r * r;
      v.mB0[n] = std::sin(w);
      v.mAmp[n] = amp;
      // A resonator's gain at its own frequency is 1 / (2 (1 - r)): a periodic bow is scaled by
      // (1 - r) so every mode ends up near its strike level, a noisy bow by sqrt(1 - r).
      v.mBowT[n] = 3.f * (1.f - r);
      v.mBowN[n] = 0.6f * std::sqrt(2.f * (1.f - r));
      v.mY1[n] = v.mY2[n] = 0.f;
      energy += amp * amp;
      ++n;
    }
    v.nModes = n;
    const float norm = kModalGain / std::sqrt(std::max(1e-6f, energy));
    for (int j = 0; j < n; ++j) v.mAmp[j] *= norm;

    const float ex = clampf(c.mExciter, 0.f, 1.f);
    const float hard = clampf(c.mHardness, 0.f, 1.f);
    // A hit is a short half-sine of constant area: harder / faster = shorter = brighter.
    float len = 0.00015f * sr_ * std::pow(27.f, 1.f - hard) * (1.4f - 0.8f * vel01);
    v.strikeN = std::max(4, static_cast<int>(len));
    v.strikeI = 0;
    v.strikeAmp = clampf(2.f * (1.f - ex), 0.f, 1.f) * (kPi * 0.5f) / static_cast<float>(v.strikeN);
    v.bowAmp = clampf(2.f * ex, 0.f, 1.f);
    v.bowNoise = 0.1f + 0.6f * hard;
    v.bowPh = 0.f;
    v.bowInc = freq / sr_;
  }

  static constexpr float kModalGain = 1.2f;

  static float polyBlep(float t, float dt) {
    if (t < dt) { t /= dt; return t + t - t * t - 1.f; }
    if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
    return 0.f;
  }
  // Pulse (0) -> saw (0.5) -> triangle (1), each trimmed to a similar loudness. Pulse and saw are
  // band-limited with PolyBLEP; the triangle's harmonics fall off fast enough on their own.
  static float pswWave(float p, float dt, float shape, float width) {
    float pulse = 0.f, saw = 0.f, tri = 0.f;
    if (shape < 0.999f) {
      saw = (2.f * p - 1.f) - polyBlep(p, dt);
      if (shape < 0.5f) {
        float q = p - width;
        if (q < 0.f) q += 1.f;
        pulse = (p < width ? 1.f : -1.f) + polyBlep(p, dt) - polyBlep(q, dt);
      }
    }
    if (shape > 0.5f) tri = 4.f * std::fabs(p - 0.5f) - 1.f;
    if (shape <= 0.5f) {
      const float t = shape * 2.f;
      return (1.f - t) * 0.5f * pulse + t * 0.87f * saw;
    }
    const float t = (shape - 0.5f) * 2.f;
    return (1.f - t) * 0.87f * saw + t * 0.87f * tri;
  }

  void renderVoice(Voice& v, float* outL, float* outR, int n, float volume) {
    const float inv2pi = 1.0f / sr_;
    const float master = volume * 0.35f;
    for (int i = 0; i < n; ++i) {
      float env;
      if (v.age < v.attackN) env = static_cast<float>(v.age) / static_cast<float>(v.attackN);
      else if (v.age < v.gateN) env = 1.f;
      else if (v.age < v.gateN + v.releaseN) {
        float t = 1.0f - static_cast<float>(v.age - v.gateN) / static_cast<float>(v.releaseN);
        env = t * t;
      } else {
        v.active = false;
        return;
      }
      float s = 0.f;
      switch (v.type) {
        case 0: {  // glass pad
          v.ph1 += v.freq * inv2pi;
          v.ph2 += v.freq * 2.004f * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          if (v.ph2 >= 1.f) v.ph2 -= 1.f;
          s = 0.65f * std::sin(kTwoPi * v.ph1) + 0.3f * std::sin(kTwoPi * v.ph2);
          break;
        }
        case 1: {  // FM bell
          v.ph1 += v.freq * inv2pi;
          v.phm += v.freq * 3.5f * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          if (v.phm >= 1.f) v.phm -= 1.f;
          s = std::sin(kTwoPi * v.ph1 + v.bIdx * std::sin(kTwoPi * v.phm)) * v.bAmp;
          v.bIdx *= v.bIdxD;
          v.bAmp *= v.bAmpD;
          break;
        }
        case 2: {  // pluck
          float out = v.ks[v.ksIdx];
          float avg = 0.5f * (out + v.ksPrev);
          v.ksPrev = out;
          float ap = v.apC * (avg - v.apY) + v.apX;
          v.apX = avg;
          v.apY = ap;
          v.ks[v.ksIdx] = ap * v.decay;
          if (++v.ksIdx >= v.ksLen) v.ksIdx = 0;
          s = out * 1.6f;
          break;
        }
        case 4: {  // soft pad: two slightly detuned sines + a quiet octave
          v.ph1 += v.freq * inv2pi;
          v.ph2 += v.freq * 1.0035f * inv2pi;
          v.phm += v.freq * 2.0f * 0.9985f * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          if (v.ph2 >= 1.f) v.ph2 -= 1.f;
          if (v.phm >= 1.f) v.phm -= 1.f;
          s = 0.42f * std::sin(kTwoPi * v.ph1) + 0.42f * std::sin(kTwoPi * v.ph2) + 0.16f * std::sin(kTwoPi * v.phm);
          break;
        }
        case 5: {  // organ: fundamental + 2nd + 3rd harmonic, slow vibrato
          v.phm += 5.2f * inv2pi;
          if (v.phm >= 1.f) v.phm -= 1.f;
          v.ph1 += v.freq * (1.0f + 0.0025f * std::sin(kTwoPi * v.phm)) * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          s = 0.6f * std::sin(kTwoPi * v.ph1) + 0.25f * std::sin(2.f * kTwoPi * v.ph1) + 0.1f * std::sin(3.f * kTwoPi * v.ph1);
          break;
        }
        case 6: {  // FM: carrier + one modulator with feedback, brightness decays with the index envelope
          const float idx = v.fmIdx0 * (0.15f + 0.85f * v.bAmp);
          v.bAmp *= v.bAmpD;
          v.phm += v.freq * v.fmRatio * inv2pi;
          v.phm -= std::floor(v.phm);
          const float m = std::sin(kTwoPi * v.phm + v.fmFb * v.fmPrev);
          v.fmPrev = m;
          v.ph1 += v.freq * inv2pi;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          s = 0.8f * std::sin(kTwoPi * v.ph1 + idx * m);
          break;
        }
        case 7: {  // mini synth: two detuned morphing oscillators into a resonant low-pass
          v.ph1 += v.inc1;
          if (v.ph1 >= 1.f) v.ph1 -= 1.f;
          v.ph2 += v.inc2;
          if (v.ph2 >= 1.f) v.ph2 -= 1.f;
          const float o = 0.5f * (pswWave(v.ph1, v.inc1, v.pwShape, v.pwWidth) + pswWave(v.ph2, v.inc2, v.pwShape, v.pwWidth));
          v.fcEnv *= v.fcEnvD;
          if ((v.age & 15) == 0) updateSvf(v);
          const float v3 = o - v.svI2;
          const float v1 = v.svA1 * v.svI1 + v.svA2 * v3;
          const float v2 = v.svI2 + v.svA2 * v.svI1 + v.svA3 * v3;
          v.svI1 = 2.f * v1 - v.svI1;
          v.svI2 = 2.f * v2 - v.svI2;
          s = v2 * v.svComp;
          break;
        }
        case 8: {  // modal: strike and / or bow into the resonator bank
          float x = 0.f;
          if (v.strikeI < v.strikeN) {
            x = v.strikeAmp * std::sin(kPi * (static_cast<float>(v.strikeI) + 0.5f) / static_cast<float>(v.strikeN));
            ++v.strikeI;
          }
          float bt = 0.f, bn = 0.f;
          if (v.bowAmp > 0.f) {
            v.bowPh += v.bowInc;
            if (v.bowPh >= 1.f) v.bowPh -= 1.f;
            const float lvl = v.bowAmp * env;
            bt = lvl * (1.f - v.bowNoise) * (2.f * v.bowPh - 1.f);
            bn = lvl * v.bowNoise * rng_.bi();
          }
          float sum = 0.f;
          for (int j = 0; j < v.nModes; ++j) {
            const float y = v.mA1[j] * v.mY1[j] - v.mR2[j] * v.mY2[j] + v.mB0[j] * (x + bt * v.mBowT[j] + bn * v.mBowN[j]);
            v.mY2[j] = v.mY1[j];
            v.mY1[j] = y;
            sum += v.mAmp[j] * y;
          }
          s = sum;
          if (v.age < v.gateN) env = 1.f;  // the note is the ringing body; only the bow follows the attack
          break;
        }
        default: {  // sample slice (type 3)
          if (!sample_ || sample_->frames < 4) { v.active = false; return; }
          int N = sample_->frames;
          int i0 = static_cast<int>(v.pos);
          if (i0 >= N - 2) { v.active = false; return; }
          float f = static_cast<float>(v.pos - static_cast<double>(i0));
          float a = sample_->l[static_cast<size_t>(i0)], b = sample_->l[static_cast<size_t>(i0 + 1)];
          float a2 = sample_->r[static_cast<size_t>(i0)], b2 = sample_->r[static_cast<size_t>(i0 + 1)];
          s = 0.5f * ((a + (b - a) * f) + (a2 + (b2 - a2) * f)) * 1.2f;
          v.pos += v.inc;
          break;
        }
      }
      float o = s * env * v.amp * master;
      outL[i] += o * v.gL;
      outR[i] += o * v.gR;
      ++v.age;
    }
    if (v.type == 8) {  // keep the long-dead resonators out of denormal range
      for (int j = 0; j < v.nModes; ++j) {
        if (std::fabs(v.mY1[j]) < 1e-15f) v.mY1[j] = 0.f;
        if (std::fabs(v.mY2[j]) < 1e-15f) v.mY2[j] = 0.f;
      }
    }
  }

  float sr_ = 48000.f;
  const SampleData* sample_ = nullptr;
  Ball balls_[kMaxBalls];
  int nBalls_ = 0, shape_ = 4;
  float angle_ = 0.f, acc_ = 0.f;
  RingsPool rings_;
  Voice voices_[kMaxVoices];
  Rng rng_{0x0AB1Cu};
};

}  // namespace gb
