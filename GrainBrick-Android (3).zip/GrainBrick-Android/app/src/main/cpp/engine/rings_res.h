// GrainBrick Android - resonators for the RINGS ORBIX.
//
// A small bank of struck / strummed resonators in the spirit of a Rings-style module: the notes the
// ORBIX balls play excite a resonator whose character is set by four controls (Structure, Brightness,
// Decay, Position) and a model:
//   0 modal         24 two-pole resonators; Structure bends harmonic -> stiff string -> free bar
//   1 sympathetic   a strummed chord of strings (Structure picks the chord)
//   2 string        one waveguide string with stiffness (Structure = inharmonicity)
//   3 fm            two-operator FM with the same four controls
// Odd and even modes (or strings) go to the left and right channel. At most 1, 2 or 4 notes sound at
// once; a note that is pushed out fades over a few milliseconds instead of clicking.
// This is original code written for this project; it shares no code with any other synth.
#pragma once

#include <algorithm>
#include <cmath>
#include <vector>

#include "dsp.h"

namespace gb {

struct RingsCtl {
  int model = 0;        // 0 modal, 1 sympathetic strings, 2 string, 3 fm
  int polyphony = 1;    // 1, 2 or 4 notes at the same time
  float structure = 0.4f, brightness = 0.6f, decay = 0.55f, position = 0.25f;  // all 0..1
};

class RingsPool {
 public:
  static constexpr int kSlots = 8;
  static constexpr int kModes = 24;
  static constexpr int kStrings = 6;
  static constexpr int kLine = 2048;  // longest string delay in samples

  void prepare(float sr) {
    sr_ = sr;
    lines_.assign(static_cast<size_t>(kSlots) * kStrings * kLine, 0.f);
    slots_.assign(kSlots, Slot());
  }
  void reset() {
    for (auto& s : slots_) s.active = false;
  }
  bool ready() const { return !lines_.empty(); }
  int activeCount() const {
    int n = 0;
    for (const auto& s : slots_) n += s.active ? 1 : 0;
    return n;
  }

  void note(const RingsCtl& c, float freq, float vel, float pan) {
    if (!ready()) return;
    const int poly = std::max(1, std::min(4, c.polyphony));
    for (;;) {  // push out the oldest notes beyond the polyphony
      int live = 0, oldest = -1, oldestAge = -1;
      for (int i = 0; i < kSlots; ++i) {
        Slot& s = slots_[static_cast<size_t>(i)];
        if (s.active && !s.fading) {
          ++live;
          if (s.age > oldestAge) { oldestAge = s.age; oldest = i; }
        }
      }
      if (live < poly || oldest < 0) break;
      Slot& o = slots_[static_cast<size_t>(oldest)];
      o.fading = true;
      o.fadeI = 0;
      o.fadeN = std::max(16, static_cast<int>(0.008f * sr_));
    }
    int idx = -1, oldestAge = -1;
    for (int i = 0; i < kSlots; ++i) {
      if (!slots_[static_cast<size_t>(i)].active) { idx = i; break; }
      if (slots_[static_cast<size_t>(i)].age > oldestAge) { oldestAge = slots_[static_cast<size_t>(i)].age; idx = i; }
    }
    Slot& s = slots_[static_cast<size_t>(idx)];
    s = Slot();
    s.active = true;
    s.model = std::max(0, std::min(3, c.model));
    s.amp = 0.25f + 0.75f * clampf(vel / 1.5f, 0.f, 1.f);
    const float p = clampf(pan, -1.f, 1.f);
    s.gL = 1.f - 0.4f * p;
    s.gR = 1.f + 0.4f * p;
    const float f = clampf(freq, sr_ / 2000.f, 0.45f * sr_);
    switch (s.model) {
      case 0: initModal(s, c, f); break;
      case 1: initStrings(s, c, f, true, idx); break;
      case 2: initStrings(s, c, f, false, idx); break;
      default: initFm(s, c, f); break;
    }
  }

  void render(float* outL, float* outR, int n, float volume) {
    const float master = volume * 0.35f;
    for (auto& s : slots_) {
      if (!s.active) continue;
      for (int i = 0; i < n; ++i) {
        float env = 1.f;
        if (s.fading) {
          env = 1.f - static_cast<float>(s.fadeI) / static_cast<float>(s.fadeN);
          if (++s.fadeI >= s.fadeN) { s.active = false; break; }
        } else if (s.age >= s.maxN) {
          s.active = false;
          break;
        } else if (s.maxN - s.age < kTail) {
          env = static_cast<float>(s.maxN - s.age) / static_cast<float>(kTail);
        }
        float l = 0.f, r = 0.f;
        switch (s.model) {
          case 0: stepModal(s, l, r); break;
          case 3: stepFm(s, l, r); break;
          default: stepStrings(s, l, r); break;
        }
        ++s.age;
        const float g = env * s.amp * master;
        outL[i] += l * g * s.gL;
        outR[i] += r * g * s.gR;
      }
      if (s.model == 0 && s.active) {  // keep dead resonators out of denormal range
        for (int j = 0; j < s.nModes; ++j) {
          if (std::fabs(s.y1[j]) < 1e-15f) s.y1[j] = 0.f;
          if (std::fabs(s.y2[j]) < 1e-15f) s.y2[j] = 0.f;
        }
      }
    }
  }

 private:
  static constexpr int kTail = 2400;
  static constexpr float kModalGain = 2.6f;

  struct Str {
    float D = 100.f, g = 0.99f, b = 1.f, a = 0.f, prev = 0.f, z0 = 0.f, z1 = 0.f, level = 1.f;
    int w = 0, start = 0;
    bool started = false;
  };
  struct Slot {
    bool active = false, fading = false;
    int model = 0, age = 0, maxN = 0, fadeI = 0, fadeN = 1;
    float amp = 1.f, gL = 1.f, gR = 1.f;
    // modal
    int nModes = 0, exN = 0, exI = 0;
    float a1[kModes], r2[kModes], b0[kModes], mAmp[kModes], y1[kModes], y2[kModes];
    float exAmp = 0.f;
    // strings
    int nStr = 0, base = 0;
    float fillCoef = 1.f, fillPos = 0.25f, fillLevel = 1.f;
    Str str[kStrings];
    // fm
    float ph = 0.f, phm = 0.f, inc = 0.f, incM = 0.f, idx0 = 0.f, idxE = 1.f, idxD = 1.f, ampE = 1.f, ampD = 1.f, fb = 0.f, prevM = 0.f;
  };

  static float lerpf(float a, float b, float t) { return a + (b - a) * t; }

  // ---- modal -----------------------------------------------------------------------------
  void initModal(Slot& s, const RingsCtl& c, float f0) {
    const float st = clampf(c.structure, 0.f, 1.f);
    const float bright = clampf(c.brightness, 0.f, 1.f);
    const float bq = 0.25f + 0.75f * bright;
    const float alpha = 0.2f + 1.8f * (1.f - bright);
    float t0 = 0.3f * std::pow(100.f, clampf(c.decay, 0.f, 1.f));
    t0 *= clampf(std::pow(261.6256f / f0, 0.35f), 0.4f, 3.f);
    const float posn = 0.04f + 0.46f * clampf(c.position, 0.f, 1.f);
    float energy = 0.f, longest = 0.f;
    int n = 0;
    for (int k = 1; k <= kModes; ++k) {
      float ratio;
      const float kk = static_cast<float>(k);
      if (st < 0.5f) {
        const float t = st * 2.f;
        ratio = kk * std::sqrt(1.f + 0.002f * t * t * kk * kk);  // harmonic -> stiff string
      } else {
        const float u = (st - 0.5f) * 2.f;
        const float stiff = kk * std::sqrt(1.f + 0.002f * kk * kk);
        const float bar = (kk + 0.5f) * (kk + 0.5f) / 2.25f;      // free bar: 1, 2.78, 5.44, 8.98 ...
        ratio = lerpf(stiff, bar, u);
      }
      const float f = f0 * ratio;
      if (f > 0.45f * sr_) break;
      float amp = 1.f / std::pow(kk, 0.7f);
      amp *= 0.2f + 0.8f * std::fabs(std::sin(kPi * kk * posn));
      amp *= std::pow(bq, std::log2(ratio));
      const float t60 = std::min(12.f, std::max(0.02f, t0 * std::pow(ratio, -alpha)));
      longest = std::max(longest, t60);
      const float r = std::exp(-6.9078f / (t60 * sr_));
      const float w = kTwoPi * f / sr_;
      s.a1[n] = 2.f * r * std::cos(w);
      s.r2[n] = r * r;
      s.b0[n] = std::sin(w);
      s.mAmp[n] = amp;
      s.y1[n] = s.y2[n] = 0.f;
      energy += amp * amp;
      ++n;
    }
    s.nModes = n;
    const float norm = kModalGain / std::sqrt(std::max(1e-6f, energy));
    for (int j = 0; j < n; ++j) s.mAmp[j] *= norm;
    const float vel01 = clampf((s.amp - 0.25f) / 0.75f, 0.f, 1.f);
    const float len = 0.00015f * sr_ * std::pow(27.f, 1.f - bright) * (1.4f - 0.8f * vel01);
    s.exN = std::max(4, static_cast<int>(len));
    s.exI = 0;
    s.exAmp = (kPi * 0.5f) / static_cast<float>(s.exN);
    s.maxN = static_cast<int>(std::min(13.f, longest * 1.3f + 0.05f) * sr_);
  }

  void stepModal(Slot& s, float& l, float& r) {
    float x = 0.f;
    if (s.exI < s.exN) {
      // a hit: half-sine of constant area, roughened with noise (the "internal exciter")
      x = s.exAmp * std::sin(kPi * (static_cast<float>(s.exI) + 0.5f) / static_cast<float>(s.exN)) * (0.7f + 0.6f * rng_.bi());
      ++s.exI;
    }
    for (int j = 0; j < s.nModes; ++j) {
      const float y = s.a1[j] * s.y1[j] - s.r2[j] * s.y2[j] + s.b0[j] * x;
      s.y2[j] = s.y1[j];
      s.y1[j] = y;
      ((j & 1) ? r : l) += s.mAmp[j] * y;
    }
  }

  // ---- strings ---------------------------------------------------------------------------
  void initStrings(Slot& s, const RingsCtl& c, float f0, bool chord, int slotIdx) {
    static const int kChords[8][kStrings] = {
        {0, 12, 24, -12, 12, 0},  {0, 7, 12, 19, -12, -5}, {0, 5, 7, 12, 17, -12}, {0, 3, 7, 12, 15, -12},
        {0, 3, 7, 10, 12, 15},    {0, 3, 7, 10, 14, 12},   {0, 4, 7, 11, 12, 16},  {0, 4, 7, 11, 14, 12}};
    static const int kChordSize[8] = {4, 6, 6, 6, 6, 6, 6, 6};
    const float st = clampf(c.structure, 0.f, 1.f);
    const float bright = clampf(c.brightness, 0.f, 1.f);
    const int ci = std::max(0, std::min(7, static_cast<int>(std::lround(st * 7.f))));
    s.nStr = chord ? kChordSize[ci] : 1;
    s.base = slotIdx * kStrings * kLine;
    const float t60 = 0.3f * std::pow(80.f, clampf(c.decay, 0.f, 1.f));
    const float apA = chord ? -0.02f : -0.9f * st * st;  // stiffness: negative coefficient stretches the overtones
    float norm = 0.f;
    for (int i = 0; i < s.nStr; ++i) {
      Str& q = s.str[i];
      const float fi = clampf(f0 * std::pow(2.f, (chord ? kChords[ci][i] : 0) / 12.f), sr_ / 2000.f, 0.45f * sr_);
      q.b = 0.55f + 0.45f * bright;
      q.a = apA;
      const float w = kTwoPi * fi / sr_;
      const float tau = (1.f - q.a * q.a) / (1.f + q.a * q.a + 2.f * q.a * std::cos(w));  // allpass group delay
      q.D = clampf(sr_ / fi - (1.f - q.b) - 2.f * tau, 4.f, static_cast<float>(kLine - 3));
      q.g = std::min(0.99995f, std::exp(-6.9078f / (t60 * fi)));
      q.level = (i == 0 ? 1.f : 0.6f);
      q.start = chord ? static_cast<int>(0.0045f * sr_ * static_cast<float>(i)) : 0;
      q.started = false;
      q.w = 0;
      norm += q.level * q.level;
    }
    for (int i = 0; i < s.nStr; ++i) s.str[i].level *= 2.0f / std::sqrt(norm);
    s.fillCoef = 0.12f + 0.88f * bright * bright;
    s.fillPos = 0.04f + 0.46f * clampf(c.position, 0.f, 1.f);
    s.fillLevel = 1.f;
    s.maxN = static_cast<int>(std::min(13.f, t60 * 1.2f + 0.1f) * sr_) + static_cast<int>(0.0045f * sr_ * static_cast<float>(s.nStr));
  }

  void pluck(Slot& s, int i) {
    Str& q = s.str[i];
    float* buf = &lines_[static_cast<size_t>(s.base + i * kLine)];
    std::fill(buf, buf + kLine, 0.f);
    const int L = std::max(4, std::min(kLine - 2, static_cast<int>(q.D)));
    float y = 0.f, mean = 0.f;
    for (int k = 0; k < L; ++k) {
      y += s.fillCoef * (rng_.bi() - y);
      buf[k] = y;
      mean += y;
    }
    mean /= static_cast<float>(L);
    const int shift = std::max(1, static_cast<int>(s.fillPos * static_cast<float>(L)));
    float e = 0.f;
    static thread_local float tmp[kLine];
    for (int k = 0; k < L; ++k) {
      tmp[k] = (buf[k] - mean) - (buf[(k + L - shift) % L] - mean);  // pick-up / pluck position comb
      e += tmp[k] * tmp[k];
    }
    const float g = 1.f / std::sqrt(std::max(1e-9f, e / static_cast<float>(L)));
    for (int k = 0; k < L; ++k) buf[k] = tmp[k] * g * 0.5f;
    q.w = L;
    q.prev = 0.f;
    q.z0 = q.z1 = 0.f;
    q.started = true;
  }

  void stepStrings(Slot& s, float& l, float& r) {
    for (int i = 0; i < s.nStr; ++i) {
      Str& q = s.str[i];
      if (!q.started) {
        if (s.age >= q.start) pluck(s, i);
        else continue;
      }
      float* buf = &lines_[static_cast<size_t>(s.base + i * kLine)];
      float rp = static_cast<float>(q.w) - q.D;
      if (rp < 0.f) rp += static_cast<float>(kLine);
      const int i0 = static_cast<int>(rp);
      const float fr = rp - static_cast<float>(i0);
      const int i1 = (i0 + 1 >= kLine) ? 0 : i0 + 1;
      const float y = buf[i0] * (1.f - fr) + buf[i1] * fr;
      float f = q.b * y + (1.f - q.b) * q.prev;
      q.prev = y;
      float o = q.a * f + q.z0;  // two identical all-pass sections = dispersion
      q.z0 = f - q.a * o;
      f = o;
      o = q.a * f + q.z1;
      q.z1 = f - q.a * o;
      buf[q.w] = o * q.g;
      q.w = (q.w + 1 >= kLine) ? 0 : q.w + 1;
      ((i & 1) ? r : l) += y * q.level;
    }
    if (s.nStr == 1) r = l;
  }

  // ---- fm --------------------------------------------------------------------------------
  void initFm(Slot& s, const RingsCtl& c, float f0) {
    static const float kRatios[8] = {0.5f, 1.f, 1.5f, 2.f, 3.f, 4.f, 5.f, 7.f};
    const int ri = std::max(0, std::min(7, static_cast<int>(std::lround(clampf(c.structure, 0.f, 1.f) * 7.f))));
    const float vel01 = clampf((s.amp - 0.25f) / 0.75f, 0.f, 1.f);
    const float bright = clampf(c.brightness, 0.f, 1.f);
    const float time = 0.08f * std::pow(150.f, clampf(c.decay, 0.f, 1.f));  // seconds
    s.inc = f0 / sr_;
    s.incM = f0 * kRatios[ri] / sr_;
    s.idx0 = 10.f * bright * bright * (0.5f + 0.5f * vel01);
    s.idxE = 1.f;
    s.idxD = std::exp(-1.f / (0.35f * time * sr_));
    s.ampE = 1.f;
    s.ampD = std::exp(-6.9078f / (time * sr_));
    s.fb = 1.5f * clampf(c.position, 0.f, 1.f);
    s.maxN = static_cast<int>(std::min(13.f, time * 1.1f + 0.05f) * sr_);
  }

  void stepFm(Slot& s, float& l, float& r) {
    const float idx = s.idx0 * (0.1f + 0.9f * s.idxE);
    s.idxE *= s.idxD;
    s.phm += s.incM;
    s.phm -= std::floor(s.phm);
    const float m = std::sin(kTwoPi * s.phm + s.fb * s.prevM);
    s.prevM = m;
    s.ph += s.inc;
    s.ph -= std::floor(s.ph);
    const float v = 1.2f * std::sin(kTwoPi * s.ph + idx * m) * s.ampE;
    s.ampE *= s.ampD;
    l = v;
    r = v;
  }

  float sr_ = 48000.f;
  Rng rng_{0x2545F491u};
  std::vector<float> lines_;
  std::vector<Slot> slots_;
};

}  // namespace gb
