// Measures and renders one ORBIX note per voice recipe (a project-style JSON with "key": number pairs).
//   voice_eval [-n midi] [-s seconds] [-o outdir] recipe.json ...
// For every recipe it prints the level, the strongest spectral peaks (as multiples of the note's
// frequency) and how fast the fundamental and the strongest overtone die away, and writes a WAV.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <regex>
#include <sstream>
#include <string>
#include <vector>

#include "fft.h"
#include "wav.h"
#include "../../app/src/main/cpp/engine/orbix_params.h"

using namespace gb;
constexpr int kSr = 48000;

static bool loadRecipe(const std::string& path, float* P) {
  std::ifstream in(path);
  if (!in) return false;
  std::stringstream ss;
  ss << in.rdbuf();
  std::string s = ss.str();
  std::regex kv("\"([a-z0-9_.]+)\"\\s*:\\s*(-?[0-9.eE+-]+)");
  for (std::sregex_iterator it(s.begin(), s.end(), kv), end; it != end; ++it) {
    int idx = paramIndex((*it)[1].str().c_str());
    if (idx >= 0) P[idx] = std::strtof((*it)[2].str().c_str(), nullptr);
  }
  return true;
}

static double levelDb(const std::vector<double>& p, double hz, size_t n, double tol = 0.03) {
  const double bin = static_cast<double>(kSr) / static_cast<double>(n);
  size_t lo = static_cast<size_t>(std::max(1.0, hz * (1 - tol) / bin)), hi = static_cast<size_t>(hz * (1 + tol) / bin) + 1;
  double m = 1e-30;
  for (size_t i = lo; i <= hi && i < p.size(); ++i) m = std::max(m, p[i]);
  return 10.0 * std::log10(m);
}

int main(int argc, char** argv) {
  int midi = 60;
  double secs = 5.0;
  std::string outDir;
  std::vector<std::string> files;
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    if (a == "-n" && i + 1 < argc) midi = std::atoi(argv[++i]);
    else if (a == "-s" && i + 1 < argc) secs = std::atof(argv[++i]);
    else if (a == "-o" && i + 1 < argc) outDir = argv[++i];
    else files.push_back(a);
  }
  const double f0 = 440.0 * std::pow(2.0, (midi - 69) / 12.0);
  int bad = 0;
  for (const auto& path : files) {
    std::vector<float> P(P_COUNT);
    for (int i = 0; i < P_COUNT; ++i) P[i] = paramInfo(i).def;
    if (!loadRecipe(path, P.data())) { std::fprintf(stderr, "cannot read %s\n", path.c_str()); return 1; }
    std::ifstream chk(path); std::stringstream cs; cs << chk.rdbuf();
    const bool rings = cs.str().find("\"rings.") != std::string::npos;
    OrbixCtl c = rings ? ringsCtlFromParams(P.data()) : orbixCtlFromParams(P.data());
    c.enabled = false;  // no balls: only the note we play
    Orbix ob;
    ob.prepare(kSr, rings);
    ob.playNote(c, static_cast<float>(midi), 1.5f, 0.f);
    const size_t total = static_cast<size_t>(secs * kSr);
    std::vector<float> L(total), R(total);
    for (size_t i = 0; i + 64 <= total; i += 64) ob.process(c, L.data() + i, R.data() + i, 64);
    std::vector<float> Lo = L, Ro = R;
    for (size_t i = 0; i < total; ++i) L[i] = 0.5f * (L[i] + R[i]);  // analyse the mono sum: odd / even modes sit in different channels
    float peak = 0.f; bool finite = true;
    for (size_t i = 0; i < total; ++i) { peak = std::max(peak, std::fabs(L[i])); if (!std::isfinite(L[i]) || !std::isfinite(R[i])) finite = false; }
    auto rms = [&](double t0, double t1) {
      size_t a = static_cast<size_t>(t0 * kSr), b = std::min(total, static_cast<size_t>(t1 * kSr));
      double e = 0; for (size_t i = a; i < b; ++i) e += static_cast<double>(L[i]) * L[i];
      return 20.0 * std::log10(std::sqrt(e / std::max<size_t>(1, b - a)) + 1e-12);
    };
    std::printf("%s  (note %d = %.1f Hz)\n", path.c_str(), midi, f0);
    std::printf("  peak %.3f%s   rms dB: 0-0.1s %.1f | 0.1-0.4 %.1f | 0.5-1 %.1f | 1-2 %.1f | 2-3 %.1f | 3-5 %.1f\n", peak, finite ? "" : " NON-FINITE",
                rms(0, .1), rms(.1, .4), rms(.5, 1), rms(1, 2), rms(2, 3), rms(3, 5));
    // spectrum at 0.15 s
    const size_t N = 16384;
    auto p = ana::power(L, static_cast<size_t>(0.15 * kSr), N);
    double top = 0; for (double v : p) top = std::max(top, v);
    std::printf("  strongest peaks (x f0, dB re strongest):");
    std::vector<std::pair<double, double>> pk;
    for (size_t i = 3; i + 3 < p.size(); ++i) {
      if (p[i] > p[i - 1] && p[i] >= p[i + 1] && p[i] > top * 1e-6) pk.push_back({p[i], i * static_cast<double>(kSr) / N});
    }
    std::sort(pk.begin(), pk.end(), [](auto& a, auto& b) { return a.first > b.first; });
    for (size_t i = 0; i < pk.size() && i < 8; ++i) std::printf("  %.2fx:%.0f", pk[i].second / f0, 10 * std::log10(pk[i].first / top));
    std::printf("\n");
    // decay of the fundamental and of the strongest overtone (>1.5 x f0)
    double ot = 0, otHz = 0;
    for (auto& q : pk) if (q.second > 1.5 * f0 && q.second < 0.4 * kSr) { ot = q.first; otHz = q.second; break; }
    const size_t n2 = 8192;
    auto pa = ana::power(L, static_cast<size_t>(0.10 * kSr), n2), pb = ana::power(L, static_cast<size_t>(0.90 * kSr), n2);
    std::printf("  fundamental: %.1f dB at 0.1 s -> %.1f dB at 0.9 s (%.1f dB/s)\n", levelDb(pa, f0, n2), levelDb(pb, f0, n2), (levelDb(pa, f0, n2) - levelDb(pb, f0, n2)) / 0.8);
    if (otHz > 0)
      std::printf("  overtone %.2fx: %.1f dB -> %.1f dB (%.1f dB/s)\n", otHz / f0, levelDb(pa, otHz, n2), levelDb(pb, otHz, n2), (levelDb(pa, otHz, n2) - levelDb(pb, otHz, n2)) / 0.8);
    if (!finite || peak > 1.0f) ++bad;
    if (!outDir.empty()) {
      std::string name = path.substr(path.find_last_of('/') == std::string::npos ? 0 : path.find_last_of('/') + 1);
      name = name.substr(0, name.rfind('.'));
      std::vector<float> st(total * 2);
      for (size_t i = 0; i < total; ++i) { st[2 * i] = Lo[i] * 3.f; st[2 * i + 1] = Ro[i] * 3.f; }
      writeWav16(outDir + "/" + name + ".wav", st, kSr);
    }
  }
  return bad ? 1 : 0;
}
